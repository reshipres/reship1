import React, { FC } from 'react';
import { Link } from 'react-router-dom';
import { XMarkIcon, ClockIcon, FireIcon } from '@heroicons/react/24/outline';
import { StarIcon } from '@heroicons/react/24/solid';

// Интерфейсы данных
interface Category {
  id: string;
  title: string;
  path: string;
}

interface HistoryItem {
  id: number;
  title: string;
  price: number;
  image: string;
}

interface Product {
  id: number;
  title: string;
  price: number;
  brand: string;
  image: string;
}

interface SearchDropdownProps {
  searchQuery: string;
  isOpen: boolean;
  categories: Category[];
  historyItems: HistoryItem[];
  popularProducts: Product[];
  searchResults?: Product[];
  onClearHistory: () => void;
  onProductSelect: (product: Product) => void;
  onCategorySelect: (category: Category) => void;
}

const SearchDropdown: FC<SearchDropdownProps> = ({
  searchQuery,
  isOpen,
  categories,
  historyItems,
  popularProducts,
  searchResults,
  onClearHistory,
  onProductSelect,
  onCategorySelect
}) => {
  if (!isOpen) return null;

  const showSearchResults = searchQuery.length > 0 && searchResults && searchResults.length > 0;

  return (
    <div className="absolute top-full left-0 mt-2 bg-white border-2 border-[#646464] rounded-md shadow-lg z-50" 
      style={{ width: '548px', maxHeight: '619px', overflowY: 'auto' }}>
      
      {/* Популярные разделы */}
      {!showSearchResults && (
        <div className="p-4 border-b border-[#E3E7F0]">
          <div className="flex items-center mb-3">
            <div className="w-[31px] h-[31px] flex items-center justify-center bg-[#E3E7F0] rounded-md mr-2">
              <StarIcon className="w-[22px] h-[22px] text-[#096DFF]" />
            </div>
            <span className="font-bold text-[#646464] text-base tracking-tight" style={{ fontFamily: 'Century Gothic' }}>
              Популярные разделы
            </span>
          </div>

          <div className="flex flex-wrap gap-3">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => onCategorySelect(category)}
                className="flex items-center justify-center px-5 py-1.5 border-2 border-[#212121] rounded-[10px]"
              >
                <span className="font-medium text-[#212121] text-base" style={{ fontFamily: 'Roboto' }}>
                  {category.title}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* История просмотров */}
      {!showSearchResults && historyItems.length > 0 && (
        <div className="p-4 border-b border-[#E3E7F0]">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center">
              <div className="w-[31px] h-[31px] flex items-center justify-center bg-[#E3E7F0] rounded-md mr-2">
                <ClockIcon className="w-[21px] h-[20px] text-[#096DFF]" />
              </div>
              <span className="font-bold text-[#646464] text-base tracking-tight" style={{ fontFamily: 'Century Gothic' }}>
                История
              </span>
            </div>
            
            <button 
              onClick={onClearHistory}
              className="flex items-center text-[#096DFF]"
            >
              <XMarkIcon className="w-4 h-4 text-[#096DFF] mr-1" />
              <span className="font-medium text-[14px]">Очистить</span>
            </button>
          </div>

          <div className="space-y-3">
            {historyItems.map((item) => (
              <div key={item.id} className="flex items-center gap-4">
                <div className="flex-shrink-0 w-[23px] h-[22px]">
                  <ClockIcon className="w-[20px] h-[20px] text-gray-400" />
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-[59px] h-[36px] bg-[#E3E7F0] rounded-[2px] flex items-center justify-center overflow-hidden">
                    <img src={item.image} alt={item.title} className="w-[56px] h-[25px] object-contain" />
                  </div>
                  <span className="font-medium text-[#212121] text-lg truncate max-w-[260px]">
                    {item.title}
                  </span>
                </div>
                <span className="font-semibold text-[#7A7A7A] ml-auto" style={{ fontFamily: 'Inter' }}>
                  {item.price.toLocaleString()} ₽
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Хиты/Результаты поиска */}
      <div className="p-4">
        {!showSearchResults ? (
          <>
            <div className="flex items-center mb-3">
              <div className="flex items-center">
                <div className="w-[31px] h-[31px] flex items-center justify-center bg-[#E3E7F0] rounded-md mr-2">
                  <FireIcon className="w-[22px] h-[22px] text-[#096DFF]" />
                </div>
                <span className="font-bold text-[#646464] text-base tracking-tight" style={{ fontFamily: 'Century Gothic' }}>
                  Хиты
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {popularProducts.map((product) => (
                <div 
                  key={product.id} 
                  className="flex items-start gap-4 cursor-pointer"
                  onClick={() => onProductSelect(product)}
                >
                  <div className="flex-shrink-0 w-[102px] h-[88px] bg-[#E3E7F0] rounded-md flex items-center justify-center overflow-hidden">
                    <img src={product.image} alt={product.title} className="w-[94px] h-[62px] object-contain" />
                  </div>
                  <div className="flex flex-col gap-[7px]">
                    <div className="flex flex-col gap-[3px]">
                      <span className="text-[14px] font-medium text-[#7A7A7A]" style={{ fontFamily: 'Roboto' }}>
                        {product.brand}
                      </span>
                      <span className="text-[16px] leading-tight font-medium text-[#212121] truncate max-w-[90px]" style={{ fontFamily: 'Roboto' }}>
                        {product.title}
                      </span>
                    </div>
                    <span className="text-[16px] font-semibold text-[#7A7A7A]" style={{ fontFamily: 'Inter' }}>
                      {product.price.toLocaleString()} ₽
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </>
        ) : (
          // Результаты поиска
          <>
            <div className="flex flex-col gap-4">
              {searchResults.map((product) => (
                <div 
                  key={product.id} 
                  className="flex items-start gap-4 cursor-pointer"
                  onClick={() => onProductSelect(product)}
                >
                  <div className="flex-shrink-0 w-[102px] h-[88px] bg-[#E3E7F0] rounded-md flex items-center justify-center overflow-hidden">
                    <img src={product.image} alt={product.title} className="w-[94px] h-[62px] object-contain" />
                  </div>
                  <div className="flex flex-col gap-[7px]">
                    <div className="flex flex-col gap-[3px]">
                      <span className="text-[14px] font-medium text-[#7A7A7A]" style={{ fontFamily: 'Roboto' }}>
                        {product.brand}
                      </span>
                      <span className="text-[18px] leading-tight font-medium text-[#212121]" style={{ fontFamily: 'Roboto' }}>
                        {product.title}
                      </span>
                    </div>
                    <span className="text-[16px] font-semibold text-[#7A7A7A]" style={{ fontFamily: 'Inter' }}>
                      {product.price.toLocaleString()} ₽
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default SearchDropdown; 