import React, { FC, ChangeEvent, KeyboardEvent } from 'react';
import { MagnifyingGlassIcon } from '@heroicons/react/24/outline';

interface SearchInputProps {
  value: string;
  placeholder?: string;
  onChange: (value: string) => void;
  onFocus?: () => void;
  onBlur?: () => void;
  onKeyDown?: (e: KeyboardEvent<HTMLInputElement>) => void;
  onSearch: () => void;
}

const SearchInput: FC<SearchInputProps> = ({
  value,
  placeholder = 'Я ищу..',
  onChange,
  onFocus,
  onBlur,
  onKeyDown,
  onSearch
}) => {
  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    onChange(e.target.value);
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      onSearch();
      e.preventDefault();
    }
    
    if (onKeyDown) {
      onKeyDown(e);
    }
  };

  return (
    <div className="flex flex-row justify-between items-center w-full h-full" 
      style={{ 
        border: '2px solid #646464', 
        borderRadius: '6px',
        padding: '13px 16px'
      }}
    >
      <input
        type="text"
        placeholder={placeholder}
        value={value}
        onChange={handleChange}
        onFocus={onFocus}
        onBlur={onBlur}
        onKeyDown={handleKeyDown}
        className="w-full border-none outline-none bg-transparent"
        style={{
          fontFamily: 'Roboto',
          fontWeight: 400,
          fontSize: '18px',
          lineHeight: '22px',
          color: '#5F5F5F'
        }}
      />
      <button
        type="button"
        onClick={onSearch}
        className="flex items-center justify-center"
      >
        <MagnifyingGlassIcon className="text-[#646464] w-5 h-5" />
      </button>
    </div>
  );
};

export default SearchInput; 