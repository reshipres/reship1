import React, { FC, useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import SearchInput from './SearchInput';
import SearchDropdown from './SearchDropdown';
import { Category, HistoryItem, Product } from '../../types/search';

interface SearchProps {
  onSearch?: (query: string) => void;
  className?: string;
}

const Search: FC<SearchProps> = ({ onSearch, className = '' }) => {
  const [query, setQuery] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const searchRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  // Моковые данные для категорий
  const categories: Category[] = [
    { id: 'keyboards', title: 'Клавиатуры', path: '/catalog/keyboards' },
    { id: 'mice', title: 'Мышки', path: '/catalog/mice' },
    { id: 'mousepads', title: 'Коврики', path: '/catalog/mousepads' },
    { id: 'mice2', title: 'Мышки', path: '/catalog/mice' },
    { id: 'keyboards2', title: 'Клавиатуры', path: '/catalog/keyboards' },
  ];

  // Моковые данные для истории поиска
  const [historyItems, setHistoryItems] = useState<HistoryItem[]>([
    {
      id: 1,
      title: 'Ergohaven Planeta V2 Galaxy Blac..',
      price: 8200,
      image: '/images/products/keyboards/leopold-fc750r/1.svg'
    },
    {
      id: 2,
      title: 'Hana Glass Mousepad',
      price: 8200,
      image: '/images/products/keyboards/leopold-fc750r/2.svg'
    },
    {
      id: 3,
      title: 'Varmilo Koi — Overshadow the Flo..',
      price: 8200,
      image: '/images/products/keyboards/leopold-fc750r/3.svg'
    }
  ]);

  // Моковые данные для популярных товаров
  const popularProducts: Product[] = [
    {
      id: 1,
      title: 'HS80 RGB USB Gaming Headset 7.1 - Carbon',
      price: 8200,
      brand: 'Corsair',
      image: '/images/products/keyboards/leopold-fc750r/1.svg'
    },
    {
      id: 2,
      title: 'HS80 RGB USB Gaming Carbon',
      price: 8200,
      brand: 'Corsair',
      image: '/images/products/keyboards/leopold-fc750r/2.svg'
    },
  ];

  // Обработчик поиска
  const handleSearch = () => {
    if (query.trim()) {
      if (onSearch) {
        onSearch(query);
      } else {
        navigate(`/search?q=${encodeURIComponent(query)}`);
      }
      setIsDropdownOpen(false);
      
      // Сохраняем запрос в истории поиска
      const isAlreadyInHistory = historyItems.some(item => 
        item.title.toLowerCase().includes(query.toLowerCase())
      );
      
      if (!isAlreadyInHistory && query.length > 2) {
        // В реальном приложении здесь была бы логика для сохранения истории поиска в localStorage или на сервере
        console.log('Запрос сохранен в истории:', query);
      }
    }
  };

  // Обработчик очистки истории
  const handleClearHistory = () => {
    setHistoryItems([]);
    // В реальном приложении здесь была бы логика для очистки истории поиска в localStorage или на сервере
  };

  // Обработчик выбора товара
  const handleProductSelect = (product: Product) => {
    navigate(`/product/${product.id}`);
    setIsDropdownOpen(false);
  };

  // Обработчик выбора категории
  const handleCategorySelect = (category: Category) => {
    navigate(category.path);
    setIsDropdownOpen(false);
  };

  // Обработчик клика вне компонента поиска
  const handleClickOutside = (event: MouseEvent) => {
    if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
      setIsDropdownOpen(false);
    }
  };

  // При изменении запроса выполняем поиск
  useEffect(() => {
    if (query.trim().length > 2) {
      // В реальном приложении здесь был бы запрос на поиск товаров
      // Имитация поискового запроса
      const mockSearchResults = popularProducts.filter(product => 
        product.title.toLowerCase().includes(query.toLowerCase()) ||
        product.brand.toLowerCase().includes(query.toLowerCase())
      );
      setSearchResults(mockSearchResults);
    } else {
      setSearchResults([]);
    }
  }, [query]);

  // Обработчик клика вне компонента
  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div className={`relative ${className}`} ref={searchRef}>
      <SearchInput
        value={query}
        onChange={setQuery}
        onFocus={() => setIsDropdownOpen(true)}
        onSearch={handleSearch}
      />
      
      <SearchDropdown
        searchQuery={query}
        isOpen={isDropdownOpen}
        categories={categories}
        historyItems={historyItems}
        popularProducts={popularProducts}
        searchResults={searchResults}
        onClearHistory={handleClearHistory}
        onProductSelect={handleProductSelect}
        onCategorySelect={handleCategorySelect}
      />
    </div>
  );
};

export default Search; 