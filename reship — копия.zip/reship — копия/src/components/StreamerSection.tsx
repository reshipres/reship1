import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRightIcon } from '@heroicons/react/24/outline';

// Типы для карточек стримеров
interface ProductItem {
  id: number;
  name: string;
  brand: string;
  image: string;
}

interface Streamer {
  id: number;
  name: string;
  nickname: string;
  bgColor: string;
  image: string;
  products: ProductItem[];
}

// Моковые данные стримеров
const streamers: Streamer[] = [
  {
    id: 1,
    name: 'Владимир Братишкин',
    nickname: 'Братишкин (тутуттуу)',
    bgColor: '#2C1B30',
    image: 'https://cdn.forbes.ru/forbes-static/new/2024/04/Vladimir-bratishkinoff-Semenuk-662234b6cab96.jpg',
    products: [
      {
        id: 101,
        name: 'Logitech G PRO X',
        brand: 'Logitech',
        image: 'https://resource.logitechg.com/w_386,c_limit,q_auto,f_auto,dpr_2.0/d_transparent.gif/content/dam/gaming/en/products/pro-x-superlight/pro-x-superlight-black-gallery-1.png'
      },
      {
        id: 102,
        name: 'Logitech G PRO X',
        brand: 'Logitech',
        image: 'https://www.hyperxgaming.com/unitedkingdom/microsite/mousepad/img/furys.webp'
      }
    ]
  },
  {
    id: 2,
    name: 'Evelone ( Вадим)',
    nickname: 'Братишкин (тутуттуу)',
    bgColor: '#2B2239',
    image: 'https://via.placeholder.com/650x415?text=Evelone',
    products: [
      {
        id: 103,
        name: 'Logitech G PRO X',
        brand: 'Logitech',
        image: 'https://resource.logitechg.com/w_386,c_limit,q_auto,f_auto,dpr_2.0/d_transparent.gif/content/dam/gaming/en/products/pro-x-superlight/pro-x-superlight-black-gallery-1.png'
      },
      {
        id: 104,
        name: 'Logitech G PRO X',
        brand: 'Logitech',
        image: 'https://resource.logitechg.com/w_386,c_limit,q_auto,f_auto,dpr_2.0/d_transparent.gif/content/dam/gaming/en/products/pro-x-superlight/pro-x-superlight-black-gallery-1.png'
      }
    ]
  },
  {
    id: 3,
    name: 'Tenderlybae',
    nickname: 'TenderlyBae (тутуттуу)',
    bgColor: '#214A4D',
    image: 'https://via.placeholder.com/650x415?text=TenderlyBae',
    products: [
      {
        id: 105,
        name: 'Logitech G PRO X',
        brand: 'Logitech',
        image: 'https://resource.logitechg.com/w_386,c_limit,q_auto,f_auto,dpr_2.0/d_transparent.gif/content/dam/gaming/en/products/pro-x-superlight/pro-x-superlight-black-gallery-1.png'
      },
      {
        id: 106,
        name: 'Logitech G840',
        brand: 'Logitech',
        image: 'https://resource.logitechg.com/w_386,c_limit,q_auto,f_auto,dpr_2.0/d_transparent.gif/content/dam/gaming/en/products/pro-x-superlight/pro-x-superlight-black-gallery-1.png'
      }
    ]
  }
];

const StreamerSection: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [touchStartX, setTouchStartX] = useState<number | null>(null);
  const [indicators, setIndicators] = useState<number[]>([]);
  
  useEffect(() => {
    setIndicators(streamers.map((_, idx) => idx));
  }, []);
  
  // Обработчики навигации
  const handlePrev = () => {
    if (isTransitioning) return;
    
    setIsTransitioning(true);
    setCurrentIndex(prev => (prev === 0 ? streamers.length - 1 : prev - 1));
    
    setTimeout(() => {
      setIsTransitioning(false);
    }, 300);
  };
  
  const handleNext = () => {
    if (isTransitioning) return;
    
    setIsTransitioning(true);
    setCurrentIndex(prev => (prev === streamers.length - 1 ? 0 : prev + 1));
    
    setTimeout(() => {
      setIsTransitioning(false);
    }, 300);
  };
  
  // Обработчики для сенсорного взаимодействия
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStartX(e.touches[0].clientX);
  };
  
  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX === null) return;
    
    const touchEndX = e.changedTouches[0].clientX;
    const diff = touchStartX - touchEndX;
    
    // Смахивание вправо или влево
    if (Math.abs(diff) > 50) {
      if (diff > 0) {
        handleNext();
      } else {
        handlePrev();
      }
    }
    
    setTouchStartX(null);
  };
  
  // Прямой переход к стримеру по индикатору
  const handleIndicatorClick = (idx: number) => {
    if (isTransitioning || idx === currentIndex) return;
    
    setIsTransitioning(true);
    setCurrentIndex(idx);
    
    setTimeout(() => {
      setIsTransitioning(false);
    }, 300);
  };
  
  // Получаем текущего стримера и следующего (для отображения части)
  const currentStreamer = streamers[currentIndex];
  const nextStreamerIndex = (currentIndex + 1) % streamers.length;
  const nextStreamer = streamers[nextStreamerIndex];

  return (
    <section className="relative w-full bg-[#E3E7F0] py-8 md:py-10 lg:py-14 overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        {/* Левая часть с заголовком и кнопками навигации */}
        <div className="flex flex-col mb-8 md:mb-0 md:flex-row md:items-start md:gap-10">
          <div className="w-full md:w-[355px]">
            <div className="flex flex-col gap-4 md:gap-8">
              {/* Заголовок */}
              <h2 className="font-['Century_Gothic'] font-bold text-3xl md:text-4xl text-[#096DFF]">
                Выбор стримеров
              </h2>
              
              {/* Кнопки навигации */}
              <div className="flex items-center gap-6">
                <div className="flex gap-2.5">
                  <button 
                    onClick={handlePrev}
                    className="flex justify-center items-center w-10 h-10 md:w-[46px] md:h-[46px] rounded-full border-2 border-black hover:bg-black hover:text-white transition-colors duration-300"
                    disabled={isTransitioning}
                  >
                    <svg width="7" height="12" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M7 1L1 7L7 13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </button>
                  <button 
                    onClick={handleNext}
                    className="flex justify-center items-center w-10 h-10 md:w-[46px] md:h-[46px] rounded-full border-2 border-black hover:bg-black hover:text-white transition-colors duration-300"
                    disabled={isTransitioning}
                  >
                    <svg width="7" height="12" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M1 13L7 7L1 1" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </button>
                </div>
                
                {/* Индикаторы */}
                <div className="flex gap-2">
                  {indicators.map(idx => (
                    <button
                      key={idx}
                      onClick={() => handleIndicatorClick(idx)}
                      className={`w-2 h-2 rounded-full transition-all duration-300 ${
                        idx === currentIndex 
                          ? 'bg-black w-4' 
                          : 'bg-gray-400 hover:bg-gray-600'
                      }`}
                      aria-label={`Перейти к стримеру ${idx + 1}`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
          
          {/* Правая часть с карточками стримеров (контейнер с overflow) */}
          <div className="mt-6 md:mt-0 md:ml-auto w-full relative md:w-[calc(100%_-_355px_-_40px)]">
            {/* Здесь контейнер для карточек стримеров */}
            <div 
              className="flex gap-[15px] w-[1351px] relative transition-transform duration-300 ease-in-out"
              style={{ transform: isTransitioning ? 'scale(0.98)' : 'scale(1)' }}
              onTouchStart={handleTouchStart}
              onTouchEnd={handleTouchEnd}
            >
              {/* Первая карточка стримера (полностью видимая) */}
              <div 
                className="streamer-card rounded-[7px] overflow-hidden w-[668px] h-[411px] relative shadow-lg hover:shadow-xl transition-all duration-300 ease-in-out"
              >
                {/* Фоновый цвет и изображение */}
                <div className="absolute inset-0 w-full h-full" style={{ background: currentStreamer.bgColor }}></div>
                <div className="absolute inset-0 w-full h-full opacity-60 transition-transform duration-500 hover:opacity-80 hover:scale-105">
                  <img 
                    src={currentStreamer.image} 
                    alt={currentStreamer.name} 
                    className="w-full h-full object-cover transition-transform duration-700 ease-out" 
                    style={{ objectPosition: "center 20%" }}
                  />
                </div>
                
                {/* Имя стримера */}
                <div className="absolute left-[10px] bottom-[10px] py-2 px-3 w-[296px] backdrop-blur-[27.5px] bg-white/10 rounded-[10px] transition-all duration-300 hover:bg-white/20">
                  <div className="flex flex-col gap-1">
                    <h3 className="font-['Century_Gothic'] font-bold text-xl md:text-2xl text-white tracking-tight">
                      {currentStreamer.name}
                    </h3>
                    <p className="font-['Roboto'] text-sm md:text-base text-white">
                      {currentStreamer.nickname}
                    </p>
                  </div>
                </div>
                
                {/* Карточки товаров стримера */}
                <div className="absolute top-[17px] right-[10px] flex flex-col gap-[15px]">
                  {currentStreamer.products.map((product, idx) => (
                    <Link to={`/product/${product.id}`} key={product.id} className="block transform transition-transform duration-300 hover:translate-y-[-2px] hover:translate-x-[-2px]">
                      <div className="w-[275px] h-[146px] bg-white/10 backdrop-blur-[32.5px] rounded-[7px] p-[10px] transition-all duration-300 hover:bg-white/20">
                        <div className="flex flex-col gap-2">
                          <div className="flex justify-between items-start">
                            <div className="flex flex-col">
                              <h4 className="font-['Century_Gothic'] font-bold text-base text-white tracking-tight line-clamp-1">
                                {product.name}
                              </h4>
                              <span className="text-[10.5px] text-white/50 font-['Inter'] font-medium">
                                {product.brand}
                              </span>
                            </div>
                            <ArrowRightIcon className="w-[14px] h-[14px] text-white -rotate-45 transition-transform duration-300 group-hover:translate-x-1" />
                          </div>
                          <div className="w-full h-[87px] rounded overflow-hidden flex items-center justify-center bg-gradient-to-r from-blue-500/30 to-purple-500/30">
                            <img 
                              src={product.image} 
                              alt={product.name} 
                              className="w-full h-full object-contain p-2 transition-transform duration-500 hover:scale-110"
                            />
                          </div>
                        </div>
                      </div>
                    </Link>
                  ))}
                  
                  {/* Кнопка "Посмотреть все товары" */}
                  <Link to={`/player/${currentStreamer.id}`} className="block transform transition-all duration-300 hover:translate-y-[-2px]">
                    <div className="w-[275px] h-[57px] bg-white rounded-[12px] flex items-center px-[18px] hover:bg-gray-100 transition-colors duration-300 hover:shadow-md group">
                      <span className="font-['Roboto'] font-medium text-sm text-[#212121]">
                        Посмотреть все товары
                      </span>
                      <ArrowRightIcon className="w-[14px] h-[14px] ml-auto text-[#212121] transition-transform duration-300 group-hover:translate-x-1" />
                    </div>
                  </Link>
                </div>
              </div>
              
              {/* Вторая карточка стримера (частично видимая) */}
              <div 
                className="streamer-card rounded-[7px] overflow-hidden w-[668px] h-[411px] relative shadow-lg cursor-pointer"
                onClick={handleNext}
              >
                {/* Фоновый цвет и изображение */}
                <div className="absolute inset-0 w-full h-full" style={{ background: nextStreamer.bgColor }}></div>
                <div className="absolute inset-0 w-full h-full opacity-60 hover:opacity-80 transition-opacity duration-300">
                  <img 
                    src={nextStreamer.image} 
                    alt={nextStreamer.name} 
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-105" 
                    style={{ objectPosition: "center 20%" }}
                  />
                </div>
                
                {/* Имя стримера */}
                <div className="absolute left-[10px] bottom-[10px] py-2 px-3 w-[296px] backdrop-blur-[27.5px] bg-white/10 rounded-[10px] transition-all duration-300 hover:bg-white/20">
                  <div className="flex flex-col gap-1">
                    <h3 className="font-['Century_Gothic'] font-bold text-xl md:text-2xl text-white tracking-tight">
                      {nextStreamer.name}
                    </h3>
                    <p className="font-['Roboto'] text-sm md:text-base text-white">
                      {nextStreamer.nickname}
                    </p>
                  </div>
                </div>
                
                {/* Элемент перехода к следующему */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity duration-300">
                  <div className="w-16 h-16 rounded-full bg-white/30 backdrop-blur-md flex items-center justify-center">
                    <svg width="14" height="24" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M1 13L7 7L1 1" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default StreamerSection; 