import React from 'react';
import VerticalProductCard from './VerticalProductCard';
import { ChevronRightIcon } from '@heroicons/react/24/outline';
import { Link } from 'react-router-dom';

interface Product {
  id: number;
  title: string;
  brand: string;
  price: number;
  oldPrice?: number;
  rating: number;
  reviewCount: number;
  image: string;
  discount?: number;
  isNew?: boolean;
  inStock?: boolean;
  isPreorder?: boolean;
  colors?: Array<{ id: number | string, name: string, hex: string }>;
}

interface ProductGridProps {
  title: string;
  products: Product[];
  filters?: React.ReactNode;
  showViewAll?: boolean;
}

const ProductGrid: React.FC<ProductGridProps> = ({ 
  title, 
  products, 
  filters, 
  showViewAll = true 
}) => {
  return (
    <section className="py-8 bg-[#E3E7F0]">
      <div className="container mx-auto px-4">
        <div className="flex flex-row justify-between items-center mb-5">
          <div className="flex flex-row items-center">
            <h2 className="text-[40px] font-bold leading-[49px] tracking-tight text-[#096DFF]" 
                style={{ fontFamily: 'Century Gothic, sans-serif' }}>
              {title}
            </h2>
            
            {filters && (
              <div className="flex items-center pl-5 ml-4 border-l border-gray-300">
                {filters}
              </div>
            )}
          </div>
          
          {showViewAll && (
            <Link 
              to={`/catalog/${title.toLowerCase().replace(/\s+/g, '-')}`} 
              className="text-[#212121] font-medium text-sm hover:underline">
              Смотреть все
            </Link>
          )}
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {products.map((product) => (
            <VerticalProductCard
              key={product.id}
              id={product.id}
              title={product.title}
              brand={product.brand}
              price={product.price}
              oldPrice={product.oldPrice}
              rating={product.rating}
              reviewCount={product.reviewCount}
              image={product.image}
              discount={product.discount}
              inStock={product.inStock}
              colors={product.colors}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductGrid; 