import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { StarIcon } from '@heroicons/react/24/solid';
import { StarIcon as StarOutlineIcon } from '@heroicons/react/24/outline';
import { HeartIcon } from '@heroicons/react/24/outline';
import { HeartIcon as HeartSolidIcon } from '@heroicons/react/24/solid';
import CartIcon from './icons/CartIcon';
import classNames from 'classnames';
import { useDispatch, useSelector } from 'react-redux';
import { addToCart } from '../store/slices/cartSlice';
import { addToFavorite, removeFromFavorite, selectIsFavorite } from '../store/slices/favoriteSlice';
import { toast } from 'react-hot-toast';
import { Product } from '../types/product';
import { RootState } from '../store';

interface ProductCardProps {
  id: number;
  title: string;
  brand: string;
  price: number;
  oldPrice?: number;
  rating: number;
  reviewCount: number;
  image: string;
  discount?: number;
  isNew?: boolean;
  isPreorder?: boolean;
  inStock?: boolean;
  colors?: Array<{ id: number | string, name: string, hex: string }>;
  className?: string;
}

const ProductCard: React.FC<ProductCardProps> = ({
  id,
  title,
  brand,
  price,
  oldPrice,
  rating,
  reviewCount,
  image,
  discount,
  isNew,
  isPreorder,
  inStock = true,
  colors = [],
  className = ''
}) => {
  const [selectedColor, setSelectedColor] = useState(colors.length > 0 ? colors[0].id : null);
  const [isHovered, setIsHovered] = useState(false);
  const [imageError, setImageError] = useState(false);
  const dispatch = useDispatch();
  const isFavorite = useSelector((state: RootState) => selectIsFavorite(state, id));

  // Используем локальную заглушку
  const defaultImage = '/images/products/fallback.svg';

  // Обработчик ошибки загрузки изображения
  const handleImageError = () => {
    setImageError(true);
  };

  // Получаем финальный URL изображения
  const getImageUrl = () => {
    if (imageError) return defaultImage;
    return image || defaultImage;
  };

  // Функция для добавления товара в корзину
  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!inStock) return;
    
    const selectedColorObj = colors.find(color => color.id === selectedColor);
    const selectedColorName = selectedColorObj ? selectedColorObj.name : undefined;
    
    // Создаем объект продукта для корзины
    const productData: Product = {
      id,
      title,
      brand,
      price,
      oldPrice,
      rating,
      reviewCount,
      image,
      discount,
      isNew,
      inStock,
      colors,
      isPreorder
    };
    
    dispatch(addToCart({
      product: productData,
      quantity: 1,
      selectedColor: selectedColorName
    }));
    
    toast.success('Товар добавлен в корзину');
  };

  // Функция для добавления/удаления товара из избранного
  const handleFavoriteToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (isFavorite) {
      dispatch(removeFromFavorite(id));
      toast.success('Товар удален из избранного');
    } else {
      // Создаем объект продукта для избранного
      const productData: Product = {
        id,
        title,
        brand,
        price,
        oldPrice,
        rating,
        reviewCount,
        image,
        discount,
        isNew,
        inStock,
        colors,
        isPreorder
      };
      
      dispatch(addToFavorite(productData));
      toast.success('Товар добавлен в избранное');
    }
  };
  
  // Обработчик клика по бренду
  const handleBrandClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    window.location.href = `/catalog/brands/${brand.toLowerCase().replace(/\s+/g, '-')}`;
  };

  // Проверяем, начинается ли название товара с бренда
  const displayTitle = title.startsWith(brand) 
    ? title.substring(brand.length).trim() 
    : title;
  
  return (
    <Link 
      to={`/product/${id}`} 
      className={classNames(
        "block relative bg-white rounded-lg overflow-hidden transition-all duration-200 hover:shadow-md",
        className
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Изображение товара */}
      <div className="relative h-[240px] w-full bg-white rounded-lg overflow-hidden">
        <img 
          src={getImageUrl()} 
          alt={title}
          className="w-full h-full object-contain transition-transform duration-300"
          onError={handleImageError}
        />
        
        {/* Бейдж "Новинка" */}
        {isNew && !discount && (
          <div className="absolute top-3 left-3 bg-green-500 text-white text-xs font-medium py-1 px-2 rounded">
            Новинка
          </div>
        )}
        
        {/* Бейдж "Предзаказ" */}
        {isPreorder && !discount && !isNew && (
          <div className="absolute top-3 left-3 bg-purple-500 text-white text-xs font-medium py-1 px-2 rounded">
            Предзаказ
          </div>
        )}
        
        {/* Бейдж скидки */}
        {discount && (
          <div className="absolute top-3 left-3 bg-[#096DFF] text-white text-sm font-medium py-1 px-2.5 rounded">
            Скидка -{discount}%
          </div>
        )}
        
        {/* Кнопка добавления в избранное */}
        <button
          onClick={handleFavoriteToggle}
          className="absolute top-3 right-3 p-1.5 bg-white rounded-full shadow-sm hover:shadow-md transition-shadow duration-200 z-10"
          aria-label={isFavorite ? 'Удалить из избранного' : 'Добавить в избранное'}
        >
          {isFavorite ? (
            <HeartSolidIcon className="h-5 w-5 text-red-500" />
          ) : (
            <HeartIcon className="h-5 w-5 text-gray-500" />
          )}
        </button>
        
        {/* Выбор цветов товара */}
        {colors.length > 0 && (
          <div className="absolute bottom-3 left-3 flex items-center gap-1.5">
            {colors.slice(0, 3).map((color) => (
              <button
                key={color.id}
                className={classNames(
                  "w-[22px] h-[22px] rounded-md transition-all border",
                  color.id === selectedColor ? "border-gray-800" : "border-transparent"
                )}
                style={{ backgroundColor: color.hex }}
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setSelectedColor(color.id);
                }}
                aria-label={`Выбрать цвет: ${color.name}`}
              ></button>
            ))}
            
            {colors.length > 3 && (
              <div className="w-[22px] h-[22px] rounded-md bg-[#E3E7F0] flex items-center justify-center text-xs font-medium text-gray-800">
                +{colors.length - 3}
              </div>
            )}
          </div>
        )}
      </div>
      
      {/* Информация о товаре */}
      <div className="p-3 flex flex-col gap-1.5">
        <h3 className="text-base md:text-lg font-medium text-gray-900 line-clamp-2">
          <span 
            className="text-gray-500 hover:text-[#096DFF] cursor-pointer transition-colors"
            onClick={handleBrandClick}
          >
            {brand}
          </span>{' '}
          {displayTitle}
        </h3>
        
        {/* Рейтинг */}
        <div className="flex items-center gap-1">
          <div className="flex">
            {Array.from({ length: 5 }).map((_, index) => (
              index < Math.floor(rating) ? (
                <StarIcon key={index} className="h-[18px] w-[18px] text-[#096DFF] stroke-[#096DFF]" />
              ) : (
                <StarOutlineIcon key={index} className="h-[18px] w-[18px] text-white stroke-[#096DFF]" />
              )
            ))}
          </div>
          <span className="text-xs text-gray-600 ml-1">{reviewCount}</span>
        </div>
        
        {/* Цена */}
        <div className="flex items-center gap-2 mt-1">
          {oldPrice && (
            <div className="relative">
              <span className="text-gray-500 text-base line-through">{oldPrice.toLocaleString()} ₽</span>
            </div>
          )}
          <span className={`text-xl font-semibold ${discount ? 'text-[#096DFF]' : 'text-[#212121]'}`}>
            {price.toLocaleString()} ₽
          </span>
        </div>
      </div>
      
      {/* Плавающая кнопка добавления в корзину, появляется при наведении */}
      {inStock && isHovered && (
        <button
          onClick={handleAddToCart}
          className="absolute bottom-3 right-3 bg-primary text-white p-2 rounded-full shadow-lg transition-all duration-300 transform hover:scale-110"
          aria-label="Добавить в корзину"
        >
          <CartIcon className="h-5 w-5" />
        </button>
      )}
      
      {/* Индикатор отсутствия на складе */}
      {!inStock && (
        <div className="absolute bottom-0 left-0 right-0 bg-gray-800 bg-opacity-70 text-white py-1 px-3 text-center text-sm">
          Нет в наличии
        </div>
      )}
    </Link>
  );
};

export default ProductCard;