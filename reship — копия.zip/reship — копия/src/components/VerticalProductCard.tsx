import React from 'react';
import { Link } from 'react-router-dom';
import { StarIcon } from '@heroicons/react/24/solid';
import { HeartIcon } from '@heroicons/react/24/outline';
import { HeartIcon as HeartSolidIcon } from '@heroicons/react/24/solid';
import { useDispatch, useSelector } from 'react-redux';
import { addToFavorite, removeFromFavorite, selectIsFavorite } from '../store/slices/favoriteSlice';
import { toast } from 'react-hot-toast';
import { Product } from '../types/product';
import { RootState } from '../store';

interface VerticalProductCardProps {
  id: number;
  title: string;
  brand: string;
  price: number;
  oldPrice?: number;
  rating: number;
  reviewCount: number;
  image: string;
  discount?: number;
  inStock?: boolean;
  colors?: Array<{ id: number | string, name: string, hex: string }>;
  className?: string;
}

const VerticalProductCard: React.FC<VerticalProductCardProps> = ({
  id,
  title,
  brand,
  price,
  oldPrice,
  rating,
  reviewCount,
  image,
  discount,
  inStock = true,
  colors = [],
  className = ''
}) => {
  const dispatch = useDispatch();
  const isFavorite = useSelector((state: RootState) => selectIsFavorite(state, id));

  // Функция для добавления/удаления товара из избранного
  const handleFavoriteToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (isFavorite) {
      dispatch(removeFromFavorite(id));
      toast.success('Товар удален из избранного');
    } else {
      // Создаем объект продукта для избранного
      const productData: Product = {
        id,
        title,
        brand,
        price,
        oldPrice,
        rating,
        reviewCount,
        image,
        discount,
        inStock,
        colors
      };
      
      dispatch(addToFavorite(productData));
      toast.success('Товар добавлен в избранное');
    }
  };

  // Обработчик клика по бренду
  const handleBrandClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    window.location.href = `/catalog/brands/${brand.toLowerCase().replace(/\s+/g, '-')}`;
  };

  // Проверяем, начинается ли название товара с бренда
  const displayTitle = title.startsWith(brand) 
    ? title.substring(brand.length).trim() 
    : title;

  return (
    <Link to={`/product/${id}`} className={`block w-[279px] ${className}`}>
      {/* Изображение товара с бейджами */}
      <div className="relative w-full h-[241px] mb-[13px]">
        <img 
          src={image} 
          alt={title}
          className="w-full h-full object-contain bg-white rounded-[7px]"
        />
        
        {/* Бейдж скидки */}
        {discount && (
          <div className="absolute top-3 left-3 bg-[#096DFF] text-white py-1 px-2.5 rounded-[5px] text-sm font-medium">
            Скидка -{discount}%
          </div>
        )}

        {/* Индикатор отсутствия на складе */}
        {!inStock && (
          <div className="absolute top-3 left-3 bg-gray-700 text-white py-1 px-2.5 rounded-[5px] text-sm font-medium">
            Нет в наличии
          </div>
        )}
        
        {/* Кнопка добавления в избранное */}
        <button
          onClick={handleFavoriteToggle}
          className="absolute top-3 right-3 p-1.5 bg-white rounded-full shadow-sm hover:shadow-md transition-shadow duration-200 z-10"
          aria-label={isFavorite ? 'Удалить из избранного' : 'Добавить в избранное'}
        >
          {isFavorite ? (
            <HeartSolidIcon className="h-5 w-5 text-red-500" />
          ) : (
            <HeartIcon className="h-5 w-5 text-gray-500" />
          )}
        </button>
        
        {/* Выбор цветов товара */}
        {colors.length > 0 && (
          <div className="absolute bottom-3 left-3 flex items-center gap-[5px]">
            {colors.slice(0, 2).map((color) => (
              <div
                key={color.id}
                className="w-[22px] h-[22px] rounded-[6.5px]"
                style={{ backgroundColor: color.hex }}
              ></div>
            ))}
            
            {colors.length > 2 && (
              <div className="w-[22px] h-[22px] rounded-[6.5px] bg-[#E3E7F0] flex items-center justify-center">
                <span className="text-[#212121] text-[13px] font-medium">+{colors.length - 2}</span>
              </div>
            )}
          </div>
        )}
      </div>
      
      {/* Информация о товаре */}
      <div className="flex flex-col gap-[6px]">
        {/* Название товара с кликабельным брендом */}
        <h3 className="text-[20px] leading-[23px] text-[#212121] font-normal font-roboto line-clamp-2">
          <span 
            className="text-gray-500 hover:text-[#096DFF] cursor-pointer transition-colors"
            onClick={handleBrandClick}
          >
            {brand}
          </span>{' '}
          {displayTitle}
        </h3>
        
        {/* Рейтинг */}
        <div className="flex gap-[5px] items-center">
          <div className="flex">
            {Array.from({ length: 5 }).map((_, index) => (
              <div key={index} className="w-[19px] h-[18px] relative">
                <StarIcon 
                  className={`w-full h-full ${index < Math.floor(rating) ? 'text-[#096DFF]' : 'text-[#E3E7F0]'}`} 
                />
              </div>
            ))}
          </div>
          <span className="text-[13px] text-[#383838] font-medium">{reviewCount}</span>
        </div>
        
        {/* Цена */}
        <div className="flex items-center gap-2 mt-1">
          {oldPrice && (
            <div className="relative">
              <span className="text-[20px] text-[#838383] font-semibold line-through">{oldPrice.toLocaleString()} ₽</span>
              <div className="absolute w-full h-0 border-t-[1.2px] border-[#838383] top-[28px]"></div>
            </div>
          )}
          <span className={`text-[22px] leading-[27px] font-semibold ${discount ? 'text-[#096DFF]' : 'text-[#212121]'}`}>
            {price.toLocaleString()}₽
          </span>
        </div>
      </div>
    </Link>
  );
};

export default VerticalProductCard; 