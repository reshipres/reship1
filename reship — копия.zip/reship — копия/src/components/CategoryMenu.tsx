import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRightIcon } from '@heroicons/react/24/solid';

interface CategoryProps {
  id: number;
  name: string;
  image: string;
  slug: string;
}

interface CategoryMenuProps {
  categories: CategoryProps[];
}

const CategoryMenu: React.FC<CategoryMenuProps> = ({ categories }) => {
  return (
    <div className="w-full overflow-hidden bg-[#E3E7F0] py-6">
      <div className="container mx-auto px-3 md:px-4">
        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3 md:gap-4">
          {categories.map((category) => (
            <div
              key={category.id}
              className="w-full"
            >
              <Link 
                to={`/catalog/${category.slug}`} 
                className="flex flex-col bg-white rounded-lg shadow-sm h-[90px] md:h-[100px] w-full transition-all duration-200 hover:shadow-md hover:-translate-y-1"
              >
                <div className="p-2.5 flex flex-col h-full">
                  <div className="mb-1.5 flex justify-between items-center">
                    <span className="font-bold text-xs md:text-sm text-[#212121] line-clamp-1">
                      {category.name}
                    </span>
                    <div className="w-3.5 h-3.5 flex items-center justify-center">
                      <ChevronRightIcon className="h-2.5 w-2.5 text-black" />
                    </div>
                  </div>
                  <div className="w-full flex-grow bg-gradient-to-br from-[#f5f5f5] to-[#e8e8e8] rounded-lg flex items-center justify-center group overflow-hidden relative">
                    <div className="absolute inset-0 w-full h-full opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <div className="absolute inset-0 bg-white/30 backdrop-blur-[2px]"></div>
                      <div className="absolute inset-0 bg-gradient-to-t from-white/40 to-transparent"></div>
                    </div>
                    <span className="relative z-10 text-[#212121] opacity-0 group-hover:opacity-100 text-[10px] md:text-xs font-medium transition-opacity duration-300">
                      Перейти в категорию
                    </span>
                  </div>
                </div>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default CategoryMenu;
