import React, { useState, useEffect, useRef } from 'react';
import { Link, NavLink } from 'react-router-dom';
import '../styles/fonts.css';

// Данные для слайдера
const slides = [
  {
    id: 1,
    title: 'Как поменялись клавиатуры в 2025',
    description: 'О выбранный нами инновационный путь требует от нас анализа форм воздействия. Являясь всего лишь частью общей картины.',
    backgroundImage: 'https://wraithesports.com/cdn/shop/videos/c/vp/7ce328de0a9846fdb5065c2e87524bc2/7ce328de0a9846fdb5065c2e87524bc2.HD-1080p-7.2Mbps-41863541.mp4?v=0',
    isVideo: true,
    link: '/blog/keyboards-2025',
  },
  {
    id: 2,
    title: 'Лучшие мышки 2025 года',
    description: '',
    backgroundImage: 'url(https://pbs.twimg.com/media/GkR-MlhWkAAJJoz?format=jpg&name=4096x4096)',
    isVideo: false,
    link: '/blog/best-mice-2025',
  },
  {
    id: 3,
    title: 'Топ-5 ковриков для киберспортсменов',
    description: 'Выбор профессионалов: какие коврики используют лучшие игроки на мировой сцене.',
    backgroundImage: 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    isVideo: true,
    link: '/blog/pro-mousepads-2025',
  }
];

const Hero: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isHovering, setIsHovering] = useState(false);
  const [backgroundErrors, setBackgroundErrors] = useState<Record<number, boolean>>({});
  const [isTransitioning, setIsTransitioning] = useState(false);
  const slideIntervalRef = useRef<NodeJS.Timeout | null>(null);
  
  // Функция для запуска таймера слайдов
  const startSlideTimer = () => {
    // Очищаем предыдущий таймер если он существует
    if (slideIntervalRef.current) {
      clearInterval(slideIntervalRef.current);
    }
    
    // Устанавливаем новый таймер на 6 секунд
    slideIntervalRef.current = setInterval(() => {
      changeSlide((currentSlide + 1) % slides.length);
    }, 6000);
  };
  
  // Запускаем таймер при первой загрузке компонента
  useEffect(() => {
    startSlideTimer();
    
    // Очистка таймера при размонтировании компонента
    return () => {
      if (slideIntervalRef.current) {
        clearInterval(slideIntervalRef.current);
      }
    };
  }, [currentSlide]); // Перезапускаем таймер при изменении слайда
  
  // Функция для плавного переключения слайдов
  const changeSlide = (index: number) => {
    if (isTransitioning || index === currentSlide) return;
    
    setIsTransitioning(true);
    
    // Задержка для завершения анимации исчезновения перед сменой слайда
    setTimeout(() => {
      setCurrentSlide(index);
      
      // Задержка для завершения анимации появления после смены слайда
      setTimeout(() => {
        setIsTransitioning(false);
      }, 500);
    }, 500);
  };
  
  // Переключение на конкретный слайд (с перезапуском таймера)
  const goToSlide = (index: number) => {
    changeSlide(index);
    startSlideTimer(); // Перезапуск таймера при ручном переключении
  };

  // Обработчик ошибки загрузки фонового изображения или видео
  const handleBackgroundError = (slideId: number) => {
    console.error(`Ошибка загрузки медиа для слайда ${slideId}`);
    setBackgroundErrors(prev => ({
      ...prev,
      [slideId]: true
    }));
  };
  
  // Очистка URL от префикса url()
  const cleanUrl = (url: string) => {
    if (url.startsWith('url(') && url.endsWith(')')) {
      return url.slice(4, -1).replace(/['"]/g, '');
    }
    return url;
  };
  
  // Генерация фонового стиля для слайда
  const getSlideBackground = (slideIndex: number) => {
    const slide = slides[slideIndex];
    
    // Если ошибка загрузки или нет фонового изображения - используем градиент
    if (backgroundErrors[slide.id] || !slide.backgroundImage) {
      return 'linear-gradient(135deg, #0A6DFF, #213559)';
    }
    
    // Если это не видео, и URL имеет формат url(...), используем его напрямую
    return slide.isVideo ? '' : slide.backgroundImage;
  };
  
  return (
    <section className="w-full bg-[#E3E7F0] pt-[18px] pb-[18px]">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-stretch gap-[13px]" style={{ height: 'auto' }}>
          {/* Левая часть с изображением - адаптированная согласно дизайну Figma */}
          <div 
            className="relative flex-grow w-full lg:w-[73%] h-[300px] md:h-[400px] lg:h-[570px] rounded-[7px] overflow-hidden mb-4 lg:mb-0"
            style={{ flex: 'none', order: 0 }}
          >
            {/* Фоновое изображение или видео с плавным переходом */}
            <div className={`absolute inset-0 w-full h-full transition-opacity duration-1000 ease-in-out ${isTransitioning ? 'opacity-0' : 'opacity-100'}`}>
              {slides[currentSlide].isVideo ? (
                <video 
                  className="absolute inset-0 w-full h-full object-cover rounded-[7px] transition-transform duration-700 ease-out"
                  src={cleanUrl(slides[currentSlide].backgroundImage)}
                  autoPlay
                  muted
                  loop
                  playsInline
                  key={`video-${currentSlide}`}
                  onError={() => handleBackgroundError(slides[currentSlide].id)}
                  style={{ objectPosition: 'center center', transform: isTransitioning ? 'scale(1.05)' : 'scale(1)' }}
                />
              ) : (
                <div 
                  className="absolute inset-0 bg-cover bg-center rounded-[7px] transition-transform duration-700 ease-out" 
                  style={{
                    background: getSlideBackground(currentSlide),
                    backgroundSize: 'cover',
                    backgroundPosition: 'center center',
                    transform: isTransitioning ? 'scale(1.05)' : 'scale(1)'
                  }}
                  key={`bg-${currentSlide}`}
                  onError={() => handleBackgroundError(slides[currentSlide].id)}
                ></div>
              )}
            </div>
            
            {/* Градиентный оверлей согласно дизайну */}
            <div className="absolute w-full h-full inset-0 bg-gradient-to-b from-transparent via-black/30 to-black rounded-[7px]"></div>
            
            {/* Контент с правильным выравниванием и отступами */}
            <div className="relative z-10 w-full h-full px-4 md:px-[29px] py-3 md:py-[12px] flex flex-col">
              <div className="flex flex-col flex-grow justify-end pt-[130px] md:pt-[160px] lg:pt-[220px]">
                {/* Основной контент: текст и кнопка */}
                <div className="flex flex-row items-end justify-between gap-4 sm:gap-[62px] w-full mb-5 lg:mb-[23px]">
                  {/* Текстовый блок с анимацией */}
                  <div 
                    className={`flex flex-col gap-5 max-w-full sm:max-w-[85%] md:max-w-[75%] lg:max-w-[571px] transition-all duration-700 ease-in-out ${
                      isTransitioning ? 'opacity-0 transform translate-y-4' : 'opacity-100 transform translate-y-0'
                    }`}
                    key={`content-${currentSlide}`}
                  >
                    {/* Заголовок согласно макету */}
                    <h1 className="text-xl md:text-[28px] lg:text-[32px] font-bold text-white leading-[1.2] tracking-[-0.01em]" 
                        style={{ 
                          fontFamily: 'Century Gothic',
                          fontWeight: 700,
                          lineHeight: '39px',
                          letterSpacing: '-0.01em'
                        }}>
                      {slides[currentSlide].title}
                    </h1>
                    
                    {/* Описание согласно макету (показываем только если есть) */}
                    {slides[currentSlide].description && (
                      <p className="text-sm md:text-base lg:text-[20px] text-white leading-[1.25] max-w-[90%] lg:max-w-[544px]" 
                        style={{ 
                          fontFamily: 'Roboto',
                          fontWeight: 400,
                          lineHeight: '25px'
                        }}>
                        {slides[currentSlide].description}
                      </p>
                    )}
                  </div>
                  
                  {/* Кнопка "Посмотреть" с правильным стилем - поднята ещё выше */}
                  <div className={`flex items-end mb-8 transition-all duration-700 ease-in-out ${
                    isTransitioning ? 'opacity-0 transform translate-y-4' : 'opacity-100 transform translate-y-0'
                  }`}>
                    <Link 
                      to={slides[currentSlide].link}
                      className="flex justify-center items-center px-[39px] py-[18px] border-2 border-white text-white rounded-[11px] transition-all duration-300 hover:bg-white/10 whitespace-nowrap"
                      aria-label="Посмотреть"
                    >
                      <span className="text-white font-medium text-[16px]" style={{ fontFamily: 'Roboto' }}>Посмотреть</span>
                    </Link>
                  </div>
                </div>
                
                {/* Слайдер с индикаторами - с плавным переходом */}
                <div className="flex items-center justify-center gap-[8px] w-full mt-0 transition-opacity duration-500 ease-in-out">
                  {slides.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => goToSlide(index)}
                      className={`h-[5px] transition-all duration-700 ease-in-out rounded-[15px] ${
                        currentSlide === index ? 'w-[18px] bg-[#3772FF]' : 'w-[11px] bg-white hover:bg-white/70'
                      }`}
                      aria-label={`Перейти к слайду ${index + 1}`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
          
          {/* Правая часть с советником по подбору */}
          <div 
            className="w-full lg:w-[27%] h-[300px] md:h-[400px] lg:h-[570px] lg:flex-grow-0 transition-all duration-500 rounded-[7px] overflow-hidden"
            style={{ order: 1 }}
            onMouseEnter={() => setIsHovering(true)}
            onMouseLeave={() => setIsHovering(false)}
          >
            <Link 
              to="/tools/setup-finder"
              className="flex flex-col items-end w-full h-full bg-[#096DFF] overflow-hidden relative"
            >
              {/* Декоративные элементы (линии и фигуры) */}
              <div className="absolute w-full h-full left-0 top-0 opacity-40">
                {/* Группа верхних линий */}
                <div className="absolute w-full h-[168px] left-[5%] top-0">
                  {/* Серия горизонтальных линий */}
                  <div className="absolute w-[60%] h-0 right-[10%] top-[55px] border border-white transform rotate-180"></div>
                  <div className="absolute w-[60%] h-0 right-[10%] top-[81px] border border-white transform rotate-180"></div>
                  <div className="absolute w-[60%] h-0 right-[10%] top-[112px] border border-white transform rotate-180"></div>
                  <div className="absolute w-[50%] h-0 right-[5%] top-[142px] border border-white transform rotate-180"></div>
                  
                  {/* Серия вертикальных линий - адаптивно с процентами */}
                  <div className="absolute w-[143px] h-0 left-[20%] top-[25px] border border-white transform rotate-90"></div>
                  <div className="absolute w-[143px] h-0 left-[30%] top-[25px] border border-white transform rotate-90"></div>
                  <div className="absolute w-[143px] h-0 left-[40%] top-[25px] border border-white transform rotate-90"></div>
                  <div className="absolute w-[143px] h-0 left-[50%] top-[25px] border border-white transform rotate-90"></div>
                  <div className="absolute w-[143px] h-0 left-[60%] top-[25px] border border-white transform rotate-90"></div>
                  <div className="absolute w-[143px] h-0 left-[70%] top-[25px] border border-white transform rotate-90"></div>
                  <div className="absolute w-[143px] h-0 left-[90%] top-[25px] border border-white transform rotate-90"></div>
                </div>
                
                {/* Группа нижних линий - адаптивно */}
                <div className="absolute w-[30%] h-[174px] left-0 bottom-[15%]">
                  <div className="absolute w-[174px] h-0 left-[36px] bottom-0 border border-white transform -rotate-90"></div>
                  <div className="absolute w-[100%] h-0 left-0 bottom-[40px] border border-white"></div>
                  <div className="absolute w-[100%] h-0 left-0 bottom-[60px] border border-white"></div>
                  <div className="absolute w-[95%] h-0 left-0 bottom-[80px] border border-white"></div>
                  <div className="absolute w-[73px] h-0 left-[11px] bottom-[60px] border border-white transform -rotate-90"></div>
                </div>
                
                {/* Декоративный прямоугольник с фоном - адаптивно */}
                <div className="absolute w-[45%] h-[76px] left-[10%] bottom-[20%] bg-white/20"></div>
                
                {/* Декоративные круги - адаптивно */}
                <div className="absolute w-[40px] h-[40px] right-[15%] top-[20%] bg-[#9FBCFF] rounded-full transform rotate-[-15deg]"></div>
                <div className="absolute w-[64px] h-[64px] left-[12%] top-[25%] bg-white/20 rounded-full transform rotate-[-30deg]"></div>
              </div>
              
              {/* Основной контент */}
              <div className="flex flex-col items-start p-[5%] gap-[10px] isolation-isolate w-full h-full z-10">
                {/* Заголовок "Начать покупку" */}
                <div className="flex flex-row items-center w-[90%] mt-[30%] z-[1]">
                  <h2 className="w-[80%] text-[26px] md:text-[32px] leading-[1.2] font-bold text-white tracking-[-0.01em] mr-[-38px]"
                     style={{ fontFamily: 'Century Gothic' }}>
                    Начать покупку
                  </h2>
                  
                  {/* Круглая кнопка со стрелкой */}
                  <div className="flex items-center justify-center w-[50px] h-[50px] md:w-[58px] md:h-[58px] bg-white rounded-full ml-auto">
                    <div className="w-[12px] h-[12px] md:w-[20px] md:h-[20px] bg-black transform rotate-90 rounded-[1px]"></div>
                  </div>
                </div>
                
                {/* Разделительная линия и информационный блок */}
                <div className="flex flex-col items-end gap-[8px] w-full mt-auto">
                  {/* Линия разделитель */}
                  <div className="w-full h-0 border-t-2 border-[#90BDFF]"></div>
                  
                  {/* Информационный текст */}
                  <div className="flex flex-col items-start gap-[6px] w-full">
                    <p className="w-full text-[14px] md:text-[16px] leading-[1.2] font-semibold text-white" style={{ fontFamily: 'Roboto' }}>
                      Не знаешь что выбрать?
                    </p>
                    <p className="w-[90%] text-[12px] md:text-[14px] leading-[1.3] font-normal text-white" style={{ fontFamily: 'Roboto' }}>
                      Наш инструмент поможет тебе найти идеальную мышку или коврик
                    </p>
                  </div>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;