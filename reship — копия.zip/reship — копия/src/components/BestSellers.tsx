import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeftIcon, ChevronRightIcon } from '@heroicons/react/24/outline';
import VerticalProductCard from './VerticalProductCard';

interface Product {
  id: number;
  title: string;
  brand: string;
  price: number;
  oldPrice?: number;
  rating: number;
  reviewCount: number;
  image: string;
  discount?: number;
  isNew?: boolean;
  isPreorder?: boolean;
  inStock?: boolean;
  colors?: Array<{id: number | string, name: string, hex: string}>;
}

interface BestSellersProps {
  products: Product[];
}

const BestSellers: React.FC<BestSellersProps> = ({ products }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const productsPerSlide = 4;
  const totalSlides = Math.ceil(products.length / productsPerSlide);
  
  const nextSlide = () => {
    setCurrentSlide((prev) => 
      prev === totalSlides - 1 ? 0 : prev + 1
    );
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => 
      prev === 0 ? totalSlides - 1 : prev - 1
    );
  };

  return (
    <section className="py-8 bg-[#E3E7F0]">
      <div className="container mx-auto px-4">
        <div className="flex flex-row justify-between items-center mb-5">
          <div className="flex flex-row items-center">
            <h2 className="text-[40px] font-bold leading-[49px] tracking-tight text-[#096DFF]" 
                style={{ fontFamily: 'Century Gothic, sans-serif' }}>
              Хиты продаж
            </h2>
            
            <div className="flex items-center pl-5 ml-4 border-l border-gray-300">
              <Link 
                to="/catalog?category=keyboards" 
                className="flex justify-center items-center px-6 py-2 border border-[#212121] rounded-[10px] text-[#212121] text-sm font-medium hover:bg-[#212121] hover:text-white transition-colors">
                Клавиатуры
              </Link>
              
              <Link 
                to="/catalog?category=mice" 
                className="flex justify-center items-center px-5 py-2 border border-[#212121] rounded-[10px] text-[#212121] text-sm font-medium ml-3 hover:bg-[#212121] hover:text-white transition-colors">
                Мышки
              </Link>
            </div>
          </div>
          
          <Link 
            to="/bestsellers" 
            className="text-[#212121] font-medium text-sm hover:underline">
            Смотреть все
          </Link>
        </div>
        
        <div className="relative">
          {/* Карусель */}
          <div className="overflow-hidden">
            <div 
              className="flex transition-transform duration-300 ease-in-out"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {Array.from({ length: totalSlides }).map((_, slideIndex) => (
                <div key={slideIndex} className="w-full flex-shrink-0">
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
                    {products
                      .slice(slideIndex * productsPerSlide, (slideIndex + 1) * productsPerSlide)
                      .map(product => (
                        <VerticalProductCard 
                          key={product.id}
                          id={product.id}
                          title={product.title}
                          brand={product.brand}
                          price={product.price}
                          oldPrice={product.oldPrice}
                          rating={product.rating}
                          reviewCount={product.reviewCount}
                          image={product.image}
                          discount={product.discount}
                          inStock={product.inStock}
                          colors={product.colors}
                        />
                      ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Кнопки навигации - они расположены вне товаров */}
          <button 
            onClick={prevSlide}
            className="absolute left-0 top-1/2 transform -translate-y-1/2 -translate-x-6 bg-white rounded-full p-2 shadow-md hover:bg-gray-100 transition-colors z-10 focus:outline-none"
            aria-label="Предыдущие товары"
          >
            <ChevronLeftIcon className="h-6 w-6 text-gray-800" />
          </button>
          <button 
            onClick={nextSlide}
            className="absolute right-0 top-1/2 transform -translate-y-1/2 translate-x-6 bg-white rounded-full p-2 shadow-md hover:bg-gray-100 transition-colors z-10 focus:outline-none"
            aria-label="Следующие товары"
          >
            <ChevronRightIcon className="h-6 w-6 text-gray-800" />
          </button>
        </div>
        
        {/* Индикаторы слайдов */}
        {totalSlides > 1 && (
          <div className="flex justify-center mt-6 space-x-2">
            {Array.from({ length: totalSlides }).map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`h-2 rounded-full transition-all ${
                  currentSlide === index ? 'w-8 bg-[#096DFF]' : 'w-2 bg-gray-300'
                }`}
                aria-label={`Перейти к слайду ${index + 1}`}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default BestSellers; 