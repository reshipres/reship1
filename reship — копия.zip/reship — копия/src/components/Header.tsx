import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { UserIcon, Bars3Icon, XMarkIcon, ChevronDownIcon } from '@heroicons/react/24/outline';
import CartIcon from './icons/CartIcon';
import Search from './search/Search';
import ToolsDropdown from './ToolsDropdown';

const Header: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isToolsOpen, setIsToolsOpen] = useState(false);
  const navigate = useNavigate();

  const menuItems = [
    { title: 'Мышки', path: '/catalog/mice' },
    { title: 'Коврики', path: '/catalog/mousepads' },
    { title: 'Клавиатуры', path: '/catalog/keyboards' },
    { title: 'Гайды/Грипсы', path: '/catalog/grips' },
    { title: 'Наушники', path: '/catalog/headsets' },
    { title: 'Микрофоны', path: '/catalog/microphones' },
    { title: 'Аксессуары', path: '/catalog/accessories' },
    { title: 'Бренды', path: '/brands' },
    { title: 'Медиа советуют', path: '/players', isSpecial: true },
  ];

  const handleSearch = (query: string) => {
    if (query.trim()) {
      navigate(`/search?q=${encodeURIComponent(query)}`);
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    navigate('/');
  };

  return (
    <header className="bg-white z-40 relative">
      {/* Верхняя полоса */}
      <div className="bg-[#212121] text-white py-2">
        <div className="container flex justify-between items-center">
          <div className="flex flex-wrap items-center space-x-6">
            <Link to="/delivery" className="text-sm hover:text-gray-300">Доставка и оплата</Link>
            <Link to="/gift-cards" className="text-sm hover:text-gray-300">Подарочные карты</Link>
            <Link to="/help" className="text-sm hover:text-gray-300">Помощь в подборе</Link>
            <Link to="/contacts" className="text-sm hover:text-gray-300">Контакты</Link>
          </div>
          <div className="text-sm flex items-center">
            <span className="text-gray-400 mr-2">Есть вопросы? Звоните:</span>
            <a href="tel:+79213330701" className="font-medium hover:text-gray-300">+7 921 333 07 01</a>
          </div>
        </div>
      </div>
      
      {/* Основной заголовок - точные размеры из Figma */}
      <div className="container py-3">
        <div className="flex items-center" style={{ gap: '48.49px' }}>
          {/* Логотип - точные размеры */}
          <Link to="/" className="inline-block">
            <img src="/images/reship.png" alt="RESHIP" style={{ width: '100px', height: 'auto' }} />
          </Link>

          {/* Поисковая строка - точные размеры и стили */}
          <div style={{ width: '657px' }}>
            <Search 
              onSearch={handleSearch} 
            />
          </div>

          {/* Уцененные и Блог - точное позиционирование */}
          <div className="flex" style={{ gap: '28.72px' }}>
            <Link to="/discount" style={{ 
              fontFamily: 'Roboto', 
              fontWeight: 400,
              fontSize: '18.8px',
              lineHeight: '22px',
              color: '#000000'
            }}>
              Уцененные
            </Link>
            <Link to="/blog" style={{ 
              fontFamily: 'Roboto', 
              fontWeight: 400,
              fontSize: '18.8px',
              lineHeight: '22px',
              color: '#000000'
            }}>
              Блог
            </Link>
            <Link to="/brands" style={{ 
              fontFamily: 'Roboto', 
              fontWeight: 400,
              fontSize: '18.8px',
              lineHeight: '22px',
              color: '#000000'
            }}>
              Бренды
            </Link>
          </div>

          {/* Инструменты и корзина с профилем - точные размеры */}
          <div className="flex items-center ml-auto" style={{ gap: '29px' }}>
            {/* Инструменты */}
            <div className="relative">
              <button 
                className="flex items-center justify-between"
                onClick={() => setIsToolsOpen(!isToolsOpen)}
                style={{ 
                  width: '160.31px',
                  height: '36.61px',
                  border: '2.39345px solid #4993FF',
                  borderRadius: '11.97px',
                  padding: '8.38px 16.75px'
                }}
              >
                <span style={{
                  fontFamily: 'Roboto',
                  fontWeight: 600,
                  fontSize: '16.82px',
                  lineHeight: '20px',
                  color: '#4993FF'
                }}>Инструменты</span>
                <ChevronDownIcon style={{ width: '11px', height: '11px', color: '#4993FF' }} />
              </button>
              
              {isToolsOpen && (
                <ToolsDropdown onClose={() => setIsToolsOpen(false)} />
              )}
            </div>
            
            {/* Корзина и профиль */}
            <div className="flex items-center" style={{ gap: '14.84px' }}>
              {/* Корзина с счетчиком */}
              <Link to="/cart" className="relative">
                <div style={{ width: '38.24px', height: '33.58px', position: 'relative' }}>
                  <img 
                    src="/images/iconcart.png" 
                    alt="Корзина" 
                    className="w-[32.71px] h-[32.71px]" 
                  />
                  <span className="absolute -top-[2px] -right-[2px] w-[17px] h-[17px] bg-[#096DFF] text-white text-[10px] rounded-full flex items-center justify-center font-normal">9+</span>
                </div>
              </Link>
              
              {/* Профиль */}
              <div className="relative">
                <Link to={isLoggedIn ? "/account" : "/login"}>
                  <div style={{ width: '33.58px', height: '33.58px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <img 
                      src="/images/iconprofile.png" 
                      alt="Профиль" 
                      className="w-[29px] h-[29px]" 
                    />
                  </div>
                </Link>
              </div>
            </div>
            
            {/* Мобильное меню */}
            <button 
              className="md:hidden focus:outline-none ml-2"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? (
                <XMarkIcon className="h-6 w-6 text-secondary" />
              ) : (
                <Bars3Icon className="h-6 w-6 text-secondary" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Навигация по категориям */}
      <div className="bg-[#E3E7F0] py-[12px]">
        <div className="container">
          <nav>
            <div className="flex items-start justify-start w-full overflow-x-auto hide-scrollbar" style={{ gap: '28.7px' }}>
              <Link to="/catalog/mice" className="relative">
                <div className="whitespace-nowrap text-[#212121]" style={{ 
                  fontFamily: 'Century Gothic', 
                  fontWeight: 'bold',
                  fontSize: '18.8px',
                  lineHeight: '23px'
                }}>
                  Мышки
                </div>
              </Link>
              
              <Link to="/catalog/mousepads" className="relative">
                <div className="whitespace-nowrap text-[#212121]" style={{ 
                  fontFamily: 'Century Gothic', 
                  fontWeight: 'bold',
                  fontSize: '18.8px',
                  lineHeight: '23px'
                }}>
                  Коврики
                </div>
              </Link>
              
              <Link to="/catalog/keyboards" className="relative">
                <div className="whitespace-nowrap text-[#212121]" style={{ 
                  fontFamily: 'Century Gothic', 
                  fontWeight: 'bold',
                  fontSize: '18.8px',
                  lineHeight: '23px'
                }}>
                  Клавиатуры
                </div>
              </Link>
              
              <Link to="/catalog/grips" className="relative">
                <div className="whitespace-nowrap text-[#212121]" style={{ 
                  fontFamily: 'Century Gothic', 
                  fontWeight: 'bold',
                  fontSize: '18.8px',
                  lineHeight: '23px'
                }}>
                  Глайды/Грипсы
                </div>
              </Link>
              
              <Link to="/catalog/headsets" className="relative">
                <div className="whitespace-nowrap text-[#212121]" style={{ 
                  fontFamily: 'Century Gothic', 
                  fontWeight: 'bold',
                  fontSize: '18.8px',
                  lineHeight: '23px'
                }}>
                  Наушники
                </div>
              </Link>
              
              <Link to="/catalog/microphones" className="relative">
                <div className="whitespace-nowrap text-[#212121]" style={{ 
                  fontFamily: 'Century Gothic', 
                  fontWeight: 'bold',
                  fontSize: '18.8px',
                  lineHeight: '23px'
                }}>
                  Микрофоны
                </div>
              </Link>
              
              <Link to="/catalog/accessories" className="relative">
                <div className="whitespace-nowrap text-[#212121]" style={{ 
                  fontFamily: 'Century Gothic', 
                  fontWeight: 'bold',
                  fontSize: '18.8px',
                  lineHeight: '23px'
                }}>
                  Аксессуары
                </div>
              </Link>
              
              <Link to="/players" className="relative">
                <div className="whitespace-nowrap text-[#096DFF]" style={{ 
                  fontFamily: 'Century Gothic', 
                  fontWeight: 'bold',
                  fontSize: '18.8px',
                  lineHeight: '23px'
                }}>
                  Медиа советуют
                </div>
              </Link>
            </div>
          </nav>
        </div>
      </div>

      {/* Мобильное меню */}
      {isMenuOpen && (
        <div className="md:hidden bg-white pt-2 pb-4 border-t border-gray-200">
          <div className="container">
            <div className="mb-4">
              <Search onSearch={handleSearch} />
            </div>
            
            <div className="flex flex-col space-y-3">
              {menuItems.map((item, index) => (
                <Link 
                  key={index}
                  to={item.path}
                  className={`block py-2 ${item.isSpecial ? 'text-[#096DFF]' : 'text-[#212121]'} hover:opacity-80 transition-opacity`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.title}
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;