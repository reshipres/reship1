import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { addToCart } from '../../store/slices/cartSlice';
import { addToFavorite, removeFromFavorite } from '../../store/slices/favoriteSlice';
import { toast } from 'react-hot-toast';
import Rating from './Rating';

// Тип для опций цвета
interface ColorOption {
  id: string;
  name: string;
  color: string;
}

// Тип для опций переключателей
interface SwitchOption {
  id: string;
  name: string;
  color: string;
}

// Интерфейс для данных о товаре
interface ProductInfoProps {
  id: number;
  title: string;
  brand: string;
  price: number;
  oldPrice?: number;
  discount?: number;
  rating: number;
  reviewCount: number;
  availability: string;
  isFavorite: boolean;
  category?: string;
  categoryUrl?: string;
  switchOptions?: SwitchOption[];
  colorOptions?: ColorOption[];
  onReviewsClick?: () => void;
}

const ProductInfo: React.FC<ProductInfoProps> = ({
  id,
  title,
  brand,
  price,
  oldPrice,
  discount,
  rating,
  reviewCount,
  availability,
  isFavorite,
  category = 'Клавиатуры',
  categoryUrl = '/catalog/keyboards',
  switchOptions = [],
  colorOptions = [],
  onReviewsClick
}) => {
  const dispatch = useDispatch();
  
  // Состояния
  const [selectedSwitch, setSelectedSwitch] = useState<string>(
    switchOptions.length > 0 ? switchOptions[0].id : ''
  );
  const [selectedColor, setSelectedColor] = useState<string>(
    colorOptions.length > 0 ? colorOptions[2].id : ''
  );
  const [selectedLayout, setSelectedLayout] = useState<string>('ru');
  const [quantity, setQuantity] = useState<number>(1);
  
  // Стили компонента
  const styles = {
    container: {
      display: 'flex', 
      flexDirection: 'column' as const, 
      width: '430px',
      height: 'auto',
      padding: '0px',
      gap: '0px',
      flex: 'none',
      order: 1,
      flexGrow: 0
    },
    innerContainer: {
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'flex-start',
      padding: '0px',
      gap: '13px',
      width: '100%',
      flex: 'none',
      order: 0,
      alignSelf: 'stretch',
      flexGrow: 0
    },
    contentFrame: {
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'flex-start',
      padding: '0px',
      gap: '20px',
      width: '100%',
      flex: 'none',
      order: 0,
      alignSelf: 'stretch',
      flexGrow: 0
    },
    header: {
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'flex-start',
      padding: '0px',
      gap: '13px',
      width: '100%',
      flex: 'none',
      order: 0,
      alignSelf: 'stretch',
      flexGrow: 0
    },
    topInfoBlock: {
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'flex-start',
      padding: '0px',
      gap: '13px',
      width: '100%',
      flex: 'none',
      order: 0,
      alignSelf: 'stretch',
      flexGrow: 0
    },
    titleBlock: {
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'flex-start',
      padding: '0px',
      width: '100%',
      flex: 'none',
      order: 0,
      alignSelf: 'stretch',
      flexGrow: 0
    },
    categoryLink: {
      width: '100%',
      height: '17px',
      fontFamily: 'Inter, sans-serif',
      fontStyle: 'normal',
      fontWeight: 600,
      fontSize: '14px',
      lineHeight: '17px',
      color: '#5F5F5F',
      textDecoration: 'none',
      transition: 'color 0.2s',
      flex: 'none',
      order: 0,
      alignSelf: 'stretch',
      flexGrow: 0
    },
    title: {
      width: '100%',
      height: '90px',
      fontFamily: 'Century Gothic, sans-serif',
      fontStyle: 'normal',
      fontWeight: 700,
      fontSize: '40px',
      lineHeight: '49px',
      letterSpacing: '-0.01em',
      color: '#212121',
      flex: 'none',
      order: 1,
      alignSelf: 'stretch',
      flexGrow: 0
    },
    ratingContainer: {
      display: 'flex',
      flexDirection: 'row' as const,
      alignItems: 'center',
      padding: '0px',
      gap: '8px',
      width: '188.14px',
      height: '26px',
      flex: 'none',
      order: 1,
      flexGrow: 0,
      cursor: 'pointer'
    },
    reviewCount: {
      width: '85px',
      height: '26px',
      fontFamily: 'Inter, sans-serif',
      fontStyle: 'normal',
      fontWeight: 500,
      fontSize: '14px',
      lineHeight: '26px',
      color: '#383838',
      flex: 'none',
      order: 1,
      flexGrow: 0
    },
    optionsContainer: {
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'flex-start',
      padding: '0px',
      gap: '24px',
      width: '100%',
      flex: 'none',
      order: 1,
      flexGrow: 0
    },
    optionsRow: {
      display: 'flex',
      flexDirection: 'row' as const,
      alignItems: 'flex-start',
      width: '100%',
      gap: '30px',
      flex: 'none',
      order: 0,
      flexGrow: 0
    },
    colorBlock: {
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'flex-start',
      padding: '0px',
      gap: '6px',
      width: '89px',
      height: '50px',
      flex: 'none',
      order: 0,
      flexGrow: 0
    },
    layoutBlock: {
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'flex-start',
      padding: '0px',
      gap: '6px',
      width: '110px',
      height: '50px',
      flex: 'none',
      order: 1,
      flexGrow: 0
    },
    optionTitle: {
      width: '100%',
      height: '19px',
      fontFamily: 'Roboto, sans-serif',
      fontStyle: 'normal',
      fontWeight: 500,
      fontSize: '16px',
      lineHeight: '19px',
      color: '#292929',
      flex: 'none',
      order: 0,
      alignSelf: 'stretch',
      flexGrow: 0
    },
    colorOptions: {
      display: 'flex',
      flexDirection: 'row' as const,
      alignItems: 'center',
      padding: '0px',
      gap: '7px',
      width: '89px',
      height: '25px',
      flex: 'none',
      order: 1,
      alignSelf: 'stretch',
      flexGrow: 0
    },
    colorButton: {
      width: '25px',
      height: '25px',
      borderRadius: '4px',
      border: 'none',
      cursor: 'pointer',
      flex: 'none',
      flexGrow: 0
    },
    layoutOptions: {
      display: 'flex',
      flexDirection: 'row' as const,
      alignItems: 'center',
      padding: '0px',
      gap: '7px',
      width: '110px',
      height: '25px',
      flex: 'none',
      order: 1,
      flexGrow: 0
    },
    layoutButton: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: '50px',
      height: '25px',
      paddingTop: '1px',
      borderRadius: '4px',
      border: '2px solid #e5e7eb',
      fontFamily: 'Roboto, sans-serif',
      fontWeight: 500,
      fontSize: '14px',
      color: '#212121',
      cursor: 'pointer',
      flex: 'none',
      flexGrow: 0,
      backgroundColor: 'transparent'
    },
    switchOptionsContainer: {
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'flex-start',
      padding: '0px',
      gap: '8px',
      width: '100%',
      flex: 'none',
      order: 1,
      alignSelf: 'stretch',
      flexGrow: 0
    },
    switchOptionsHeader: {
      display: 'flex',
      flexDirection: 'row' as const,
      alignItems: 'flex-end',
      padding: '0px',
      gap: '4px',
      width: '142px',
      height: '19px',
      flex: 'none',
      order: 0,
      flexGrow: 0
    },
    switchesTitle: {
      width: '121px',
      height: '19px',
      fontFamily: 'Roboto, sans-serif',
      fontStyle: 'normal',
      fontWeight: 500,
      fontSize: '16px',
      lineHeight: '19px',
      color: '#292929',
      flex: 'none',
      order: 0,
      flexGrow: 0
    },
    infoIcon: {
      width: '17px',
      height: '17px',
      flex: 'none',
      order: 1,
      flexGrow: 0,
      position: 'relative' as const
    },
    switchOptions: {
      display: 'flex',
      flexDirection: 'row' as const,
      flexWrap: 'wrap' as const,
      alignItems: 'flex-start',
      alignContent: 'flex-start',
      padding: '0px',
      gap: '8px 9px',
      width: '100%',
      flex: 'none',
      order: 1,
      alignSelf: 'stretch',
      flexGrow: 0
    },
    switchButton: {
      boxSizing: 'border-box' as const,
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'flex-start',
      padding: '6px',
      gap: '10px',
      height: '30px',
      border: '2px solid #e5e7eb',
      borderRadius: '4px',
      flex: 'none',
      flexGrow: 0,
      cursor: 'pointer'
    },
    switchButtonInner: {
      display: 'flex',
      flexDirection: 'row' as const,
      alignItems: 'center',
      padding: '0px',
      gap: '6px',
      height: '18px',
      flex: 'none',
      order: 0,
      flexGrow: 0
    },
    switchColor: {
      width: '18px',
      height: '18px',
      borderRadius: '3px',
      flex: 'none',
      order: 0,
      flexGrow: 0
    },
    switchName: {
      fontFamily: 'Roboto, sans-serif',
      fontStyle: 'normal',
      fontWeight: 500,
      fontSize: '14px',
      lineHeight: '16px',
      color: '#212121',
      flex: 'none',
      order: 1,
      flexGrow: 0
    },
    priceContainer: {
      display: 'flex',
      flexDirection: 'row' as const,
      alignItems: 'center',
      padding: '0px',
      gap: '9px',
      width: '238px',
      height: '29px',
      flex: 'none',
      order: 1,
      flexGrow: 0,
      marginTop: '10px'
    },
    discountBadge: {
      width: '48px',
      height: '25px',
      backgroundColor: '#096DFF',
      borderRadius: '5px',
      position: 'relative' as const,
      flex: 'none',
      order: 0,
      flexGrow: 0
    },
    discountText: {
      position: 'absolute' as const,
      width: '39px',
      height: '19px',
      left: '7px',
      top: '3px',
      fontFamily: 'Inter, sans-serif',
      fontStyle: 'normal',
      fontWeight: 600,
      fontSize: '16px',
      lineHeight: '19px',
      color: 'white'
    },
    currentPrice: {
      width: '103px',
      height: '29px',
      fontFamily: 'Inter, sans-serif',
      fontStyle: 'normal',
      fontWeight: 600,
      fontSize: '24px',
      lineHeight: '29px',
      color: '#000000',
      flex: 'none',
      order: 1,
      flexGrow: 0
    },
    oldPriceContainer: {
      width: '69px',
      height: '19px',
      flex: 'none',
      order: 2,
      flexGrow: 0,
      position: 'relative' as const
    },
    oldPrice: {
      position: 'absolute' as const,
      width: '69px',
      height: '19px',
      left: '0',
      top: '5px',
      fontFamily: 'Inter, sans-serif',
      fontStyle: 'normal',
      fontWeight: 600,
      fontSize: '16px',
      lineHeight: '19px',
      color: '#8E8E8E'
    },
    oldPriceLine: {
      position: 'absolute' as const,
      width: '65px',
      height: '0px',
      left: '2px',
      top: '15px',
      border: '1px solid #8E8E8E'
    },
    actionsContainer: {
      display: 'flex',
      flexDirection: 'row' as const,
      alignItems: 'center',
      padding: '0px',
      gap: '8px',
      width: '100%',
      height: '57px',
      flex: 'none',
      order: 1,
      alignSelf: 'stretch',
      flexGrow: 0,
      marginTop: '5px'
    },
    addToCartButton: {
      width: '310px',
      height: '57px',
      backgroundColor: '#212121',
      borderRadius: '7px',
      position: 'relative' as const,
      border: 'none',
      cursor: 'pointer',
      flex: 'none',
      order: 0,
      flexGrow: 0
    },
    addToCartText: {
      position: 'absolute' as const,
      width: '153px',
      height: '20px',
      left: '78px',
      top: '19px',
      fontFamily: 'Roboto, sans-serif',
      fontStyle: 'normal',
      fontWeight: 500,
      fontSize: '16px',
      lineHeight: '19px',
      textAlign: 'center' as const,
      color: 'white'
    },
    quantityContainer: {
      boxSizing: 'border-box' as const,
      width: '83px',
      height: '57px',
      border: '2px solid #212121',
      borderRadius: '10px',
      position: 'relative' as const,
      flex: 'none',
      order: 1,
      flexGrow: 0
    },
    quantityButton: {
      fontFamily: 'Roboto, sans-serif',
      fontStyle: 'normal',
      fontWeight: 500,
      fontSize: '16px',
      lineHeight: '19px',
      color: '#212121',
      backgroundColor: 'transparent',
      border: 'none',
      cursor: 'pointer',
      position: 'absolute' as const
    },
    quantityDecrease: {
      left: '15px',
      top: '19px'
    },
    quantityIncrease: {
      right: '15px',
      top: '19px'
    },
    quantityText: {
      position: 'absolute' as const,
      left: '40px',
      top: '19px',
      fontFamily: 'Roboto, sans-serif',
      fontStyle: 'normal',
      fontWeight: 500,
      fontSize: '16px',
      lineHeight: '19px',
      color: '#212121'
    },
    infoContainer: {
      display: 'flex',
      flexDirection: 'row' as const,
      alignItems: 'center',
      padding: '0px',
      gap: '15px',
      width: '100%',
      height: '34px',
      flex: 'none',
      order: 2,
      alignSelf: 'stretch',
      flexGrow: 0,
      marginTop: '10px'
    },
    infoItem: {
      display: 'flex',
      flexDirection: 'row' as const,
      alignItems: 'center',
      gap: '8px',
      flex: 'none',
      flexGrow: 0
    },
    infoDot: {
      width: '8px',
      height: '8px',
      backgroundColor: '#096DFF',
      borderRadius: '50%'
    },
    quantityInfo: {
      fontFamily: 'Roboto, sans-serif',
      fontStyle: 'normal',
      fontWeight: 500,
      fontSize: '14px',
      lineHeight: '16px',
      color: '#383838'
    },
    divider: {
      width: '2px',
      height: '20px',
      backgroundColor: '#212121',
      transform: 'rotate(0deg)',
      flex: 'none',
      flexGrow: 0
    },
    deliveryInfo: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      flex: 'none',
      flexGrow: 0
    },
    deliveryIcon: {
      width: '20px',
      height: '17px',
      marginTop: '-2px'
    },
    deliveryText: {
      fontFamily: 'Roboto, sans-serif',
      fontStyle: 'normal',
      fontWeight: 500,
      fontSize: '14px',
      lineHeight: '16px',
      color: '#4D4D4D'
    }
  };

  // Обработчики событий
  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value > 0) {
      setQuantity(value);
    }
  };

  const incrementQuantity = () => {
    setQuantity(prev => prev + 1);
  };

  const decrementQuantity = () => {
    setQuantity(prev => (prev > 1 ? prev - 1 : 1));
  };

  const handleToggleFavorite = () => {
    if (isFavorite) {
      dispatch(removeFromFavorite(id));
      toast.success('Товар удален из избранного');
    } else {
      dispatch(addToFavorite({
        id,
        title,
        brand,
        price,
        oldPrice,
        discount,
        rating,
        reviewCount,
        image: '', // Здесь должен быть URL изображения
        inStock: availability === 'В наличии'
      }));
      toast.success('Товар добавлен в избранное');
    }
  };

  const handleAddToCart = () => {
    dispatch(addToCart({
      product: {
        id,
        title,
        brand,
        price,
        oldPrice,
        rating,
        reviewCount,
        image: '', // Здесь должен быть URL изображения
        discount,
        inStock: availability === 'В наличии'
      },
      quantity,
      selectedColor,
      selectedSwitch
    }));
    toast.success('Товар добавлен в корзину');
  };
  
  return (
    <div style={styles.container}>
      <div style={styles.innerContainer}>
        <div style={styles.contentFrame}>
          <div style={styles.header}>
            {/* Заголовок и категория */}
            <div style={styles.topInfoBlock}>
              <div style={styles.titleBlock}>
                <Link to={categoryUrl} style={styles.categoryLink}>{category}</Link>
                <h1 style={styles.title}>{title}</h1>
              </div>
              
              {/* Рейтинг и отзывы */}
              <div style={styles.ratingContainer} onClick={onReviewsClick}>
                <Rating rating={rating} />
                <span style={styles.reviewCount}>{reviewCount} отзывов</span>
              </div>
            </div>
            
            {/* Блоки опций */}
            <div style={styles.optionsContainer}>
              {/* Блоки цвета и раскладки в одной строке */}
              <div style={styles.optionsRow}>
                {/* Блок цвета */}
                {colorOptions.length > 0 && (
                  <div style={styles.colorBlock}>
                    <span style={styles.optionTitle}>Цвет</span>
                    <div style={styles.colorOptions}>
                      {colorOptions.map(option => (
                        <button 
                          key={option.id}
                          style={{
                            ...styles.colorButton,
                            backgroundColor: option.color,
                            border: selectedColor === option.id ? '2px solid #212121' : 'none',
                            order: option.id === 'white' ? 0 : option.id === 'black' ? 1 : 2
                          }}
                          onClick={() => setSelectedColor(option.id)}
                          aria-label={option.name}
                        />
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Блок раскладки */}
                <div style={styles.layoutBlock}>
                  <span style={styles.optionTitle}>Раскладка</span>
                  <div style={styles.layoutOptions}>
                    <button 
                      style={{
                        ...styles.layoutButton,
                        border: selectedLayout === 'en' ? '2px solid #212121' : '2px solid #e5e7eb',
                        backgroundColor: selectedLayout === 'en' ? '#f0f0f0' : 'transparent'
                      }}
                      onClick={() => setSelectedLayout('en')}
                    >
                      EN
                    </button>
                    <button 
                      style={{
                        ...styles.layoutButton,
                        border: selectedLayout === 'ru' ? '2px solid #212121' : '2px solid #e5e7eb',
                        backgroundColor: selectedLayout === 'ru' ? '#f0f0f0' : 'transparent'
                      }}
                      onClick={() => setSelectedLayout('ru')}
                    >
                      RU
                    </button>
                  </div>
                </div>
              </div>
              
              {/* Блок переключателей */}
              {switchOptions.length > 0 && (
                <div style={styles.switchOptionsContainer}>
                  <div style={styles.switchOptionsHeader}>
                    <span style={styles.switchesTitle}>Переключатели</span>
                    <div style={styles.infoIcon}>
                      <div style={{ 
                        position: 'absolute', 
                        width: '17px', 
                        height: '17px', 
                        backgroundColor: '#292929', 
                        borderRadius: '50%' 
                      }}></div>
                      <div style={{ 
                        position: 'absolute', 
                        width: '3px', 
                        height: '3px', 
                        backgroundColor: 'white', 
                        borderRadius: '50%',
                        left: '7px',
                        top: '3px'
                      }}></div>
                      <div style={{ 
                        position: 'absolute', 
                        width: '4.86px', 
                        height: '0px', 
                        border: '2.4px solid white',
                        transform: 'rotate(90deg)',
                        left: '5px',
                        top: '10px'
                      }}></div>
                    </div>
                  </div>
                  <div style={styles.switchOptions}>
                    {switchOptions.map((option, index) => (
                      <button 
                        key={option.id}
                        style={{
                          ...styles.switchButton,
                          width: option.id === 'red' ? '172px' : '149px',
                          padding: option.id === 'black' ? '6px 7px' : '6px',
                          border: selectedSwitch === option.id ? '2px solid #212121' : '2px solid #e5e7eb',
                          backgroundColor: selectedSwitch === option.id ? '#F8F8F8' : 'transparent'
                        }}
                        onClick={() => setSelectedSwitch(option.id)}
                      >
                        <div style={styles.switchButtonInner}>
                          <div style={{ 
                            ...styles.switchColor, 
                            backgroundColor: option.color 
                          }}></div>
                          <span style={{
                            ...styles.switchName,
                            width: option.id === 'red' ? '133px' : option.id === 'black' ? '105px' : '110px'
                          }}>
                            {option.name}
                          </span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
            
            {/* Цена и скидка */}
            {price && (
              <div style={styles.priceContainer}>
                {discount && discount > 0 && (
                  <div style={styles.discountBadge}>
                    <span style={styles.discountText}>-{discount}%</span>
                  </div>
                )}
                <span style={styles.currentPrice}>{price.toLocaleString()} ₽</span>
                {oldPrice && oldPrice > price && (
                  <div style={styles.oldPriceContainer}>
                    <span style={styles.oldPrice}>{oldPrice.toLocaleString()} ₽</span>
                    <div style={styles.oldPriceLine}></div>
                  </div>
                )}
              </div>
            )}
          </div>
          
          {/* Кнопки Добавить в корзину и счетчик */}
          <div style={styles.actionsContainer}>
            <button
              style={styles.addToCartButton}
              onClick={handleAddToCart}
              className="hover:bg-black"
            >
              <span style={styles.addToCartText}>Добавить в корзину</span>
            </button>
            
            <div style={styles.quantityContainer}>
              <button
                style={{...styles.quantityButton, ...styles.quantityDecrease}}
                onClick={decrementQuantity}
                disabled={quantity <= 1}
              >
                -
              </button>
              <span style={styles.quantityText}>{quantity}</span>
              <button
                style={{...styles.quantityButton, ...styles.quantityIncrease}}
                onClick={incrementQuantity}
              >
                +
              </button>
            </div>
          </div>
          
          {/* Информация о доставке */}
          <div style={styles.infoContainer}>
            <div style={styles.infoItem}>
              <div style={styles.infoDot}></div>
              <span style={styles.quantityInfo}>Количество товара: {quantity} шт</span>
            </div>
            
            <div style={styles.divider}></div>
            
            <div style={styles.deliveryInfo}>
              <div style={styles.deliveryIcon}>
                <svg 
                  width="20" 
                  height="17" 
                  viewBox="0 0 20 17" 
                  fill="none" 
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path d="M14 5H2V13H14V5ZM15 2H1C0.45 2 0 2.45 0 3V14C0 14.55 0.45 15 1 15H15C15.55 15 16 14.55 16 14V3C16 2.45 15.55 2 15 2ZM11 4C11.55 4 12 3.55 12 3C12 2.45 11.55 2 11 2C10.45 2 10 2.45 10 3C10 3.55 10.45 4 11 4ZM14 3C14 2.45 13.55 2 13 2C12.45 2 12 2.45 12 3C12 3.55 12.45 4 13 4C13.55 4 14 3.55 14 3Z" fill="#4D4D4D"/>
                </svg>
              </div>
              <span style={styles.deliveryText}>
                Доставка по всей РФ <a href="#" style={{ color: '#096DFF' }}>Подробнее</a>
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductInfo; 