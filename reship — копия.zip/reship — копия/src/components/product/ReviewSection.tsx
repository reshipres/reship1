import React, { useState, useMemo } from 'react';
import { HandThumbUpIcon, HandThumbDownIcon } from '@heroicons/react/24/outline';
import { StarIcon } from '@heroicons/react/24/outline';
import { StarIcon as StarSolidIcon } from '@heroicons/react/24/solid';
import { toast } from 'react-hot-toast';
import Rating from './Rating';
import { Review, ReviewsStats } from '../../types/reviews';

interface ReviewSectionProps {
  productId: number;
  reviews: Review[];
  stats: ReviewsStats;
  onWriteReview: () => void;
}

const ReviewSection: React.FC<ReviewSectionProps> = ({
  productId,
  reviews,
  stats,
  onWriteReview
}) => {
  // Состояния для сортировки и фильтрации
  const [reviewSort, setReviewSort] = useState<string>('newest');
  const [reviewFilter, setReviewFilter] = useState<string>('all');
  const [updatedReviews, setUpdatedReviews] = useState<Review[]>(reviews);
  
  // Мемоизация отсортированных и отфильтрованных отзывов
  const displayedReviews = useMemo(() => {
    // Функция сортировки
    const sortReviews = (reviewsToSort: Review[]) => {
      switch (reviewSort) {
        case 'newest':
          return [...reviewsToSort].sort((a, b) => 
            new Date(b.date).getTime() - new Date(a.date).getTime()
          );
        case 'oldest':
          return [...reviewsToSort].sort((a, b) => 
            new Date(a.date).getTime() - new Date(b.date).getTime()
          );
        case 'highest':
          return [...reviewsToSort].sort((a, b) => b.rating - a.rating);
        case 'lowest':
          return [...reviewsToSort].sort((a, b) => a.rating - b.rating);
        case 'helpful':
          return [...reviewsToSort].sort((a, b) => b.helpfulCount - a.helpfulCount);
        default:
          return reviewsToSort;
      }
    };
    
    // Функция фильтрации
    const filterReviews = (reviewsToFilter: Review[]) => {
      switch (reviewFilter) {
        case 'positive':
          return reviewsToFilter.filter(review => review.rating >= 4);
        case 'negative':
          return reviewsToFilter.filter(review => review.rating <= 2);
        case 'with-photos':
          return reviewsToFilter.filter(review => review.photos && review.photos.length > 0);
        default:
          return reviewsToFilter;
      }
    };
    
    // Применяем сортировку и фильтрацию
    return sortReviews(filterReviews(updatedReviews));
  }, [updatedReviews, reviewSort, reviewFilter]);
  
  // Обработчик оценки полезности отзыва
  const handleReviewHelpful = (reviewId: string, helpful: boolean) => {
    setUpdatedReviews(
      updatedReviews.map(review => {
        if (review.id === reviewId) {
          if (helpful) {
            return { ...review, helpfulCount: review.helpfulCount + 1 };
          } else {
            return { ...review, unhelpfulCount: review.unhelpfulCount + 1 };
          }
        }
        return review;
      })
    );
    toast.success(helpful ? 'Спасибо за вашу оценку!' : 'Спасибо за ваш отзыв!');
  };
  
  // Стили компонента
  const styles = {
    mainContainer: {
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'flex-start',
      padding: '0px',
      gap: '22px',
      width: '100%',
      height: 'auto',
      minHeight: '720px',
      fontFamily: 'Roboto, sans-serif'
    },
    header: {
      display: 'flex',
      width: '100%',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '15px',
      fontFamily: 'Roboto, sans-serif'
    },
    title: {
      fontFamily: 'Century Gothic, sans-serif',
      fontWeight: 700,
      fontSize: '22px',
      lineHeight: '26px',
      color: '#212121'
    },
    writeReviewBtn: {
      backgroundColor: '#096DFF',
      color: 'white',
      padding: '8px 20px',
      borderRadius: '6px',
      fontSize: '14px',
      fontWeight: 500 as const,
      border: 'none',
      cursor: 'pointer',
      fontFamily: 'Roboto, sans-serif',
      transition: 'background-color 0.2s'
    },
    topSection: {
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'flex-start',
      padding: '0px',
      gap: '29px',
      width: '100%',
      maxWidth: '472px',
      height: 'auto'
    },
    reviewsCountContainer: {
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'flex-start',
      padding: '0px',
      width: '100%',
      maxWidth: '222px',
      height: '62px'
    },
    reviewsCount: {
      width: '100%',
      height: '22px',
      fontFamily: 'Inter, sans-serif',
      fontStyle: 'normal',
      fontWeight: 500,
      fontSize: '18px',
      lineHeight: '22px',
      letterSpacing: '-0.01em',
      color: '#646464'
    },
    ratingContainer: {
      display: 'flex',
      flexDirection: 'row' as const,
      alignItems: 'center',
      padding: '0px',
      gap: '7px',
      width: '100%',
      maxWidth: '222px',
      height: '40px'
    },
    ratingValue: {
      width: '46px',
      height: '40px',
      fontFamily: 'Gilroy-Bold, sans-serif',
      fontStyle: 'normal',
      fontWeight: 400,
      fontSize: '32px',
      lineHeight: '40px',
      letterSpacing: '-0.01em',
      color: '#212121'
    },
    starsWrapper: {
      width: '168px',
      height: '31.78px'
    },
    filtersContainer: {
      display: 'flex',
      flexDirection: 'row' as const,
      alignItems: 'center',
      padding: '0px',
      gap: '12px',
      width: '100%',
      maxWidth: '472px',
      height: 'auto',
      flexWrap: 'wrap' as const
    },
    filterButton: {
      boxSizing: 'border-box' as const,
      position: 'relative' as const,
      height: '31px',
      border: '2px solid #212121',
      borderRadius: '7px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer'
    },
    filterButtonActive: {
      boxSizing: 'border-box' as const,
      position: 'relative' as const,
      height: '31px',
      border: '2px solid #096DFF',
      borderRadius: '7px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer'
    },
    filterButtonLabel: {
      fontFamily: 'Roboto, sans-serif',
      fontStyle: 'normal',
      fontWeight: 500,
      fontSize: '16px',
      lineHeight: '19px',
      letterSpacing: '-0.01em',
      color: '#212121',
      padding: '0 10px',
      whiteSpace: 'nowrap' as const
    },
    filterButtonLabelActive: {
      fontFamily: 'Roboto, sans-serif',
      fontStyle: 'normal',
      fontWeight: 500,
      fontSize: '16px',
      lineHeight: '19px',
      letterSpacing: '-0.01em',
      color: '#096DFF',
      padding: '0 10px',
      whiteSpace: 'nowrap' as const
    },
    reviewsContainer: {
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'flex-start',
      padding: '22px 23px',
      gap: '10px',
      width: '100%',
      backgroundColor: '#FFFFFF',
      borderRadius: '6px'
    },
    reviewsContent: {
      display: 'flex',
      flexDirection: 'row' as const,
      alignItems: 'flex-start',
      padding: '0px',
      gap: '40px',
      width: '100%'
    },
    reviewItem: {
      marginBottom: '30px',
      position: 'relative' as const,
      width: '100%'
    },
    reviewAuthorSection: {
      display: 'flex',
      flexDirection: 'row' as const,
      alignItems: 'flex-start',
      padding: '0px',
      gap: '27px',
      width: '100%',
      maxWidth: '282px',
      height: 'auto'
    },
    authorAvatar: {
      width: '79px',
      height: '79px',
      borderRadius: '6px',
      backgroundColor: '#f3f4f6',
      flexShrink: 0
    },
    authorInfoContainer: {
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'flex-start',
      padding: '0px',
      gap: '3px',
      width: '100%',
      maxWidth: '176px',
      height: 'auto'
    },
    authorNameContainer: {
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'flex-start',
      padding: '0px',
      gap: '1px',
      width: '100%',
      height: 'auto'
    },
    authorName: {
      width: '100%',
      height: 'auto',
      fontFamily: 'Century Gothic, sans-serif',
      fontStyle: 'normal',
      fontWeight: 700,
      fontSize: '18px',
      lineHeight: '22px',
      letterSpacing: '-0.01em',
      color: '#212121',
      marginBottom: '5px'
    },
    reviewDate: {
      width: '100%',
      height: 'auto',
      fontFamily: 'Inter, sans-serif',
      fontStyle: 'normal',
      fontWeight: 400,
      fontSize: '14px',
      lineHeight: '26px',
      color: '#3A3A3A'
    },
    reviewContentContainer: {
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'flex-start',
      padding: '0px',
      gap: '36px',
      width: '100%',
      maxWidth: '651px'
    },
    reviewText: {
      width: '100%',
      height: 'auto',
      fontFamily: 'Roboto, sans-serif',
      fontStyle: 'normal',
      fontWeight: 400,
      fontSize: '16px',
      lineHeight: '22px',
      color: '#212121'
    },
    responseContainer: {
      boxSizing: 'border-box' as const,
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'flex-start',
      padding: '17px 23px',
      gap: '10px',
      width: '100%',
      backgroundColor: '#E3E7F0',
      borderLeft: '4px solid #212121',
      borderRadius: '5px'
    },
    responseRow: {
      display: 'flex',
      flexDirection: 'row' as const,
      alignItems: 'flex-start',
      padding: '0px',
      gap: '46px',
      width: '100%',
      height: 'auto',
      flexWrap: 'wrap' as const
    },
    responseAuthorContainer: {
      display: 'flex',
      flexDirection: 'column' as const,
      alignItems: 'flex-start',
      padding: '0px',
      width: '119px',
      height: '46px'
    },
    responseAuthor: {
      width: '119px',
      height: '20px',
      fontFamily: 'Century Gothic, sans-serif',
      fontStyle: 'normal',
      fontWeight: 700,
      fontSize: '16px',
      lineHeight: '20px',
      letterSpacing: '-0.01em',
      color: '#212121'
    },
    responseDate: {
      width: '119px',
      height: '26px',
      fontFamily: 'Inter, sans-serif',
      fontStyle: 'normal',
      fontWeight: 400,
      fontSize: '16px',
      lineHeight: '26px',
      color: '#666666'
    },
    responseText: {
      width: 'calc(100% - 165px)',
      height: 'auto',
      fontFamily: 'Roboto, sans-serif',
      fontStyle: 'normal',
      fontWeight: 400,
      fontSize: '16px',
      lineHeight: '19px',
      letterSpacing: '-0.01em',
      color: '#212121'
    },
    menuDotsContainer: {
      position: 'absolute' as const,
      width: '5.25px',
      height: '21px',
      right: '0',
      top: '0',
      display: 'flex',
      flexDirection: 'column' as const,
      gap: '5px'
    },
    menuDot: {
      width: '5.25px',
      height: '5.25px',
      backgroundColor: '#7A7A7A',
      borderRadius: '50%'
    },
    photoGrid: {
      display: 'flex',
      flexDirection: 'row' as const,
      alignItems: 'center',
      gap: '13px',
      width: '100%',
      marginTop: '20px',
      marginBottom: '20px',
      flexWrap: 'wrap' as const
    },
    photo: {
      width: '153px',
      height: '85px',
      borderRadius: '4px',
      objectFit: 'cover' as const
    },
    photoMore: {
      width: '153px',
      height: '85px',
      borderRadius: '4px',
      background: 'linear-gradient(0deg, #C0DAFF, #C0DAFF)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '14px',
      fontFamily: 'Roboto, sans-serif',
      fontWeight: 500,
      color: '#096DFF'
    },
    twoColumnLayout: {
      display: 'flex',
      flexDirection: 'row' as const,
      flexWrap: 'wrap' as const,
      gap: '40px',
      width: '100%'
    },
    leftColumn: {
      flex: '0 0 282px',
      maxWidth: '282px'
    },
    rightColumn: {
      flex: '1 1 651px',
      maxWidth: '651px'
    },
    starContainer: {
      position: 'relative' as const,
      width: '100%',
      height: '20px'
    }
  };
  
  return (
    <div id="reviews-section" style={styles.mainContainer}>
      <div style={styles.header}>
        <h2 style={styles.title}>Отзывы о товаре</h2>
        <button 
          onClick={onWriteReview} 
          className="review-section-write-btn"
        >
          Оставить отзыв
        </button>
      </div>

      <div style={styles.mainContainer}>
        {/* Верхняя секция с рейтингом и фильтрами */}
        <div style={styles.topSection}>
          {/* Количество отзывов и рейтинг */}
          <div style={styles.reviewsCountContainer}>
            <div style={styles.reviewsCount}>{stats.totalCount} Отзывов</div>
            <div style={styles.ratingContainer}>
              <div style={styles.ratingValue}>{stats.averageRating.toFixed(1)}</div>
              <div style={styles.starsWrapper}>
                <Rating rating={stats.averageRating} size="lg" color="#096DFF" />
              </div>
            </div>
          </div>

          {/* Фильтры отзывов */}
          <div style={styles.filtersContainer}>
            <div 
              style={{
                ...(reviewFilter === 'all' ? styles.filterButtonActive : styles.filterButton),
                minWidth: '53px'
              }}
              onClick={() => setReviewFilter('all')}
            >
              <span style={reviewFilter === 'all' ? styles.filterButtonLabelActive : styles.filterButtonLabel}>Все</span>
            </div>
            
            <div 
              style={{
                ...(reviewFilter === 'with-photos' ? styles.filterButtonActive : styles.filterButton),
                minWidth: '84px'
              }}
              onClick={() => setReviewFilter('with-photos')}
            >
              <span style={reviewFilter === 'with-photos' ? styles.filterButtonLabelActive : styles.filterButtonLabel}>Фото</span>
            </div>
            
            <div 
              style={{
                ...(reviewFilter === 'positive' ? styles.filterButtonActive : styles.filterButton),
                minWidth: '152px'
              }}
              onClick={() => setReviewFilter('positive')}
            >
              <span style={reviewFilter === 'positive' ? styles.filterButtonLabelActive : styles.filterButtonLabel}>Положительные</span>
            </div>
            
            <div 
              style={{
                ...(reviewFilter === 'negative' ? styles.filterButtonActive : styles.filterButton),
                minWidth: '146px'
              }}
              onClick={() => setReviewFilter('negative')}
            >
              <span style={reviewFilter === 'negative' ? styles.filterButtonLabelActive : styles.filterButtonLabel}>Отрицательные</span>
            </div>
          </div>
        </div>

        {/* Контейнер отзывов */}
        <div style={styles.reviewsContainer}>
          {displayedReviews.length > 0 ? (
            <div style={styles.reviewsContent}>
              <div style={{ width: '100%' }}>
                {displayedReviews.map((review, index) => (
                  <div key={review.id} style={styles.reviewItem}>
                    <div style={styles.twoColumnLayout}>
                      {/* Левая колонка - информация об авторе */}
                      <div style={styles.leftColumn}>
                        <div style={styles.reviewAuthorSection}>
                          {/* Аватар автора */}
                          <div style={styles.authorAvatar}>
                            {review.author.avatar ? (
                              <img 
                                src={review.author.avatar} 
                                alt={review.author.name} 
                                style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: '6px' }} 
                              />
                            ) : (
                              <div style={{ 
                                width: '100%', 
                                height: '100%', 
                                borderRadius: '6px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                backgroundColor: '#f3f4f6',
                                fontSize: '32px',
                                fontWeight: 'bold',
                                color: '#6b7280'
                              }}>
                                {review.author.name.charAt(0).toUpperCase()}
                              </div>
                            )}
                          </div>

                          {/* Информация об авторе */}
                          <div style={styles.authorInfoContainer}>
                            <div style={styles.authorNameContainer}>
                              <div style={styles.authorName}>{review.author.name}</div>
                              <div style={styles.starContainer}>
                                <Rating rating={review.rating} size="md" color="#096DFF" />
                              </div>
                            </div>
                            <div style={styles.reviewDate}>{review.date}</div>
                          </div>
                        </div>
                      </div>

                      {/* Правая колонка - контент отзыва */}
                      <div style={styles.rightColumn}>
                        <div style={styles.reviewContentContainer}>
                          <div style={styles.reviewText}>{review.content}</div>
                          
                          {/* Фотографии, если есть */}
                          {review.photos && review.photos.length > 0 && (
                            <div style={styles.photoGrid}>
                              {review.photos.slice(0, 3).map((photo, idx) => (
                                <img 
                                  key={idx} 
                                  src={photo.url} 
                                  alt={`Фото от ${review.author.name}`} 
                                  style={styles.photo}
                                />
                              ))}
                              {review.photos.length > 3 && (
                                <div style={styles.photoMore}>
                                  +{review.photos.length - 3} Фотографии
                                </div>
                              )}
                            </div>
                          )}
                          
                          {/* Ответ от магазина */}
                          {index === 0 && (
                            <div style={styles.responseContainer}>
                              <div style={styles.responseRow}>
                                <div style={styles.responseAuthorContainer}>
                                  <div style={styles.responseAuthor}>Reship</div>
                                  <div style={styles.responseDate}>12 января 2024</div>
                                </div>
                                <div style={styles.responseText}>
                                  {review.author.name.split(' ')[0]}, написали вам на почту, предложили забрать клавиатуру на бесплатную диагностику.
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Меню (три точки) */}
                    <div style={styles.menuDotsContainer}>
                      <div style={styles.menuDot}></div>
                      <div style={styles.menuDot}></div>
                      <div style={styles.menuDot}></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div style={{ textAlign: 'center', padding: '32px 0', color: '#646464' }}>
              <p>Нет отзывов, соответствующих выбранным критериям</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ReviewSection; 