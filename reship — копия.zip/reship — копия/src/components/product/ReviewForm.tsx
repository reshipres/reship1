import React, { useState } from 'react';
import Rating from './Rating';

interface ReviewFormProps {
  productId: number;
  onSubmit: (reviewData: ReviewFormData) => void;
  onCancel: () => void;
}

export interface ReviewFormData {
  rating: number;
  name: string;
  comment: string;
  photos: File[];
}

const ReviewForm: React.FC<ReviewFormProps> = ({ 
  productId, 
  onSubmit, 
  onCancel 
}) => {
  // Состояние формы
  const [formData, setFormData] = useState<ReviewFormData>({
    rating: 5,
    name: '',
    comment: '',
    photos: []
  });
  
  // Обработчики изменения полей
  const handleRatingChange = (newRating: number) => {
    setFormData(prev => ({ ...prev, rating: newRating }));
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };
  
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newPhotos = Array.from(e.target.files);
      setFormData(prev => ({ ...prev, photos: [...prev.photos, ...newPhotos] }));
    }
  };
  
  const handleRemovePhoto = (index: number) => {
    setFormData(prev => ({
      ...prev,
      photos: prev.photos.filter((_, i) => i !== index)
    }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };
  
  // Стили
  const styles = {
    overlay: {
      position: 'fixed' as const,
      inset: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      zIndex: 50
    },
    modal: {
      backgroundColor: 'white',
      borderRadius: '8px',
      padding: '30px',
      width: '100%',
      maxWidth: '672px',
      position: 'relative' as const
    },
    closeButton: {
      position: 'absolute' as const,
      top: '22px',
      right: '22px',
      backgroundColor: 'transparent',
      border: 'none',
      cursor: 'pointer',
      color: '#212121',
      width: '20px',
      height: '20px',
      padding: 0
    },
    title: {
      fontSize: '24px',
      fontWeight: 'bold' as const,
      marginBottom: '30px',
      color: '#212121',
      fontFamily: 'Century Gothic, sans-serif'
    },
    form: {
      display: 'flex',
      flexDirection: 'column' as const,
      gap: '20px'
    },
    formGroup: {
      display: 'flex',
      flexDirection: 'column' as const,
      gap: '8px'
    },
    label: {
      fontSize: '16px',
      fontWeight: 500 as const,
      color: '#212121',
      marginBottom: '4px',
      fontFamily: 'Roboto, sans-serif'
    },
    input: {
      width: '100%',
      padding: '12px 15px',
      border: '1px solid #D1D5DB',
      borderRadius: '6px',
      fontSize: '16px',
      outline: 'none',
      fontFamily: 'Roboto, sans-serif'
    },
    textarea: {
      width: '100%',
      padding: '12px 15px',
      border: '1px solid #D1D5DB',
      borderRadius: '6px',
      fontSize: '16px',
      minHeight: '100px',
      resize: 'vertical' as const,
      outline: 'none',
      fontFamily: 'Roboto, sans-serif'
    },
    ratingContainer: {
      display: 'flex',
      gap: '8px',
      alignItems: 'center',
      marginBottom: '10px'
    },
    ratingLabel: {
      fontSize: '16px',
      fontWeight: 500 as const,
      color: '#212121',
      marginRight: '15px',
      fontFamily: 'Roboto, sans-serif'
    },
    photoUpload: {
      marginTop: '10px'
    },
    photoButton: {
      display: 'inline-flex',
      alignItems: 'center',
      padding: '10px 20px',
      border: '2px solid #212121',
      borderRadius: '7px',
      backgroundColor: 'white',
      fontSize: '16px',
      fontWeight: 500 as const,
      color: '#212121',
      cursor: 'pointer',
      fontFamily: 'Roboto, sans-serif'
    },
    photosPreview: {
      display: 'flex',
      flexWrap: 'wrap' as const,
      gap: '15px',
      marginTop: '15px'
    },
    photoPreview: {
      position: 'relative' as const,
      width: '153px',
      height: '85px',
      borderRadius: '4px',
      overflow: 'hidden',
      border: '1px solid #D1D5DB'
    },
    photoImage: {
      width: '100%',
      height: '100%',
      objectFit: 'cover' as const
    },
    removePhotoButton: {
      position: 'absolute' as const,
      top: '5px',
      right: '5px',
      backgroundColor: 'rgba(0, 0, 0, 0.6)',
      color: 'white',
      borderRadius: '50%',
      width: '24px',
      height: '24px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
      border: 'none',
      fontSize: '14px'
    },
    actions: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: '15px',
      marginTop: '25px'
    },
    cancelButton: {
      padding: '10px 25px',
      backgroundColor: 'white',
      border: '2px solid #212121',
      borderRadius: '7px',
      fontSize: '16px',
      fontWeight: 500 as const,
      color: '#212121',
      cursor: 'pointer',
      fontFamily: 'Roboto, sans-serif'
    },
    submitButton: {
      padding: '10px 25px',
      backgroundColor: '#096DFF',
      border: 'none',
      borderRadius: '7px',
      fontSize: '16px',
      fontWeight: 500 as const,
      color: 'white',
      cursor: 'pointer',
      fontFamily: 'Roboto, sans-serif'
    },
    starContainer: {
      display: 'flex',
      gap: '10px'
    },
    starButton: {
      background: 'transparent',
      border: 'none',
      padding: 0,
      cursor: 'pointer',
      width: '32px',
      height: '32px'
    }
  };
  
  return (
    <div style={styles.overlay}>
      <div style={styles.modal}>
        <button 
          style={styles.closeButton}
          onClick={onCancel}
          aria-label="Закрыть"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
        
        <h2 style={styles.title}>Оставить отзыв о товаре</h2>
        
        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.formGroup}>
            <div style={styles.ratingContainer}>
              <span style={styles.ratingLabel}>Оценка:</span>
              <Rating 
                rating={formData.rating} 
                size="lg" 
                color="#096DFF" 
              />
            </div>
            <div style={styles.starContainer}>
              {[1, 2, 3, 4, 5].map((star) => (
                <button 
                  key={star} 
                  type="button"
                  onClick={() => handleRatingChange(star)}
                  style={styles.starButton}
                  aria-label={`Оценка ${star} из 5`}
                >
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    viewBox="0 0 24 24" 
                    fill={star <= formData.rating ? "#096DFF" : "#E3E7F0"} 
                    stroke={star <= formData.rating ? "#096DFF" : "#096DFF"}
                    width="32" 
                    height="32"
                  >
                    <path 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      strokeWidth="1.5" 
                      d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" 
                    />
                  </svg>
                </button>
              ))}
            </div>
          </div>
          
          <div style={styles.formGroup}>
            <label htmlFor="name" style={styles.label}>Ваше имя</label>
            <input 
              type="text" 
              id="name" 
              value={formData.name} 
              onChange={handleInputChange} 
              style={styles.input} 
              required 
              placeholder="Как к вам обращаться"
            />
          </div>
          
          <div style={styles.formGroup}>
            <label htmlFor="comment" style={styles.label}>Комментарий</label>
            <textarea 
              id="comment" 
              value={formData.comment} 
              onChange={handleInputChange} 
              style={styles.textarea} 
              required 
              placeholder="Поделитесь впечатлениями о товаре"
            />
          </div>
          
          <div style={styles.formGroup}>
            <label style={styles.label}>Фотографии (до 5 фото)</label>
            {formData.photos.length < 5 && (
              <div style={styles.photoUpload}>
                <label htmlFor="photo-upload" style={styles.photoButton}>
                  Прикрепить фото
                </label>
                <input 
                  type="file" 
                  id="photo-upload" 
                  accept="image/*" 
                  onChange={handlePhotoUpload} 
                  style={{ display: 'none' }} 
                  multiple={formData.photos.length === 0 ? true : formData.photos.length < 5}
                />
              </div>
            )}
            
            {formData.photos.length > 0 && (
              <div style={styles.photosPreview}>
                {formData.photos.map((photo, index) => (
                  <div key={index} style={styles.photoPreview}>
                    <img 
                      src={URL.createObjectURL(photo)} 
                      alt={`Фото ${index + 1}`} 
                      style={styles.photoImage} 
                    />
                    <button 
                      type="button" 
                      onClick={() => handleRemovePhoto(index)} 
                      style={styles.removePhotoButton}
                      aria-label="Удалить фото"
                    >
                      ✕
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          <div style={styles.actions}>
            <button 
              type="button" 
              onClick={onCancel} 
              style={styles.cancelButton}
            >
              Отмена
            </button>
            <button 
              type="submit" 
              style={styles.submitButton}
            >
              Отправить отзыв
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ReviewForm; 