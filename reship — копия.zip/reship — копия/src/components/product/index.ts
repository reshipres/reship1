import ProductGallery from './ProductGallery';
import ProductDetails from './ProductDetails';
import ProductReviews from './ProductReviews';
import ProductInfo from './ProductInfo';
import ReviewSection from './ReviewSection';
import ReviewForm from './ReviewForm';
import Rating from './Rating';

export {
  ProductGallery,
  ProductDetails,
  ProductReviews,
  ProductInfo,
  ReviewSection,
  ReviewForm,
  Rating
};