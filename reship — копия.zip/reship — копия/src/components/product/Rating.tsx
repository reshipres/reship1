import React from 'react';
import { StarIcon } from '@heroicons/react/24/outline';
import { StarIcon as StarSolidIcon } from '@heroicons/react/24/solid';

interface RatingProps {
  rating: number;
  maxRating?: number;
  size?: 'xs' | 'sm' | 'md' | 'lg';
  color?: string;
  showValue?: boolean;
}

const Rating: React.FC<RatingProps> = ({
  rating,
  maxRating = 5,
  size = 'md',
  color = '#096DFF',
  showValue = false
}) => {
  // Определение размеров звезд
  const sizesMap = {
    xs: { width: '14px', height: '14px', margin: '0 1px' },
    sm: { width: '16px', height: '16px', margin: '0 1px' },
    md: { width: '19px', height: '18px', margin: '0 2px' },
    lg: { width: '24px', height: '24px', margin: '0 2px' },
  };
  
  const sizeStyle = sizesMap[size];
  
  // Создание массива для отображения звезд
  const stars = [];
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 >= 0.5;
  
  for (let i = 1; i <= maxRating; i++) {
    if (i <= fullStars) {
      // Полная звезда
      stars.push(
        <div key={i} style={{ position: 'relative', ...sizeStyle }}>
          <StarSolidIcon style={{ color }} />
        </div>
      );
    } else if (i === fullStars + 1 && hasHalfStar) {
      // Полная звезда (для упрощения - можно добавить половинчатую логику при необходимости)
      stars.push(
        <div key={i} style={{ position: 'relative', ...sizeStyle }}>
          <StarSolidIcon style={{ color }} />
        </div>
      );
    } else {
      // Пустая звезда
      stars.push(
        <div key={i} style={{ position: 'relative', ...sizeStyle }}>
          <StarIcon style={{ color: '#E3E7F0', stroke: color }} />
        </div>
      );
    }
  }
  
  return (
    <div style={{ display: 'flex', alignItems: 'center' }}>
      <div style={{ display: 'flex' }}>{stars}</div>
      {showValue && (
        <span style={{ marginLeft: '8px', fontSize: '14px', fontWeight: 500, color: '#383838' }}>
          {rating.toFixed(1)}
        </span>
      )}
    </div>
  );
};

export default Rating; 