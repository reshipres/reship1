import React, { useState } from 'react';

interface ProductGalleryProps {
  images: string[];
  imageDescriptions?: string[];
  initialImageIndex?: number;
}

const ProductGallery: React.FC<ProductGalleryProps> = ({ 
  images, 
  imageDescriptions = [],
  initialImageIndex = 0
}) => {
  const [activeImage, setActiveImage] = useState<number>(initialImageIndex);
  
  // Стили для галереи
  const galleryStyles = {
    container: {
      display: 'flex',
      flexDirection: 'row' as const,
      gap: '13px',
      width: '790px',
    },
    thumbnailsContainer: {
      display: 'flex',
      flexDirection: 'column' as const,
      justifyContent: 'center',
      alignItems: 'center',
      gap: '29px',
      width: '74px',
      height: '498px',
    },
    arrowButton: {
      border: '1.6px solid black',
      width: '20px',
      height: '20px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
      backgroundColor: 'white',
    },
    thumbnailsWrapper: {
      display: 'flex',
      flexDirection: 'column' as const,
      gap: '14px',
      width: '74px',
    },
    thumbnailButton: {
      width: '74px',
      height: '95px',
      backgroundColor: 'white',
      borderRadius: '6px',
      overflow: 'hidden',
      cursor: 'pointer',
      border: 'none',
      padding: 0,
    },
    thumbnailActive: {
      border: '2px solid #096DFF',
    },
    thumbnailImage: {
      width: '100%',
      height: '100%',
      objectFit: 'cover' as const,
    },
    mainImageContainer: {
      width: '700px',
      height: '527px',
      position: 'relative' as const,
    },
    mainImageBg: {
      position: 'absolute' as const,
      width: '700px',
      height: '527px',
      left: 0,
      top: 0,
      backgroundColor: 'white',
      borderRadius: '7px',
    },
    mainImageWrapper: {
      position: 'absolute' as const,
      width: '640px',
      height: '459px',
      left: '30px',
      top: '34px',
    },
    mainImage: {
      width: '100%',
      height: '100%',
      objectFit: 'contain' as const,
      borderRadius: '7px',
    }
  };

  // Переключение изображений
  const handlePrevImage = () => {
    setActiveImage(activeImage === 0 ? images.length - 1 : activeImage - 1);
  };

  const handleNextImage = () => {
    setActiveImage((activeImage + 1) % images.length);
  };

  const handleThumbnailClick = (index: number) => {
    setActiveImage(index);
  };

  return (
    <div style={galleryStyles.container}>
      {/* Вертикальная галерея миниатюр */}
      <div style={galleryStyles.thumbnailsContainer}>
        {/* Стрелка вверх */}
        <button 
          style={galleryStyles.arrowButton}
          onClick={handlePrevImage}
          aria-label="Предыдущее изображение"
        >
          <svg width="14" height="8" viewBox="0 0 14 8" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M1 7L7 1L13 7" stroke="black" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
        
        {/* Контейнер для миниатюр */}
        <div style={galleryStyles.thumbnailsWrapper}>
          {images.map((image, index) => (
            <button 
              key={index}
              style={{
                ...galleryStyles.thumbnailButton,
                ...(activeImage === index ? galleryStyles.thumbnailActive : {})
              }}
              onClick={() => handleThumbnailClick(index)}
              aria-label={imageDescriptions[index] || `Изображение ${index + 1}`}
            >
              <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <img 
                  src={image} 
                  alt={imageDescriptions[index] || `Изображение ${index + 1}`} 
                  style={galleryStyles.thumbnailImage}
                />
              </div>
            </button>
          ))}
        </div>
        
        {/* Стрелка вниз */}
        <button 
          style={galleryStyles.arrowButton}
          onClick={handleNextImage}
          aria-label="Следующее изображение"
        >
          <svg width="14" height="8" viewBox="0 0 14 8" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M1 1L7 7L13 1" stroke="black" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
      </div>
      
      {/* Основное изображение */}
      <div style={galleryStyles.mainImageContainer}>
        <div style={galleryStyles.mainImageBg}></div>
        <div style={galleryStyles.mainImageWrapper}>
          <img 
            src={images[activeImage]} 
            alt={imageDescriptions[activeImage] || `Изображение ${activeImage + 1}`} 
            style={galleryStyles.mainImage}
          />
        </div>
      </div>
    </div>
  );
};

export default ProductGallery;
