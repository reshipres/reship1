import React from 'react';
import { Link } from 'react-router-dom';

const Features: React.FC = () => {
  const features = [
    {
      title: 'Гарантия качества',
      description: 'Независимые государства будут ограничены исключительно образом мышления.',
      iconSrc: '/images/icon-shield-white.svg'
    },
    {
      title: 'Доставка по',
      linkText: 'всей России',
      linkUrl: '/delivery',
      description: 'Независимые государства будут ограничены исключительно образом мышления.',
      iconSrc: '/images/icon-truck-white.svg'
    },
    {
      title: 'Больше',
      highlightText: '1000+',
      secondPart: 'отзывов',
      description: 'Независимые государства будут ограничены исключительно образом',
      iconSrc: '/images/icon-star-white.svg'
    }
  ];

  return (
    <section className="py-[12px] bg-[#E3E7F0]">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row gap-4 md:gap-5">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="flex-1 bg-white p-[15px] rounded-[8px] transition-all duration-300 hover:shadow-md hover:translate-y-[-3px]"
            >
              <div className="flex flex-col gap-[8px] w-full h-full">
                <div className="flex items-center gap-[15px]">
                  <div className="flex-shrink-0 w-[48px] h-[48px] bg-[#212121] rounded-[6.5px] relative flex items-center justify-center">
                    <img src={feature.iconSrc} alt="" className="w-[24px] h-[24px]" />
                  </div>
                  
                  <h3 className="text-[18px] font-bold leading-[22px] tracking-tight text-[#212121] flex flex-wrap items-center" 
                      style={{ fontFamily: 'Century Gothic, sans-serif', fontWeight: 700 }}>
                    {feature.title}{' '}
                    
                    {feature.linkText && (
                      <Link to={feature.linkUrl} className="text-[#0A6DFF] hover:underline ml-1">
                        {feature.linkText}
                      </Link>
                    )}
                    
                    {feature.highlightText && (
                      <>
                        <span className="text-[#0A6DFF] ml-1">{feature.highlightText}</span>
                        {feature.secondPart && (
                          <span className="ml-1">{feature.secondPart}</span>
                        )}
                      </>
                    )}
                  </h3>
                </div>
                
                <p className="text-sm leading-[18px] text-[#222222]" style={{ fontFamily: 'Roboto, sans-serif' }}>
                  {feature.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;