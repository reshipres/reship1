import React from 'react';
import VerticalProductCard from '../components/VerticalProductCard';
import ProductCard from '../components/ProductCard';

const TestProductCardPage: React.FC = () => {
  // Тестовые данные для продукта
  const productData = {
    id: 101,
    title: 'Ninjutso x Vaxee Sora Superlight Wireless',
    brand: 'Ninjutso',
    price: 8000,
    oldPrice: 15000,
    rating: 4.5,
    reviewCount: 60,
    image: 'https://cdn.shopify.com/s/files/1/0570/6308/7457/products/SoraPink_1_1445x.jpg?v=1654577769',
    discount: 45,
    colors: [
      { id: 1, name: 'Розовый', hex: '#F6BBFF' },
      { id: 2, name: 'Белый', hex: '#FFFFFF' },
      { id: 3, name: 'Серый', hex: '#E3E7F0' },
      { id: 4, name: 'Черный', hex: '#000000' }
    ]
  };

  return (
    <div className="min-h-screen bg-gray-100 py-8">
      <div className="container mx-auto">
        <h1 className="text-2xl font-bold mb-8 text-center">Стандартизированные карточки товаров</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">1. Вертикальная карточка (новый дизайн)</h2>
            <div className="flex justify-center">
              <VerticalProductCard {...productData} />
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">2. Существующая карточка с обновлениями</h2>
            <div className="flex justify-center">
              <ProductCard 
                id={productData.id}
                title={productData.title}
                brand={productData.brand}
                price={productData.price}
                oldPrice={productData.oldPrice}
                rating={productData.rating}
                reviewCount={productData.reviewCount}
                image={productData.image}
                discount={productData.discount}
                colors={productData.colors}
                inStock={true}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestProductCardPage; 