import React, { useEffect, useState } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../store';
import { fetchPlayerById } from '../store/slices/playerSlice';
import { addToCart } from '../store/slices/cartSlice';
import { 
  ArrowLeftIcon, 
  ChevronDownIcon, 
  ChevronUpIcon, 
  ShoppingCartIcon, 
  HeartIcon, 
  PlusIcon, 
  MinusIcon, 
  ShareIcon, 
  InformationCircleIcon, 
  CheckIcon,
  ClockIcon,
  ShieldCheckIcon
} from '@heroicons/react/24/outline';
import { toast } from 'react-hot-toast';
import { EquipmentItem, PlayerEquipment } from '../types/player';

const PlayerSetupPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { currentPlayer, loading, error } = useSelector((state: RootState) => state.players);
  
  // Состояние для выбранных товаров
  const [selectedItems, setSelectedItems] = useState<Record<string, boolean>>({
    mouse: true,
    keyboard: true,
    headset: true,
    mousepad: true,
    monitor: true
  });

  // Состояние для активной секции
  const [activeSection, setActiveSection] = useState<string | null>(null);

  // Состояние для количества сетапов
  const [quantity, setQuantity] = useState(1);

  // Состояние для отображения анимации
  const [isLoaded, setIsLoaded] = useState(false);

  // Состояние для лайка (избранное)
  const [isFavorite, setIsFavorite] = useState(false);

  // Загружаем данные игрока при монтировании компонента
  useEffect(() => {
    if (id) {
      dispatch(fetchPlayerById(Number(id)) as any);
    }
    
    // Включаем анимацию с небольшой задержкой
    const timer = setTimeout(() => {
      setIsLoaded(true);
    }, 100);
    
    return () => clearTimeout(timer);
  }, [dispatch, id]);

  // Обработчик выбора/отмены выбора устройства
  const handleToggleItem = (key: string) => {
    setSelectedItems(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  // Обработчик переключения секции
  const toggleSection = (category: string) => {
    setActiveSection(prev => prev === category ? null : category);
  };

  // Увеличение количества
  const increaseQuantity = () => {
    setQuantity(prev => prev + 1);
  };

  // Уменьшение количества
  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };

  // Обработчик добавления сетапа в корзину
  const handleAddSetupToCart = () => {
    if (!currentPlayer) return;

    const equipment = currentPlayer.equipment;
    const itemsToAdd: EquipmentItem[] = [];

    // Добавляем выбранные предметы
    if (selectedItems.mouse && equipment.mouse) {
      itemsToAdd.push(equipment.mouse);
    }
    
    if (selectedItems.keyboard && equipment.keyboard) {
      itemsToAdd.push(equipment.keyboard);
    }
    
    if (selectedItems.headset && equipment.headset) {
      itemsToAdd.push(equipment.headset);
    }
    
    if (selectedItems.mousepad && equipment.mousepad) {
      itemsToAdd.push(equipment.mousepad);
    }
    
    if (selectedItems.monitor && equipment.monitor) {
      itemsToAdd.push(equipment.monitor);
    }

    // Добавляем выбранные предметы в корзину
    itemsToAdd.forEach(item => {
      dispatch(addToCart({
        product: {
          id: item.id,
          title: item.name,
          brand: item.brand,
          price: item.price,
          image: item.image || '',
          rating: 5,
          reviewCount: 32,
          inStock: true
        },
        quantity: quantity
      }) as any);
    });

    // Показываем уведомление
    toast.success(`Сетап ${currentPlayer.nickname} добавлен в корзину!`);
  };

  // Обработчик добавления в избранное
  const handleToggleFavorite = () => {
    setIsFavorite(!isFavorite);
    toast.success(isFavorite ? 'Удалено из избранного' : 'Добавлено в избранное');
  };

  // Обработчик для поделиться
  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: currentPlayer?.nickname || 'Сетап игрока',
        text: `Проверь сетап игрока ${currentPlayer?.nickname}`,
        url: window.location.href,
      })
      .then(() => toast.success('Успешно поделились!'))
      .catch((error) => console.log('Ошибка в sharing', error));
    } else {
      // Fallback - копируем ссылку в буфер обмена
      navigator.clipboard.writeText(window.location.href)
        .then(() => toast.success('Ссылка скопирована в буфер обмена!'))
        .catch(() => toast.error('Не удалось скопировать ссылку'));
    }
  };

  // Форматирование цены
  const formatPrice = (price: number): string => {
    return new Intl.NumberFormat('ru-RU', {
      style: 'currency',
      currency: 'RUB',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(price);
  };

  // Расчет общей цены сетапа
  const calculateTotalPrice = () => {
    if (!currentPlayer) return 0;
    
    const equipment = currentPlayer.equipment;
    let total = 0;

    if (selectedItems.mouse && equipment.mouse) {
      total += equipment.mouse.price;
    }
    
    if (selectedItems.keyboard && equipment.keyboard) {
      total += equipment.keyboard.price;
    }
    
    if (selectedItems.headset && equipment.headset) {
      total += equipment.headset.price;
    }
    
    if (selectedItems.mousepad && equipment.mousepad) {
      total += equipment.mousepad.price;
    }
    
    if (selectedItems.monitor && equipment.monitor) {
      total += equipment.monitor.price;
    }

    return total * quantity;
  };

  // Расчет скидки (демонстрационно)
  const calculateDiscount = () => {
    return 15; // 15% скидка на весь сетап
  };

  // Расчет цены со скидкой
  const calculateDiscountedPrice = () => {
    const total = calculateTotalPrice();
    const discount = calculateDiscount();
    return Math.round(total * (1 - discount / 100));
  };

  // Получение названия категории на русском
  const getCategoryName = (category: string): string => {
    const categories: Record<string, string> = {
      mouse: 'Мышь',
      keyboard: 'Клавиатура',
      headset: 'Наушники',
      mousepad: 'Коврик',
      monitor: 'Монитор',
      other: 'Другое'
    };
    
    return categories[category] || category;
  };

  // Получение информации о доставке
  const getDeliveryInfo = () => {
    return '1-3 дня';
  };

  // Получение информации о гарантии
  const getWarrantyInfo = () => {
    return '2 года';
  };

  // Если данные загружаются, показываем спиннер
  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8 flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  // Если произошла ошибка, показываем сообщение
  if (error || !currentPlayer) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Упс! Произошла ошибка</h2>
        <p className="text-gray-600 mb-6">Не удалось загрузить информацию об игроке. Пожалуйста, попробуйте позже.</p>
        <button 
          onClick={() => navigate(-1)} 
          className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 mx-auto"
        >
          <ArrowLeftIcon className="w-5 h-5" />
          Вернуться назад
        </button>
      </div>
    );
  }

  // CSS классы для анимации
  const fadeInClass = isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8';
  const transitionClass = 'transition-all duration-500 ease-out';

  // Основной контент страницы
  return (
    <div className="container mx-auto px-4 py-8">
      {/* Хлебные крошки */}
      <div className={`flex items-center gap-2 text-sm text-gray-600 mb-6 ${fadeInClass} ${transitionClass}`} style={{ transitionDelay: '100ms' }}>
        <Link to="/" className="hover:text-blue-600 transition-colors">
          Главная
        </Link>
        <ChevronDownIcon className="w-4 h-4 rotate-90" />
        <Link to="/players" className="hover:text-blue-600 transition-colors">
          Игроки
        </Link>
        <ChevronDownIcon className="w-4 h-4 rotate-90" />
        <span className="text-gray-800">{currentPlayer.nickname}</span>
      </div>

      <div className={`bg-white rounded-xl shadow-sm overflow-hidden mb-10 ${fadeInClass} ${transitionClass}`} style={{ transitionDelay: '200ms' }}>
        <div className="p-8">
          <div className="flex flex-col lg:flex-row gap-10">
            {/* Левая колонка - изображение игрока */}
            <div className="lg:w-1/4">
              <div className="relative rounded-xl overflow-hidden bg-blue-50 aspect-square">
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-600 to-blue-400 z-10"></div>
                <img 
                  src={currentPlayer.image || 'https://liquipedia.net/commons/images/thumb/9/9f/Silhouette_of_a_person.svg/800px-Silhouette_of_a_person.svg.png'} 
                  alt={currentPlayer.nickname} 
                  className="w-full h-full object-cover p-4 transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute top-4 left-4 bg-blue-600 text-white text-sm font-bold px-2 py-1 rounded-md">
                  -{calculateDiscount()}%
                </div>
              </div>

              <div className="mt-6 grid grid-cols-4 gap-2">
                {[...Array(4)].map((_, i) => (
                  <div 
                    key={i} 
                    className="aspect-square rounded-md overflow-hidden bg-blue-50 relative cursor-pointer hover:ring-2 hover:ring-blue-500 transition-all"
                  >
                    <img 
                      src={currentPlayer.image || 'https://liquipedia.net/commons/images/thumb/9/9f/Silhouette_of_a_person.svg/800px-Silhouette_of_a_person.svg.png'} 
                      alt={`${currentPlayer.nickname} thumbnail ${i + 1}`}
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Средняя колонка - информация об игроке */}
            <div className="lg:w-2/4">
              <div className="mb-1 text-blue-600 font-medium">{currentPlayer.games[0]}</div>
              <h1 className="text-3xl font-bold text-gray-900 mb-3">{currentPlayer.nickname}</h1>

              <p className="text-gray-700 mb-6 leading-relaxed">
                {currentPlayer.fullName}, известный как {currentPlayer.nickname} - 
                профессиональный игрок {currentPlayer.games.join(', ')}.
                {currentPlayer.bio}
              </p>

              <div className="mb-6">
                <h3 className="text-lg font-bold text-gray-800 mb-3">Особенности сетапа:</h3>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mt-0.5">
                      <CheckIcon className="w-3 h-3" />
                    </div>
                    <span className="text-gray-700">Профессиональное оборудование высшего класса</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mt-0.5">
                      <CheckIcon className="w-3 h-3" />
                    </div>
                    <span className="text-gray-700">Точно такое же оборудование, как у {currentPlayer.nickname}</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mt-0.5">
                      <CheckIcon className="w-3 h-3" />
                    </div>
                    <span className="text-gray-700">Оптимизировано для {currentPlayer.games.join(', ')}</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="w-5 h-5 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mt-0.5">
                      <CheckIcon className="w-3 h-3" />
                    </div>
                    <span className="text-gray-700">Официальная гарантия на все комплектующие</span>
                  </li>
                </ul>
              </div>

              <div className="flex flex-wrap gap-3 mb-6">
                {currentPlayer.games.map((game) => (
                  <span key={game} className="inline-block px-3 py-1 bg-blue-50 text-blue-700 text-sm font-medium rounded-md">
                    {game}
                  </span>
                ))}
                {currentPlayer.isProPlayer && (
                  <span className="inline-block px-3 py-1 bg-blue-50 text-blue-700 text-sm font-medium rounded-md">
                    Профессиональный
                  </span>
                )}
                <span className="inline-block px-3 py-1 bg-blue-50 text-blue-700 text-sm font-medium rounded-md">
                  {currentPlayer.countryCode}
                </span>
              </div>

            </div>

            {/* Правая колонка - добавление в корзину */}
            <div className="lg:w-1/4">
              <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
                <div className="flex items-center gap-3 mb-4">
                  <span className="bg-blue-600 text-white text-sm font-bold px-2 py-1 rounded">-{calculateDiscount()}%</span>
                  <span className="text-3xl font-bold text-gray-900">{formatPrice(calculateDiscountedPrice())}</span>
                  <span className="text-gray-500 line-through">{formatPrice(calculateTotalPrice())}</span>
                </div>

                <p className="text-gray-700 mb-4">Полный сетап как у {currentPlayer.nickname}</p>

                <div className="space-y-3 mb-6">
                  {Object.entries(currentPlayer.equipment).map(([key, item]) => {
                    if (!item || (Array.isArray(item) && item.length === 0)) return null;
                    
                    const equipmentItem = Array.isArray(item) ? item[0] : item;
                    
                    return (
                      <div key={key} className="flex items-center justify-between py-2 border-b border-gray-100">
                        <div className="flex items-center gap-2">
                          <input 
                            type="checkbox" 
                            className="w-4 h-4 accent-blue-500 rounded" 
                            checked={selectedItems[key] || false}
                            onChange={() => handleToggleItem(key)}
                          />
                          <div>
                            <div className="text-gray-800 font-medium">{getCategoryName(key)}</div>
                            <div className="text-sm text-gray-500">{equipmentItem.name}</div>
                          </div>
                        </div>
                        <div className="text-right font-medium">{formatPrice(equipmentItem.price)}</div>
                      </div>
                    );
                  })}
                </div>

                {/* Добавление в корзину и счетчик количества - новый стиль */}
                <div className="mb-4">
                  <div className="flex gap-3 w-full h-14">
                    <div className="relative flex-grow">
                      <button 
                        onClick={handleAddSetupToCart}
                        className="w-full h-full bg-[#212121] hover:bg-[#333333] text-white font-medium rounded-lg transition-colors flex items-center justify-center gap-2"
                      >
                        <ShoppingCartIcon className="w-5 h-5" />
                        <span>Добавить в корзину</span>
                      </button>
                    </div>
                    <div className="relative w-[83px] h-full">
                      <div className="absolute inset-0 border-2 border-[#212121] rounded-lg flex items-center justify-between px-4">
                        <button
                          onClick={decreaseQuantity}
                          className="text-[#212121] font-medium text-lg"
                        >
                          -
                        </button>
                        <span className="text-[#212121] font-medium">{quantity}</span>
                        <button
                          onClick={increaseQuantity}
                          className="text-[#212121] font-medium text-lg"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  {/* Кнопки избранное и поделиться */}
                  <div className="flex gap-3 mt-3">
                    <button 
                      onClick={handleToggleFavorite}
                      className={`w-14 h-11 flex items-center justify-center border-2 ${isFavorite ? 'bg-[#212121] text-white' : 'text-[#212121]'} border-[#212121] rounded-lg hover:bg-gray-100 transition-colors`}
                    >
                      <HeartIcon className={`w-5 h-5 ${isFavorite ? 'text-white' : ''}`} />
                    </button>
                    <button 
                      onClick={handleShare}
                      className="w-14 h-11 flex items-center justify-center border-2 border-[#212121] text-[#212121] rounded-lg hover:bg-gray-100 transition-colors"
                    >
                      <ShareIcon className="w-5 h-5" />
                    </button>
                    <div className="flex-grow flex items-center justify-between text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <ClockIcon className="w-5 h-5 text-blue-600" />
                        <span>Доставка: {getDeliveryInfo()}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <ShieldCheckIcon className="w-5 h-5 text-blue-600" />
                        <span>Гарантия: {getWarrantyInfo()}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Секции оборудования */}
      {Object.entries(currentPlayer.equipment).map(([key, item], index) => {
        if (!item || (Array.isArray(item) && item.length === 0)) return null;
        
        const equipmentItem = Array.isArray(item) ? item[0] : item;
        const isActive = activeSection === key || activeSection === null;
        
        return (
          <div 
            key={key}
            className={`bg-white rounded-xl shadow-sm mb-6 overflow-hidden ${fadeInClass} ${transitionClass}`}
            style={{ transitionDelay: `${300 + (index * 100)}ms` }}
          >
            <div
              className="p-5 flex items-center justify-between border-b border-gray-100 cursor-pointer"
              onClick={() => toggleSection(key)}
            >
              <h2 className="text-xl font-bold text-gray-800">{getCategoryName(key)}</h2>
              <ChevronUpIcon
                className={`w-5 h-5 text-gray-400 transition-transform ${isActive ? "rotate-180" : ""}`}
              />
            </div>

            <div className={`transition-all duration-300 ${isActive ? "block" : "hidden"}`}>
              <div className="p-6">
                <div className="flex flex-col md:flex-row gap-8">
                  {/* Изображение */}
                  <div className="md:w-1/6">
                    <div className="relative w-full aspect-square bg-blue-50 rounded-lg p-4 overflow-hidden group">
                      <img
                        src={equipmentItem.image || '/placeholder.svg'}
                        alt={equipmentItem.name}
                        className="object-contain p-4 transition-transform duration-500 group-hover:scale-110"
                      />
                      <div className="absolute top-2 left-2 bg-blue-600 text-white text-xs font-bold px-2 py-1 rounded-md">
                        -{calculateDiscount()}%
                      </div>
                    </div>
                  </div>

                  {/* Информация о товаре */}
                  <div className="md:w-2/3">
                    <h3 className="text-xl font-bold text-gray-800 mb-2">{equipmentItem.name}</h3>
                    <p className="text-gray-600 mb-4">
                      {equipmentItem.brand} {equipmentItem.model}
                    </p>

                    <div className="flex flex-wrap gap-6 mb-4">
                      <div className="flex items-center gap-1 text-sm">
                        <ClockIcon className="w-5 h-5 text-blue-600" />
                        <span className="text-gray-500">Доставка:</span>
                        <span className="text-gray-700">{getDeliveryInfo()}</span>
                      </div>
                      <div className="flex items-center gap-1 text-sm">
                        <ShieldCheckIcon className="w-5 h-5 text-blue-600" />
                        <span className="text-gray-500">Гарантия:</span>
                        <span className="text-gray-700">{getWarrantyInfo()}</span>
                      </div>
                    </div>

                    <div className="bg-blue-50 rounded-lg p-4 mb-4">
                      <h4 className="text-blue-800 font-medium mb-2 flex items-center gap-1">
                        <InformationCircleIcon className="w-4 h-4" /> Характеристики
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        <div className="flex items-start gap-2">
                          <div className="w-4 h-4 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mt-0.5">
                            <CheckIcon className="w-3 h-3" />
                          </div>
                          <span className="text-gray-700 text-sm">Категория: {equipmentItem.category}</span>
                        </div>
                        <div className="flex items-start gap-2">
                          <div className="w-4 h-4 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mt-0.5">
                            <CheckIcon className="w-3 h-3" />
                          </div>
                          <span className="text-gray-700 text-sm">Бренд: {equipmentItem.brand}</span>
                        </div>
                        <div className="flex items-start gap-2">
                          <div className="w-4 h-4 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mt-0.5">
                            <CheckIcon className="w-3 h-3" />
                          </div>
                          <span className="text-gray-700 text-sm">Модель: {equipmentItem.model}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Цена и кнопки */}
                  <div className="md:w-1/4">
                    <div className="bg-white p-4 rounded-lg border border-gray-200">
                      <div className="flex items-center gap-2 mb-4">
                        <span className="bg-blue-600 text-white text-xs font-bold px-2 py-1 rounded">
                          -{calculateDiscount()}%
                        </span>
                        <span className="text-2xl font-bold text-gray-900">
                          {formatPrice(Math.round(equipmentItem.price * (1 - calculateDiscount() / 100)))}
                        </span>
                        <span className="text-gray-500 line-through text-sm">
                          {formatPrice(equipmentItem.price)}
                        </span>
                      </div>

                      {/* Кнопка корзины и счетчик количества в одной строке */}
                      <div className="flex gap-3 w-full h-12">
                        <div className="relative flex-grow">
                          <button 
                            onClick={() => {
                              dispatch(addToCart({
                                product: {
                                  id: equipmentItem.id,
                                  title: equipmentItem.name,
                                  brand: equipmentItem.brand,
                                  price: equipmentItem.price,
                                  image: equipmentItem.image || '',
                                  rating: 5,
                                  reviewCount: 32,
                                  inStock: true
                                },
                                quantity: 1
                              }) as any);
                              toast.success(`${equipmentItem.name} добавлен в корзину!`);
                            }}
                            className="w-full h-full bg-[#212121] hover:bg-[#333333] text-white font-medium rounded-lg transition-colors flex items-center justify-center gap-2"
                          >
                            <ShoppingCartIcon className="w-4 h-4" />
                            <span>В корзину</span>
                          </button>
                        </div>
                        <div className="relative w-[70px] h-full">
                          <div className="absolute inset-0 border-2 border-[#212121] rounded-lg flex items-center justify-between px-2">
                            <button className="text-[#212121] font-medium text-lg">
                              -
                            </button>
                            <span className="text-[#212121] font-medium">1</span>
                            <button className="text-[#212121] font-medium text-lg">
                              +
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default PlayerSetupPage;

// Добавляем базовые анимации
const style = document.createElement('style');
style.textContent = `
  .opacity-0 {
    opacity: 0;
  }
  .opacity-100 {
    opacity: 1;
  }
  .translate-y-0 {
    transform: translateY(0);
  }
  .translate-y-8 {
    transform: translateY(8px);
  }
  .transition-all {
    transition-property: all;
  }
  .duration-300 {
    transition-duration: 300ms;
  }
  .duration-500 {
    transition-duration: 500ms;
  }
  .ease-out {
    transition-timing-function: cubic-bezier(0, 0, 0.2, 1);
  }
`;
document.head.appendChild(style); 