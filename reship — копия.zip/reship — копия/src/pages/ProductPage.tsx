import React, { useState, useEffect } from 'react';
import { Link, useParams } from 'react-router-dom';
import { StarIcon, HandThumbUpIcon, HandThumbDownIcon } from '@heroicons/react/24/outline';
import { StarIcon as StarSolidIcon } from '@heroicons/react/24/solid';
import { useDispatch, useSelector } from 'react-redux';
import { addToFavorite, removeFromFavorite, selectIsFavorite } from '../store/slices/favoriteSlice';
import VerticalProductCard from '../components/VerticalProductCard';
import { addToCart } from '../store/slices/cartSlice';
import { toast } from 'react-hot-toast';
import { RootState } from '../store';
import { 
  ProductGallery, 
  ProductInfo, 
  ReviewSection, 
  ReviewForm 
} from '../components/product';
import type { Review, ReviewsStats, ReviewPhoto } from '../types/reviews';
import { ReviewFormData } from '../components/product/ReviewForm';

// Компонент для отображения уведомлений от Reship
const NotificationMessage: React.FC<{
  message: string;
  date: string;
}> = ({ message, date }) => {
  return (
    <div className="flex items-start bg-[#F1F4FA] mb-6 rounded-md overflow-hidden">
      <div className="flex flex-col items-start pr-4 pl-4 py-4 border-r border-[#E3E7F0]">
        <span className="font-['Century_Gothic'] font-bold text-lg text-[#212121]">Reship</span>
        <span className="font-['Roboto'] text-sm text-[#5C5C5C]">{date}</span>
      </div>
      <div className="flex-1 p-4">
        <p className="font-['Roboto'] text-base text-[#212121]">{message}</p>
      </div>
    </div>
  );
};

// Моковые данные для медиа-обзоров
const mediaReviews = [
  {
    id: 1,
    source: 'Техноблог',
    title: 'Leopold FC750R BT: Клавиатура, которая стоит каждого рубля',
    text: 'Механическая клавиатура Leopold FC750R BT Light Pink — прекрасный выбор для тех, кто ценит эстетику и качество.',
    rating: 4.8,
    link: 'https://example.com/review1',
    logo: '/images/media/technoblog.svg',
    tags: ['Обзор', 'Механические клавиатуры']
  },
  {
    id: 2,
    source: 'Keyboard.ru',
    title: 'Розовая мечта: тестируем Leopold FC750R BT',
    text: 'Отличное качество сборки, приятный звук и тактильные ощущения — клавиатура полностью оправдывает свою стоимость.',
    rating: 4.5,
    link: 'https://example.com/review2',
    logo: '/images/media/keyboardru.svg',
    tags: ['Обзор', 'Тест']
  },
  {
    id: 3,
    source: 'GadgetLab',
    title: 'Топ-10 клавиатур 2023 года',
    text: 'Leopold FC750R BT занимает третье место в нашем рейтинге лучших клавиатур 2023 года благодаря своей надежности и эргономике.',
    rating: 4.7,
    link: 'https://example.com/review3',
    logo: '/images/media/gadgetlab.svg',
    tags: ['Рейтинг', 'Сравнение']
  },
  {
    id: 4,
    source: 'Техно Обзор',
    title: 'Leopold FC750R BT: Король TKL-клавиатур',
    text: 'Малошумные переключатели Cherry MX Silent Red и высококачественные PBT-кейкапы делают эту клавиатуру отличным выбором для повседневного использования.',
    rating: 4.6,
    link: 'https://example.com/review4',
    logo: '/images/media/techreview.svg',
    tags: ['Обзор', 'Сравнение']
  }
];

// Фильтры для медиа-обзоров (переведены на русский)
const mediaReviewFilters = [
  { id: 'all', name: 'Все' },
  { id: 'reviews', name: 'Обзоры' },
  { id: 'ratings', name: 'Рейтинги' },
  { id: 'comparisons', name: 'Сравнения' }
];

// Моковые данные для вопрос-ответ
const faqData = [
  {
    id: 1,
    question: 'Как мне ухаживать за клавиатурой?',
    answer: 'Регулярная чистка: Переверни и потряси, чтобы вытряхнуть крошки. Влажная уборка: Протри слегка влажной (не мокрой!) салфеткой или тряпочкой. Сложные места: Используй ватные палочки или зубочистки для очистки щелей. Дезинфекция: Протирай спиртовыми салфетками для гигиены. Избегай жидкостей: Не проливай ничего на клавиатуру. Снимай клавиши (опционально): Для глубокой очистки, но будь осторожна, чтобы не сломать механизмы.'
  },
  {
    id: 2,
    question: 'Можно ли использовать клавиатуру во время зарядки?',
    answer: 'Да, клавиатура Leopold FC750R BT может использоваться в проводном режиме через USB-C кабель. Это не повлияет на производительность клавиатуры и позволит одновременно пользоваться устройством и заряжать его.'
  },
  {
    id: 3,
    question: 'Поддерживает ли клавиатура макросы?',
    answer: 'Leopold FC750R BT не имеет встроенной поддержки макросов, но вы можете использовать программное обеспечение на вашем компьютере для этой функции. Существуют сторонние программы, такие как AutoHotkey (Windows) или Karabiner (Mac), которые позволяют настраивать сложные макросы.'
  },
  {
    id: 4,
    question: 'Как сбросить Bluetooth-подключение?',
    answer: 'Для сброса Bluetooth-подключения удерживайте кнопку Fn + соответствующую кнопку Bluetooth (1-4) в течение 3 секунд. После этого индикатор начнет мигать, указывая на то, что клавиатура находится в режиме сопряжения и готова к подключению к новому устройству.'
  }
];

// Моковые данные для продукта
const productData = {
  id: 1,
  title: 'Leopold FC750R BT Light Pink',
  brand: 'Leopold',
  price: 10299,
  oldPrice: 12200,
  discount: 17,
  rating: 4.7,
  reviewCount: 125,
  availability: 'В наличии',
  description: 'Механическая клавиатура Leopold FC750R BT Light Pink с переключателями Cherry MX Red. Беспроводное и проводное подключение, компактный формат без цифрового блока, розовый цвет корпуса.',
  features: [
    { name: 'Интерфейс', value: 'USB-C, Bluetooth 5.0' },
    { name: 'Переключатели', value: 'Cherry MX Red' },
    { name: 'Формат', value: 'TKL (без цифрового блока)' },
    { name: 'Цвет', value: 'Розовый' },
    { name: 'Материал корпуса', value: 'ABS-пластик' },
    { name: 'Тип подсветки', value: 'Нет' }
  ],
  // Добавленные группированные характеристики согласно Figma
  featuresGrouped: {
    packaging: [
      'Клавиатура',
      'Коробка',
      'Защита от пыли',
      'Кабель с велкро застежкой',
      'Кейкап пуллер',
      'Дополнительные клавиши модификаторы Ctrl, CapsLock',
      'Батарейки типа ААА - 2шт'
    ],
    construction: 'Классическая',
    keycapMaterial: 'Doubleshot PBT',
    size: '65%',
    switches: 'Cherry MX Red',
    backlighting: 'RGB',
    connection: 'USB Type-C, Bluetooth 5.1'
  },
  images: [
    '/images/products/keyboards/leopold-fc750r/1.svg',
    '/images/products/keyboards/leopold-fc750r/2.svg',
    '/images/products/keyboards/leopold-fc750r/3.svg',
    '/images/products/keyboards/leopold-fc750r/4.svg'
  ],
  imageDescriptions: [
    'Leopold FC750R BT Light Pink (вид сверху)',
    'Leopold FC750R BT Light Pink (вид сбоку)',
    'Leopold FC750R BT Light Pink (вид с разъемами)',
    'Leopold FC750R BT Light Pink (с упаковкой)'
  ],
  switchOptions: [
    { id: 'brown', name: 'Cherry MX Brown', color: '#5C2F1C' },
    { id: 'red', name: 'Cherry MX Silent Red', color: '#8C0C0C' },
    { id: 'black', name: 'Cherry MX Black', color: '#212121' }
  ],
  colorOptions: [
    { id: 'white', name: 'Белый', color: '#FFFFFF' },
    { id: 'black', name: 'Черный', color: '#212121' },
    { id: 'pink', name: 'Розовый', color: '#FF8297' }
  ],
  reviews: [
    {
      id: 1,
      author: 'Александр С.',
      date: '15.03.2023',
      rating: 5,
      text: 'Отличная клавиатура! Приятный звук переключателей, хорошее качество сборки. Рекомендую!'
    },
    {
      id: 2,
      author: 'Мария П.',
      date: '02.02.2023',
      rating: 4,
      text: 'Клавиатура понравилась, но к цвету надо привыкнуть. Немного ярче, чем на фото.'
    },
    {
      id: 3,
      author: 'Дмитрий К.',
      date: '20.01.2023',
      rating: 5,
      text: 'Топовая клава, звук приятный, тактильные ощущения на высоте. За эти деньги - лучшее, что можно найти.'
    }
  ]
};

// Моковые данные для похожих товаров
const similarProducts = [
  {
    id: 2,
    title: 'Varmilo VA88M Sakura',
    brand: 'Varmilo',
    price: 12000,
    rating: 4.5,
    reviewCount: 42,
    image: '/images/products/keyboards/leopold-fc750r/2.svg',
    inStock: true,
    colors: [
      { id: 1, name: 'Белый', hex: '#FFFFFF' },
      { id: 2, name: 'Розовый', hex: '#FF8297' }
    ]
  },
  {
    id: 3,
    title: 'Ducky One 3 Daybreak',
    brand: 'Ducky',
    price: 13500,
    rating: 4.8,
    reviewCount: 36,
    image: '/images/products/keyboards/leopold-fc750r/1.svg',
    inStock: true,
    colors: [
      { id: 1, name: 'Синий', hex: '#2B6BE6' },
      { id: 2, name: 'Черный', hex: '#000000' }
    ]
  },
  {
    id: 4,
    title: 'Keychron K8 Pro',
    brand: 'Keychron',
    price: 9000,
    rating: 4.6,
    reviewCount: 28,
    image: '/images/products/keyboards/leopold-fc750r/3.svg',
    inStock: true,
    colors: [
      { id: 1, name: 'Черный', hex: '#000000' },
      { id: 2, name: 'Белый', hex: '#FFFFFF' }
    ]
  },
  {
    id: 5,
    title: 'GMMK Pro',
    brand: 'Glorious',
    price: 16000,
    rating: 4.7,
    reviewCount: 52,
    image: '/images/products/keyboards/leopold-fc750r/4.svg',
    inStock: true,
    colors: [
      { id: 1, name: 'Черный', hex: '#000000' },
      { id: 2, name: 'Серебристый', hex: '#C0C0C0' }
    ]
  }
];

// Преобразование простых отзывов в формат для ReviewSection
const transformedReviews: Review[] = productData.reviews.map(review => ({
  id: review.id.toString(),
  productId: productData.id,
  author: {
    id: `author-${review.id}`,
    name: review.author,
    avatar: undefined
  },
  rating: review.rating as 1 | 2 | 3 | 4 | 5,
  date: review.date,
  content: review.text,
  photos: [],
  isVerifiedPurchase: true,
  helpfulCount: 0,
  unhelpfulCount: 0
}));

// Статистика отзывов
const reviewsStats: ReviewsStats = {
  averageRating: productData.rating,
  totalCount: productData.reviewCount,
  ratingCounts: {
    1: productData.reviews.filter(r => r.rating === 1).length,
    2: productData.reviews.filter(r => r.rating === 2).length,
    3: productData.reviews.filter(r => r.rating === 3).length,
    4: productData.reviews.filter(r => r.rating === 4).length,
    5: productData.reviews.filter(r => r.rating === 5).length
  },
  withPhotosCount: 0,
  positiveCount: productData.reviews.filter(r => r.rating >= 4).length,
  negativeCount: productData.reviews.filter(r => r.rating <= 2).length
};

// Компонент MediaReviews
const MediaReviews: React.FC<{ reviews: typeof mediaReviews }> = ({ reviews }) => {
  const [activeFilter, setActiveFilter] = useState('all');
  const [hoveredItem, setHoveredItem] = useState<number | null>(null);
  
  const filterMap = {
    'all': () => true,
    'reviews': (review: typeof mediaReviews[0]) => review.tags.includes('Обзор'),
    'ratings': (review: typeof mediaReviews[0]) => review.tags.includes('Рейтинг'),
    'comparisons': (review: typeof mediaReviews[0]) => review.tags.includes('Сравнение')
  };
  
  const filteredReviews = reviews.filter(filterMap[activeFilter as keyof typeof filterMap]);
  
  return (
    <div className="mt-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="font-['Century_Gothic'] font-bold text-2xl text-[#212121]">Медиа советуют</h2>
        <div className="flex gap-4">
          {mediaReviewFilters.map(filter => (
            <button
              key={filter.id}
              className={`font-['Roboto'] text-sm transition-colors duration-200 ${
                activeFilter === filter.id 
                  ? 'text-[#096DFF] font-medium border-b-2 border-[#096DFF]' 
                  : 'text-[#5C5C5C] hover:text-[#096DFF]'
              }`}
              onClick={() => setActiveFilter(filter.id)}
            >
              {filter.name}
            </button>
          ))}
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-6">
        {filteredReviews.map(review => (
          <a 
            href={review.link} 
            target="_blank"
            rel="noopener noreferrer"
            key={review.id}
            className={`block p-6 bg-white rounded-[7px] transition-all duration-200 ${
              hoveredItem === review.id ? 'shadow-md transform -translate-y-1' : ''
            }`}
            onMouseEnter={() => setHoveredItem(review.id)}
            onMouseLeave={() => setHoveredItem(null)}
          >
            <div className="flex items-center justify-between mb-3">
              <p className="font-['Century_Gothic'] font-medium text-sm text-[#5C5C5C]">{review.source}</p>
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <span key={i}>
                    {i < Math.floor(review.rating) 
                      ? <StarSolidIcon className={`w-4 h-4 ${hoveredItem === review.id ? 'text-[#096DFF]' : 'text-[#212121]'} transition-colors duration-200`} />
                      : <StarIcon className="w-4 h-4 text-[#757575]" />
                    }
                  </span>
                ))}
              </div>
            </div>
            <h3 className={`font-['Century_Gothic'] font-bold text-lg mb-2 transition-colors duration-200 ${hoveredItem === review.id ? 'text-[#096DFF]' : 'text-[#212121]'}`}>
              {review.title}
            </h3>
            <p className="font-['Roboto'] text-sm text-[#505050] mb-3 line-clamp-2">
              {review.text}
            </p>
            <div className="flex gap-2">
              {review.tags.map((tag, idx) => (
                <span 
                  key={idx} 
                  className={`text-xs py-1 px-2 rounded-full transition-colors duration-200 ${
                    hoveredItem === review.id 
                      ? 'bg-[#E6F0FF] text-[#096DFF]' 
                      : 'bg-[#E3E7F0] text-[#5C5C5C]'
                  }`}
                >
                  {tag}
                </span>
              ))}
            </div>
          </a>
        ))}
      </div>
    </div>
  );
};

// Компонент FAQ-аккордеон
const FAQAccordion: React.FC<{ items: typeof faqData }> = ({ items }) => {
  const [openItem, setOpenItem] = useState<number | null>(null);

  const toggleItem = (id: number) => {
    if (openItem === id) {
      setOpenItem(null);
    } else {
      setOpenItem(id);
    }
  };

  return (
    <div className="flex flex-row flex-wrap items-start align-content-start gap-y-[20px] gap-x-[15px] w-full">
      {items.map((item) => (
        <div 
          key={item.id}
          className={`flex flex-col items-start rounded-[7px] bg-white ${openItem === item.id ? 'w-[573px] transition-all duration-300 ease-in-out' : 'w-[573px] h-[93px] transition-all duration-300 ease-in-out'}`}
          style={{ 
            padding: openItem === item.id ? '30px 25px' : '34px 31px',
          }}
        >
          <div className="relative w-full flex justify-between items-center group cursor-pointer" onClick={() => toggleItem(item.id)}>
            <h3 className="font-['Century_Gothic'] font-bold text-[18px] leading-[22px] tracking-[-0.01em] text-[#212121]">
              {item.question}
            </h3>
            <div className={`w-[11px] h-[11px] transition-transform duration-300 ${openItem === item.id ? 'rotate-90' : ''}`}>
              <svg width="11" height="11" viewBox="0 0 11 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M4.5 0.5L10 5.5L4.5 10.5" stroke="black" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
          </div>
          
          {openItem === item.id && (
            <div className="mt-[31px] font-['Roboto'] font-normal text-[16px] leading-[22px] tracking-[-0.01em] text-[#505050] transition-all duration-300 ease-in-out">
              {item.answer}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

const ProductPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [activeTab, setActiveTab] = useState<string>('description');
  const [activeImage, setActiveImage] = useState<number>(0);
  const [selectedSwitch, setSelectedSwitch] = useState<string>(productData.switchOptions[0].id);
  const [selectedColor, setSelectedColor] = useState<string>(productData.colorOptions[2].id);
  const [selectedLayout, setSelectedLayout] = useState<string>('en');
  const [quantity, setQuantity] = useState<number>(1);
  const [isReviewFormOpen, setIsReviewFormOpen] = useState<boolean>(false);
  const [reviewSort, setReviewSort] = useState<string>('newest');
  const [reviewFilter, setReviewFilter] = useState<string>('all');
  const [reviews, setReviews] = useState<Review[]>(transformedReviews);
  const dispatch = useDispatch();
  const productId = parseInt(id || '1');
  const isFavorite = useSelector((state: RootState) => selectIsFavorite(state, productId));

  // Стили для страницы
  const styles = {
    container: {
      padding: '24px 0'
    },
    breadcrumbs: {
      width: '100%',
      fontFamily: 'Century Gothic, sans-serif',
      fontWeight: 'bold',
      fontSize: '14px',
      color: '#474747',
      marginBottom: '7px'
    },
    breadcrumbLink: {
      color: '#474747',
      textDecoration: 'none',
      transition: 'color 0.2s'
    },
    breadcrumbLinkHover: {
      color: '#096DFF'
    },
    breadcrumbSeparator: {
      margin: '0 4px'
    },
    mainContent: {
      display: 'flex',
      flexDirection: 'row' as const,
      gap: '30px',
      height: 'auto',
      minHeight: '528px'
    },
    tabs: {
      display: 'flex',
      flexDirection: 'column' as const,
      justifyContent: 'center',
      alignItems: 'center',
      padding: '13px 0',
      marginTop: '30px',
      height: '56px',
      backgroundColor: 'white',
      position: 'relative' as const,
      zIndex: 1,
      marginLeft: '-20px',
      marginRight: '-20px',
      width: 'calc(100% + 40px)'
    },
    tabsRow: {
      display: 'flex',
      alignItems: 'center',
      gap: '41px',
      width: '487px',
      height: '18px',
      margin: '0 auto'
    },
    tabButton: {
      fontFamily: 'Roboto, sans-serif',
      fontWeight: 500,
      fontSize: '16px',
      backgroundColor: 'transparent',
      border: 'none',
      padding: 0,
      cursor: 'pointer'
    },
    tabIndicator: {
      position: 'relative' as const,
      width: '100%',
      height: '2px',
      marginTop: '4px'
    },
    tabIndicatorLine: {
      position: 'absolute' as const,
      height: '2px',
      backgroundColor: '#212121'
    },
    contentContainer: {
      backgroundColor: '#E3E7F0',
      borderRadius: '8px',
      padding: '24px',
      marginBottom: '32px',
      marginTop: 0,
      position: 'relative' as const,
      zIndex: 0
    },
    similarProductsSection: {
      padding: '32px 0',
      backgroundColor: '#E3E7F0',
      marginBottom: '32px'
    },
    similarProductsHeader: {
      display: 'flex',
      flexDirection: 'row' as const,
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '20px' 
    },
    similarProductsTitle: {
      fontSize: '40px',
      fontWeight: 'bold',
      lineHeight: '49px',
      letterSpacing: '-0.01em',
      color: '#096DFF',
      fontFamily: 'Century Gothic, sans-serif'
    },
    productsGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: '20px'
    }
  };

  // Обработчик переключения табов
  const handleTabClick = (tab: string) => {
    setActiveTab(tab);
    
    if (tab === 'reviews') {
      setTimeout(() => {
        document.getElementById('reviews-section')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }
  };

  // Обработчик отправки отзыва
  const handleReviewSubmit = (reviewData: ReviewFormData) => {
    // В реальном приложении здесь был бы код для отправки отзыва на сервер
    toast.success('Ваш отзыв отправлен! Он будет опубликован после модерации.');
    setIsReviewFormOpen(false);
  };

  // Расчет позиций индикатора активного таба
  const getTabIndicatorStyle = () => {
    switch (activeTab) {
      case 'description':
        return { width: '73px', left: '0' };
      case 'features':
        return { width: '123px', left: '115px' };
      case 'questions':
        return { width: '104px', left: '279px' };
      case 'reviews':
        return { width: '63px', left: '424px' };
      default:
        return { width: '0', left: '0' };
    }
  };

  return (
    <main className="product-page bg-[#E3E7F0]">
      <div className="container" style={styles.container}>
        {/* Хлебные крошки */}
        <div style={styles.breadcrumbs}>
          <Link 
            to="/" 
            style={styles.breadcrumbLink}
            className="hover:text-[#096DFF]"
          >
            Главная
          </Link>
          <span style={styles.breadcrumbSeparator}>{'>'}</span>
          <Link 
            to="/catalog/keyboards" 
            style={styles.breadcrumbLink}
            className="hover:text-[#096DFF]"
          >
            Клавиатуры
          </Link>
          <span style={styles.breadcrumbSeparator}>{'>'}</span>
          <span>{productData.title}</span>
        </div>

        {/* Уведомление от Reship */}
        <NotificationMessage
          message="Александр, написали вам на почту, предложили забрать клавиатуру на бесплатную диагностику."
          date="12 января 2024"
        />

        {/* Основной контент */}
        <div style={styles.mainContent}>
          {/* Галерея продукта */}
          <ProductGallery 
            images={productData.images} 
            imageDescriptions={productData.imageDescriptions}
          />
                
          {/* Информация о продукте */}
          <ProductInfo 
            id={productData.id}
            title={productData.title}
            brand={productData.brand}
            price={productData.price}
            oldPrice={productData.oldPrice}
            discount={productData.discount}
            rating={productData.rating}
            reviewCount={productData.reviewCount}
            availability={productData.availability}
            isFavorite={isFavorite}
            category="Клавиатуры"
            categoryUrl="/catalog/keyboards"
            switchOptions={productData.switchOptions}
            colorOptions={productData.colorOptions}
            onReviewsClick={() => handleTabClick('reviews')}
          />
        </div>
      </div>

      {/* Табы описания - вынесены за пределы обычного контейнера */}
      <div className="relative w-full bg-white" style={{ height: '56px' }}>
        <div className="container flex flex-col justify-center items-center py-[13px]">
          <div style={styles.tabsRow}>
            <button 
              style={{
                ...styles.tabButton,
                color: activeTab === 'description' ? '#212121' : '#5C5C5C'
              }}
              onClick={() => handleTabClick('description')}
            >
              Описание
            </button>
            <button 
              style={{
                ...styles.tabButton,
                color: activeTab === 'features' ? '#212121' : '#5C5C5C'
              }}
              onClick={() => handleTabClick('features')}
            >
              Характеристики
            </button>
            <button 
              style={{
                ...styles.tabButton,
                color: activeTab === 'questions' ? '#212121' : '#5C5C5C'
              }}
              onClick={() => handleTabClick('questions')}
            >
              Вопрос/ответ
            </button>
            <button 
              style={{
                ...styles.tabButton,
                color: activeTab === 'reviews' ? '#212121' : '#5C5C5C'
              }}
              onClick={() => handleTabClick('reviews')}
            >
              Отзывы
            </button>
          </div>
          <div style={styles.tabIndicator}>
            <div style={{ 
              ...styles.tabIndicatorLine, 
              ...getTabIndicatorStyle() 
            }}></div>
          </div>
        </div>
      </div>
        
      <div className="container">
        {/* Содержимое вкладок */}
        <div style={styles.contentContainer}>
          <div style={{ padding: '24px 0' }}>
            {/* Вкладка "Описание" */}
            {activeTab === 'description' && (
              <div style={{ fontFamily: 'Roboto, sans-serif', fontSize: '16px', lineHeight: '22px' }}>
                <p style={{ color: '#212121', marginBottom: '32px' }}>
                  FC750R BT – беспроводная клавиатура 65% формата с низкопрофильными double-shot PBT колпачками и заводской шумоизоляцией. USB Type-C спрятан в центре под корпусом, а на самой клавиатуре имеются центральная и две боковые канавки под кабель.
                </p>
                
                <div style={{ 
                  display: 'grid', 
                  gridTemplateColumns: 'repeat(2, 1fr)', 
                  gap: '24px', 
                  marginTop: '32px' 
                }}>
                  {/* Карточка 1 - Bluetooth */}
                  <div style={{ 
                    display: 'flex', 
                    backgroundColor: 'white', 
                    borderRadius: '8px', 
                    overflow: 'hidden', 
                    boxShadow: '0 1px 2px rgba(0, 0, 0, 0.05)' 
                  }}>
                    <div style={{ 
                      width: '33%', 
                      backgroundColor: '#FCE7F3', 
                      padding: '16px', 
                      display: 'flex', 
                      alignItems: 'center', 
                      justifyContent: 'center' 
                    }}>
                      <img src="/images/products/keyboards/leopold-fc750r/3.svg" alt="Bluetooth" style={{ width: '100%', height: 'auto', objectFit: 'contain' }} />
                    </div>
                    <div style={{ width: '67%', padding: '16px' }}>
                      <h3 style={{ fontWeight: 500, fontSize: '16px', marginBottom: '4px' }}>Поддержка Bluetooth 5.1</h3>
                      <p style={{ fontSize: '12px', color: '#6B7280' }}>
                        Мультидевайс режим поддерживает подключение до 4-х устройств. Работает от двух батареек типа AAA. Если пользоваться клавиатурой 6 часов в день, то одного комплекта батареек хватит на полгода.
                      </p>
                    </div>
                  </div>
                  
                  {/* Карточка 2 - Bluetooth */}
                  <div style={{ 
                    display: 'flex', 
                    backgroundColor: 'white', 
                    borderRadius: '8px', 
                    overflow: 'hidden', 
                    boxShadow: '0 1px 2px rgba(0, 0, 0, 0.05)' 
                  }}>
                    <div style={{ 
                      width: '33%', 
                      backgroundColor: '#FCE7F3', 
                      padding: '16px', 
                      display: 'flex', 
                      alignItems: 'center', 
                      justifyContent: 'center' 
                    }}>
                      <img src="/images/products/keyboards/leopold-fc750r/1.svg" alt="Bluetooth" style={{ width: '100%', height: 'auto', objectFit: 'contain' }} />
                    </div>
                    <div style={{ width: '67%', padding: '16px' }}>
                      <h3 style={{ fontWeight: 500, fontSize: '16px', marginBottom: '4px' }}>Поддержка Bluetooth 5.1</h3>
                      <p style={{ fontSize: '12px', color: '#6B7280' }}>
                        Мультидевайс режим поддерживает подключение до 4-х устройств. Работает от двух батареек типа AAA. Если пользоваться клавиатурой 6 часов в день, то одного комплекта батареек хватит на полгода.
                      </p>
                    </div>
                  </div>
                  
                  {/* Карточка 3 - Type-C */}
                  <div style={{ 
                    display: 'flex', 
                    backgroundColor: 'white', 
                    borderRadius: '8px', 
                    overflow: 'hidden', 
                    boxShadow: '0 1px 2px rgba(0, 0, 0, 0.05)' 
                  }}>
                    <div style={{ 
                      width: '33%', 
                      backgroundColor: '#FCE7F3', 
                      padding: '16px', 
                      display: 'flex', 
                      alignItems: 'center', 
                      justifyContent: 'center' 
                    }}>
                      <img src="/images/products/keyboards/leopold-fc750r/3.svg" alt="Type-C" style={{ width: '100%', height: 'auto', objectFit: 'contain' }} />
                    </div>
                    <div style={{ width: '67%', padding: '16px' }}>
                      <h3 style={{ fontWeight: 500, fontSize: '16px', marginBottom: '4px' }}>Разъём Type-C</h3>
                      <p style={{ fontSize: '12px', color: '#6B7280' }}>
                        Более универсальный и современный, по сравнению с традиционным mini-USB разъёмом. Обратите внимание, что клавиатура не будет работать с кабелем USB Type-C -- USB Type-C.
                      </p>
                    </div>
                  </div>
                  
                  {/* Карточка 4 - Bluetooth */}
                  <div style={{ 
                    display: 'flex', 
                    backgroundColor: 'white', 
                    borderRadius: '8px', 
                    overflow: 'hidden', 
                    boxShadow: '0 1px 2px rgba(0, 0, 0, 0.05)' 
                  }}>
                    <div style={{ 
                      width: '33%', 
                      backgroundColor: '#FCE7F3', 
                      padding: '16px', 
                      display: 'flex', 
                      alignItems: 'center', 
                      justifyContent: 'center' 
                    }}>
                      <img src="/images/products/keyboards/leopold-fc750r/2.svg" alt="Bluetooth" style={{ width: '100%', height: 'auto', objectFit: 'contain' }} />
                    </div>
                    <div style={{ width: '67%', padding: '16px' }}>
                      <h3 style={{ fontWeight: 500, fontSize: '16px', marginBottom: '4px' }}>Поддержка Bluetooth 5.1</h3>
                      <p style={{ fontSize: '12px', color: '#6B7280' }}>
                        Мультидевайс режим поддерживает подключение до 4-х устройств. Работает от двух батареек типа AAA. Если пользоваться клавиатурой 6 часов в день, то одного комплекта батареек хватит на полгода.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {/* Вкладка "Характеристики" */}
            {activeTab === 'features' && (
              <div className="flex flex-col">
                {/* Заголовок секции */}
                <h3 className="font-['Century_Gothic'] font-bold text-xl mb-6 text-[#212121]">
                  Технические характеристики
                </h3>
                
                {/* Белый блок с характеристиками */}
                <div className="flex flex-col bg-white rounded-[7px] p-[17px_24px] mb-6">
                  <div className="flex flex-col gap-3 w-full">
                    {/* Группа: Комплектация */}
                    <div className="flex flex-col gap-5">
                      <div className="flex justify-between">
                        <h4 className="font-['Century_Gothic'] font-bold text-lg text-[#212121]">
                          Комплетация:
                        </h4>
                        <div className="font-['Roboto'] text-base text-[#212121] max-w-[476px]">
                          {productData.featuresGrouped.packaging.map((item, index) => (
                            <div key={index}>{item};</div>
                          ))}
                        </div>
                      </div>
                      <div className="w-full h-0 border-[1.8px] border-[#DEDEDE]"></div>
                    </div>
                    
                    {/* Группа: Конструкция */}
                    <div className="flex flex-col gap-2">
                      <div className="flex justify-between items-center">
                        <h4 className="font-['Century_Gothic'] font-bold text-lg text-[#212121]">
                          Конструкция:
                        </h4>
                        <span className="font-['Roboto'] text-base text-[#212121]">
                          {productData.featuresGrouped.construction}
                        </span>
                      </div>
                      <div className="w-full h-0 border-[1.8px] border-[#DEDEDE]"></div>
                    </div>
                    
                    {/* Группа: Материал клавиш (с иконкой) */}
                    <div className="flex flex-col gap-4">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <h4 className="font-['Century_Gothic'] font-bold text-lg text-[#212121] mr-2">
                            Материал клавиш
                          </h4>
                          <div className="relative w-[17px] h-[17px]">
                            <div className="absolute w-[17px] h-[17px] bg-[#292929] rounded-full"></div>
                            <div className="absolute w-[3px] h-[3px] bg-white rounded-full" style={{ left: '7px', top: '3px' }}></div>
                            <div className="absolute w-[4px] h-[4px] bg-white rounded-full" style={{ left: '6.5px', top: '8px' }}></div>
                          </div>
                        </div>
                        <span className="font-['Roboto'] text-base text-[#212121]">
                          {productData.featuresGrouped.keycapMaterial}
                        </span>
                      </div>
                      <div className="w-full h-0 border-[1.8px] border-[#DEDEDE]"></div>
                    </div>
                    
                    {/* Группа: Размер */}
                    <div className="flex flex-col gap-4">
                      <div className="flex justify-between items-center">
                        <h4 className="font-['Century_Gothic'] font-bold text-lg text-[#212121]">
                          Размер:
                        </h4>
                        <span className="font-['Roboto'] text-base text-[#212121]">
                          {productData.featuresGrouped.size}
                        </span>
                      </div>
                      <div className="w-full h-0 border-[1.8px] border-[#DEDEDE]"></div>
                    </div>

                    {/* Группа: Переключатели */}
                    <div className="flex flex-col gap-4">
                      <div className="flex justify-between items-center">
                        <h4 className="font-['Century_Gothic'] font-bold text-lg text-[#212121]">
                          Переключатели:
                        </h4>
                        <span className="font-['Roboto'] text-base text-[#212121]">
                          {productData.featuresGrouped.switches}
                        </span>
                      </div>
                      <div className="w-full h-0 border-[1.8px] border-[#DEDEDE]"></div>
                    </div>

                    {/* Группа: Подсветка */}
                    <div className="flex flex-col gap-4">
                      <div className="flex justify-between items-center">
                        <h4 className="font-['Century_Gothic'] font-bold text-lg text-[#212121]">
                          Подсветка:
                        </h4>
                        <span className="font-['Roboto'] text-base text-[#212121]">
                          {productData.featuresGrouped.backlighting}
                        </span>
                      </div>
                      <div className="w-full h-0 border-[1.8px] border-[#DEDEDE]"></div>
                    </div>

                    {/* Группа: Подключение */}
                    <div className="flex flex-col gap-4">
                      <div className="flex justify-between items-center">
                        <h4 className="font-['Century_Gothic'] font-bold text-lg text-[#212121]">
                          Подключение:
                        </h4>
                        <span className="font-['Roboto'] text-base text-[#212121]">
                          {productData.featuresGrouped.connection}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {/* Вкладка "Вопрос/ответ" */}
            {activeTab === 'questions' && (
              <div style={{ marginTop: '16px', fontFamily: 'Roboto, sans-serif', fontSize: '16px', lineHeight: '22px' }}>
                <div style={{ borderBottom: '1px solid #D1D5DB', paddingBottom: '16px', marginBottom: '24px' }}>
                  <h3 style={{ fontSize: '18px', fontWeight: 500, marginBottom: '8px', color: '#212121' }}>Часто задаваемые вопросы</h3>
                  <p style={{ fontSize: '14px', color: '#646464' }}>Здесь вы найдете ответы на самые распространенные вопросы о клавиатуре Leopold FC750R BT</p>
                </div>
                
                <FAQAccordion items={faqData} />
              </div>
            )}
            
            {/* Вкладка "Отзывы" */}
            {activeTab === 'reviews' && (
              <ReviewSection 
                productId={productData.id}
                reviews={transformedReviews}
                stats={reviewsStats}
                onWriteReview={() => setIsReviewFormOpen(true)}
              />
            )}
            
            {/* Медиа советуют - только на вкладке "Описание" */}
            {activeTab === 'description' && (
              <MediaReviews reviews={mediaReviews} />
            )}
          </div>
        </div>

        {/* Похожие товары */}
        <section style={styles.similarProductsSection}>
          <div className="container mx-auto px-4">
            <div style={styles.similarProductsHeader}>
              <h2 style={styles.similarProductsTitle}>
                Похожие товары
              </h2>
            </div>
            <div style={styles.productsGrid}>
              {similarProducts.map(product => (
                <VerticalProductCard 
                  key={product.id} 
                  id={product.id}
                  title={product.title}
                  brand={product.brand}
                  price={product.price}
                  rating={product.rating}
                  reviewCount={product.reviewCount}
                  image={product.image}
                  inStock={product.inStock}
                  colors={product.colors}
                />
              ))}
            </div>
          </div>
        </section>

        {/* Модальное окно с формой отзыва */}
        {isReviewFormOpen && (
          <ReviewForm
            productId={productData.id}
            onSubmit={handleReviewSubmit}
            onCancel={() => setIsReviewFormOpen(false)}
          />
        )}

        {/* CSS стили для кнопки "Оставить отзыв" */}
        <style>
          {`
            .review-section-write-btn {
              background-color: #096DFF !important;
              color: white !important;
              padding: 10px 22px !important;
              border-radius: 6px !important;
              font-size: 15px !important;
              font-weight: 500 !important;
              border: none !important;
              cursor: pointer !important;
              font-family: 'Roboto', sans-serif !important;
              transition: background-color 0.2s !important;
            }
            
            .review-section-write-btn:hover {
              background-color: #0759CF !important;
            }
          `}
        </style>
      </div>
    </main>
  );
};

export default ProductPage;