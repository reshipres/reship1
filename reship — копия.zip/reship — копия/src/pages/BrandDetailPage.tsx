import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import ProductCard from '../components/ProductCard';

// Интерфейс для бренда
interface Brand {
  id: number;
  name: string;
  logo: string;
  description: string;
  fullDescription: string;
  foundedYear: number;
  country: string;
  website: string;
  categories: string[];
}

// Интерфейс для продукта
interface Product {
  id: number;
  title: string;
  brand: string;
  price: number;
  oldPrice?: number;
  rating: number;
  reviewCount: number;
  image: string;
  discount?: number;
  isNew?: boolean;
  inStock?: boolean;
}

const BrandDetailPage: React.FC = () => {
  const { brandSlug } = useParams<{ brandSlug: string }>();
  const [activeTab, setActiveTab] = useState<'all' | 'popular' | 'new'>('all');
  const [brand, setBrand] = useState<Brand | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Имитация загрузки данных о бренде
    const fetchBrandData = () => {
      setIsLoading(true);
      
      // Моковые данные бренда
      const brandData: { [key: string]: Brand } = {
        'logitech': {
          id: 1,
          name: 'Logitech',
          logo: 'https://maxgaming.com/img/cms/Logitech/Logitech_Logo.jpg',
          description: 'Швейцарский производитель компьютерной периферии и программного обеспечения',
          fullDescription: 'Logitech International — швейцарская компания, производитель компьютерной периферии, основанная в 1981 году. Сегодня Logitech является одним из лидеров индустрии, производя широкий спектр продуктов: мыши, клавиатуры, веб-камеры, колонки, игровые контроллеры и многое другое. Компания известна своими инновациями и высококачественной продукцией, которая регулярно получает награды дизайнерских конкурсов.',
          foundedYear: 1981,
          country: 'Швейцария',
          website: 'www.logitech.com',
          categories: ['Мыши', 'Клавиатуры', 'Наушники', 'Веб-камеры']
        },
        'varmilo': {
          id: 2,
          name: 'Varmilo',
          logo: 'https://maxgaming.com/img/cms/Varmilo/Varmilo_Logo.jpg',
          description: 'Китайский бренд, специализирующийся на высококачественных механических клавиатурах',
          fullDescription: 'Varmilo — китайский производитель клавиатур, основанный в 2010 году. Компания получила признание среди энтузиастов механических клавиатур благодаря высокому качеству изготовления, вниманию к деталям и эстетически привлекательному дизайну. Varmilo использует переключатели Cherry MX и предлагает широкий выбор тематических дизайнов, от минималистичных до ярких художественных оформлений.',
          foundedYear: 2010,
          country: 'Китай',
          website: 'www.varmilo.com',
          categories: ['Клавиатуры', 'Коврики', 'Аксессуары']
        },
        'ducky': {
          id: 3,
          name: 'Ducky',
          logo: 'https://maxgaming.com/img/cms/Ducky/Ducky_Logo.jpg',
          description: 'Тайваньский производитель механических клавиатур премиум-класса',
          fullDescription: 'Ducky — тайваньская компания, основанная в 2008 году, специализирующаяся на производстве высококачественных механических клавиатур. Компания завоевала популярность среди геймеров и энтузиастов благодаря превосходному качеству сборки, инновационным функциям и уникальному дизайну. Ducky славится вниманием к мельчайшим деталям, используя высококачественные материалы и самые современные технологии.',
          foundedYear: 2008,
          country: 'Тайвань',
          website: 'www.duckychannel.com.tw',
          categories: ['Клавиатуры', 'Аксессуары']
        }
      };
      
      // Моковые данные продуктов
      const productsData: Product[] = [
        {
          id: 101,
          title: 'G Pro X Superlight',
          brand: brandSlug ? (brandSlug.charAt(0).toUpperCase() + brandSlug.slice(1)) : 'Unknown',
          price: 12990,
          rating: 4.8,
          reviewCount: 156,
          image: 'https://maxgaming.com/img/cms/Logitech/G%20PRO%20X%20SUPERLIGHT/Logitech_G_PRO_X_SUPERLIGHT_Black_1.jpg',
          isNew: true,
          inStock: true
        },
        {
          id: 102,
          title: 'G502 X Plus',
          brand: brandSlug ? (brandSlug.charAt(0).toUpperCase() + brandSlug.slice(1)) : 'Unknown',
          price: 14990,
          oldPrice: 16990,
          rating: 4.7,
          reviewCount: 82,
          image: 'https://maxgaming.com/img/cms/Logitech/G502%20X%20Plus/Logitech_G502_X_Plus_White_3.jpg',
          discount: 12,
          inStock: true
        },
        {
          id: 103,
          title: 'G915 TKL',
          brand: brandSlug ? (brandSlug.charAt(0).toUpperCase() + brandSlug.slice(1)) : 'Unknown',
          price: 17990,
          rating: 4.9,
          reviewCount: 124,
          image: 'https://maxgaming.com/img/cms/Logitech/G915%20TKL/Logitech_G915_TKL_White_1.jpg',
          inStock: true
        },
        {
          id: 104,
          title: 'MX Master 3S',
          brand: brandSlug ? (brandSlug.charAt(0).toUpperCase() + brandSlug.slice(1)) : 'Unknown',
          price: 9990,
          rating: 4.8,
          reviewCount: 189,
          image: 'https://maxgaming.com/img/cms/Logitech/MX%20Master%203S/Logitech_MX_Master_3S_Graphite_1.jpg',
          inStock: true
        },
        {
          id: 105,
          title: 'G Pro X Keyboard',
          brand: brandSlug ? (brandSlug.charAt(0).toUpperCase() + brandSlug.slice(1)) : 'Unknown',
          price: 13990,
          oldPrice: 15990,
          rating: 4.6,
          reviewCount: 76,
          image: 'https://maxgaming.com/img/cms/Logitech/G%20PRO%20X/Logitech_G_PRO_X_Mechanical_Gaming_Keyboard_1.jpg',
          discount: 12,
          inStock: true
        },
        {
          id: 106,
          title: 'G733 Wireless',
          brand: brandSlug ? (brandSlug.charAt(0).toUpperCase() + brandSlug.slice(1)) : 'Unknown',
          price: 10990,
          rating: 4.5,
          reviewCount: 64,
          image: 'https://maxgaming.com/img/cms/Logitech/G733/Logitech_G733_LIGHTSPEED_Wireless_RGB_Gaming_Headset_White_1.jpg',
          isNew: true,
          inStock: true
        },
        {
          id: 107,
          title: 'G305 Lightspeed',
          brand: brandSlug ? (brandSlug.charAt(0).toUpperCase() + brandSlug.slice(1)) : 'Unknown',
          price: 4990,
          oldPrice: 5990,
          rating: 4.7,
          reviewCount: 245,
          image: 'https://maxgaming.com/img/cms/Logitech/G305/Logitech_G305_LIGHTSPEED_Gaming_Mouse_White_1.jpg',
          discount: 17,
          inStock: true
        },
        {
          id: 108,
          title: 'G213 Prodigy',
          brand: brandSlug ? (brandSlug.charAt(0).toUpperCase() + brandSlug.slice(1)) : 'Unknown',
          price: 4990,
          rating: 4.3,
          reviewCount: 112,
          image: 'https://maxgaming.com/img/cms/Logitech/G213/Logitech_G213_Prodigy_Gaming_Keyboard_1.jpg',
          inStock: true
        }
      ];
      
      // Имитация задержки сети
      setTimeout(() => {
        setBrand(brandData[brandSlug || ''] || null);
        setProducts(productsData);
        setIsLoading(false);
      }, 500);
    };
    
    fetchBrandData();
  }, [brandSlug]);

  if (isLoading) {
    return (
      <div className="bg-[#E3E7F0] min-h-screen py-8 md:py-12">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#096DFF]"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!brand) {
    return (
      <div className="bg-[#E3E7F0] min-h-screen py-8 md:py-12">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="text-center py-16">
            <h1 className="font-century font-bold text-3xl md:text-4xl text-[#212121] mb-4">Бренд не найден</h1>
            <p className="font-roboto text-lg text-[#545454] mb-6">К сожалению, информация о запрошенном бренде отсутствует.</p>
            <Link to="/brands" className="inline-block px-6 py-3 bg-[#096DFF] text-white font-medium rounded-lg hover:bg-[#0756cc] transition-colors">
              Вернуться к списку брендов
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#E3E7F0] min-h-screen py-8 md:py-12">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Хлебные крошки */}
        <div className="mb-6">
          <div className="flex items-center text-sm text-[#545454]">
            <Link to="/" className="hover:text-[#096DFF] transition-colors">Главная</Link>
            <span className="mx-2">›</span>
            <Link to="/brands" className="hover:text-[#096DFF] transition-colors">Бренды</Link>
            <span className="mx-2">›</span>
            <span className="text-[#096DFF]">{brand.name}</span>
          </div>
        </div>
        
        {/* Шапка с информацией о бренде */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Логотип бренда */}
            <div className="w-full md:w-1/4 flex justify-center items-center p-6 bg-white rounded-lg border border-gray-100">
              <img 
                src={brand.logo} 
                alt={`${brand.name} логотип`} 
                className="max-w-full max-h-40 object-contain"
              />
            </div>
            
            {/* Информация о бренде */}
            <div className="w-full md:w-3/4">
              <h1 className="font-century font-bold text-3xl md:text-4xl text-[#212121] mb-4">{brand.name}</h1>
              <p className="font-roboto text-base md:text-lg text-[#545454] mb-6">
                {brand.fullDescription}
              </p>
              
              {/* Данные о бренде */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mb-4">
                <div>
                  <h3 className="font-medium text-sm text-[#757575]">Год основания</h3>
                  <p className="font-roboto text-base text-[#212121]">{brand.foundedYear}</p>
                </div>
                <div>
                  <h3 className="font-medium text-sm text-[#757575]">Страна</h3>
                  <p className="font-roboto text-base text-[#212121]">{brand.country}</p>
                </div>
                <div>
                  <h3 className="font-medium text-sm text-[#757575]">Сайт</h3>
                  <a href={`https://${brand.website}`} target="_blank" rel="noopener noreferrer" className="font-roboto text-base text-[#096DFF] hover:underline">
                    {brand.website}
                  </a>
                </div>
              </div>
              
              {/* Категории */}
              <div>
                <h3 className="font-medium text-sm text-[#757575] mb-2">Категории продуктов</h3>
                <div className="flex flex-wrap gap-2">
                  {brand.categories.map((category, index) => (
                    <span 
                      key={index} 
                      className="px-3 py-1 bg-[#E3E7F0] text-[#212121] text-sm rounded-lg"
                    >
                      {category}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Навигация по продуктам */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
          <h2 className="font-century font-bold text-2xl md:text-3xl text-[#212121]">Продукты {brand.name}</h2>
          
          <div className="flex items-center gap-2 bg-white rounded-lg p-1">
            <button 
              className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${activeTab === 'all' ? 'bg-[#096DFF] text-white' : 'text-[#545454] hover:text-[#212121]'}`}
              onClick={() => setActiveTab('all')}
            >
              Все
            </button>
            <button 
              className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${activeTab === 'popular' ? 'bg-[#096DFF] text-white' : 'text-[#545454] hover:text-[#212121]'}`}
              onClick={() => setActiveTab('popular')}
            >
              Популярные
            </button>
            <button 
              className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${activeTab === 'new' ? 'bg-[#096DFF] text-white' : 'text-[#545454] hover:text-[#212121]'}`}
              onClick={() => setActiveTab('new')}
            >
              Новинки
            </button>
          </div>
        </div>
        
        {/* Сетка продуктов */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {products
            .filter(product => {
              if (activeTab === 'popular') return product.rating >= 4.7;
              if (activeTab === 'new') return product.isNew;
              return true;
            })
            .map(product => (
              <ProductCard
                key={product.id}
                id={product.id}
                title={product.title}
                brand={product.brand}
                price={product.price}
                oldPrice={product.oldPrice}
                rating={product.rating}
                reviewCount={product.reviewCount}
                image={product.image}
                discount={product.discount}
                isNew={product.isNew}
                inStock={product.inStock}
                colors={[]}
              />
            ))}
        </div>
        
        {/* Кнопка "Смотреть все" */}
        <div className="flex justify-center mt-10">
          <Link 
            to={`/catalog?brand=${brandSlug}`}
            className="inline-flex items-center justify-center px-6 py-3 bg-white text-[#096DFF] font-medium rounded-lg border border-[#096DFF] hover:bg-[#096DFF] hover:text-white transition-colors"
          >
            Смотреть все товары {brand.name}
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" className="ml-2">
              <path d="M4.16675 10H15.8334M15.8334 10L10.0001 4.16669M15.8334 10L10.0001 15.8334" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default BrandDetailPage; 