import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../store';
import { fetchPlayers, setFilter, resetFilter } from '../store/slices/playerSlice';
import { 
  MagnifyingGlassIcon, 
  ArrowLeftIcon,
  ComputerDesktopIcon,
  SpeakerWaveIcon,
  AdjustmentsHorizontalIcon,
  XMarkIcon
} from '@heroicons/react/24/outline';
import { Player } from '../types/player';
import { Link } from 'react-router-dom';

// Компонент карточки с оборудованием
const EquipmentCard: React.FC<{ type: string; name: string; specs?: string; image?: string }> = ({ 
  type, 
  name, 
  specs, 
  image 
}) => {
  // Получение иконки на основе типа оборудования
  const getIcon = (type: string) => {
    switch (type.toLowerCase()) {
      case 'monitor':
      case 'монитор':
        return <ComputerDesktopIcon className="w-6 h-6" />;
      case 'headphones':
      case 'наушники':
      case 'headset':
        return <SpeakerWaveIcon className="w-6 h-6" />;
      case 'keyboard':
      case 'клавиатура':
        return <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" d="M22 10.5h-6m-2.25-4.125a3.375 3.375 0 1 1-6.75 0 3.375 3.375 0 0 1 6.75 0ZM4 19.235v-.11a6.375 6.375 0 0 1 12.75 0v.109A12.318 12.318 0 0 1 10.374 21c-2.331 0-4.512-.645-6.374-1.766Z" />
        </svg>;
      case 'mouse':
      case 'мышь':
        return <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" d="M15.042 21.672 13.684 16.6m0 0-2.51 2.225.569-9.47 5.227 7.917-3.286-.672ZM12 2.25V4.5m5.834.166-1.591 1.591M20.25 10.5H18M7.757 14.743l-1.59 1.59M6 10.5H3.75m4.007-4.243-1.59-1.59" />
        </svg>;
      case 'microphone':
      case 'микрофон':
        return <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a6 6 0 0 0 6-6v-1.5m-6 7.5a6 6 0 0 1-6-6v-1.5m6 7.5v3.75m-3.75 0h7.5M12 15.75a3 3 0 0 1-3-3V4.5a3 3 0 1 1 6 0v8.25a3 3 0 0 1-3 3Z" />
        </svg>;
      case 'camera':
      case 'камера':
        return <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" d="m15.75 10.5 4.72-4.72a.75.75 0 0 1 1.28.53v11.38a.75.75 0 0 1-1.28.53l-4.72-4.72M4.5 18.75h9a2.25 2.25 0 0 0 2.25-2.25v-9a2.25 2.25 0 0 0-2.25-2.25h-9A2.25 2.25 0 0 0 2.25 7.5v9a2.25 2.25 0 0 0 2.25 2.25Z" />
        </svg>;
      default:
        return <AdjustmentsHorizontalIcon className="w-6 h-6" />;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 hover:shadow-lg transition-shadow duration-300">
      <div className="relative h-52 bg-gray-50">
        <img 
          src={image || '/placeholder.svg'} 
          alt={name} 
          className="w-full h-full object-contain p-2"
        />
      </div>
      <div className="p-4">
        <div className="flex items-center gap-2 mb-2">
          {getIcon(type)}
          <span className="text-sm font-medium text-blue-600">{type}</span>
        </div>
        <h3 className="text-lg font-semibold text-gray-800">{name}</h3>
        {specs && <p className="text-sm text-gray-600 mt-1">{specs}</p>}
      </div>
    </div>
  );
};

const PlayersPage: React.FC = () => {
  const dispatch = useDispatch();
  const { players, loading, error, filter } = useSelector((state: RootState) => state.players);
  
  const [selectedGame, setSelectedGame] = useState<string>('');
  const [selectedNationality, setSelectedNationality] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [isFilterVisible, setIsFilterVisible] = useState<boolean>(true);

  // Загружаем игроков при монтировании компонента
  useEffect(() => {
    dispatch(fetchPlayers() as any);
  }, [dispatch]);

  // Обновляем фильтры при изменении выбранных значений
  useEffect(() => {
    dispatch(setFilter({
      game: selectedGame,
      nationality: selectedNationality,
      searchTerm
    }));
  }, [dispatch, selectedGame, selectedNationality, searchTerm]);

  // Функция для фильтрации игроков
  const getFilteredPlayers = () => {
    return players.filter((player: Player) => {
      // Фильтр по игре
      if (filter.game && !player.games.includes(filter.game)) {
        return false;
      }
      
      // Фильтр по национальности
      if (filter.nationality && player.nationality !== filter.nationality) {
        return false;
      }
      
      // Фильтр по поисковому запросу
      if (filter.searchTerm) {
        const searchLower = filter.searchTerm.toLowerCase();
        return (
          player.nickname.toLowerCase().includes(searchLower) ||
          player.fullName.toLowerCase().includes(searchLower)
        );
      }
      
      return true;
    });
  };

  // Получаем уникальные игры для фильтра
  const getUniqueGames = () => {
    const games = new Set<string>();
    players.forEach((player: Player) => {
      player.games.forEach((game: string) => games.add(game));
    });
    return Array.from(games).sort();
  };

  // Получаем уникальные национальности для фильтра
  const getUniqueNationalities = () => {
    const nationalities = new Set<string>();
    players.forEach((player: Player) => {
      nationalities.add(player.nationality);
    });
    return Array.from(nationalities).sort();
  };

  // Обработчик сброса фильтров
  const handleResetFilters = () => {
    setSelectedGame('');
    setSelectedNationality('');
    setSearchTerm('');
    dispatch(resetFilter());
  };

  // Отфильтрованные игроки
  const filteredPlayers = getFilteredPlayers();

  return (
    <main className="py-8 md:py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        {/* Заголовок и фильтры */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <h1 className="text-3xl font-bold text-gray-800 mb-4 md:mb-0">Игроки</h1>
            
            <button 
              className="flex items-center text-blue-600 hover:text-blue-800 transition-colors"
              onClick={() => setIsFilterVisible(!isFilterVisible)}
            >
              <AdjustmentsHorizontalIcon className="w-5 h-5 mr-2" />
              {isFilterVisible ? 'Скрыть фильтры' : 'Показать фильтры'}
            </button>
          </div>
          
          {/* Фильтры */}
          {isFilterVisible && (
            <div className="bg-white p-6 rounded-lg shadow-sm mb-8">
              <div className="flex flex-col md:flex-row gap-4 mb-4">
                {/* Фильтр по игре */}
                <div className="w-full md:w-auto">
                  <select
                    value={selectedGame}
                    onChange={(e) => setSelectedGame(e.target.value)}
                    className="w-full md:w-64 px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  >
                    <option value="">Игра</option>
                    {getUniqueGames().map(game => (
                      <option key={game} value={game}>{game}</option>
                    ))}
                  </select>
                </div>
                
                {/* Фильтр по национальности */}
                <div className="w-full md:w-auto">
                  <select
                    value={selectedNationality}
                    onChange={(e) => setSelectedNationality(e.target.value)}
                    className="w-full md:w-64 px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  >
                    <option value="">Национальность</option>
                    {getUniqueNationalities().map(nationality => (
                      <option key={nationality} value={nationality}>{nationality}</option>
                    ))}
                  </select>
                </div>
                
                {/* Поиск */}
                <div className="w-full md:flex-1 relative">
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Поиск игроков"
                    className="w-full px-4 py-2 pr-10 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                  <MagnifyingGlassIcon className="absolute right-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                </div>
              </div>
              
              {/* Активные фильтры и кнопка сброса */}
              {(selectedGame || selectedNationality || searchTerm) && (
                <div className="flex flex-wrap gap-2 mt-4">
                  {selectedGame && (
                    <div className="inline-flex items-center bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                      Игра: {selectedGame}
                      <button onClick={() => setSelectedGame('')} className="ml-2">
                        <XMarkIcon className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                  
                  {selectedNationality && (
                    <div className="inline-flex items-center bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                      Национальность: {selectedNationality}
                      <button onClick={() => setSelectedNationality('')} className="ml-2">
                        <XMarkIcon className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                  
                  {searchTerm && (
                    <div className="inline-flex items-center bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                      Поиск: {searchTerm}
                      <button onClick={() => setSearchTerm('')} className="ml-2">
                        <XMarkIcon className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                  
                  <button
                    onClick={handleResetFilters}
                    className="text-blue-600 hover:text-blue-800 text-sm font-medium ml-auto"
                  >
                    Сбросить все фильтры
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
        
        {/* Индикатор загрузки */}
        {loading && (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
          </div>
        )}
        
        {/* Сообщение об ошибке */}
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-6">
            <p>{error}</p>
          </div>
        )}
        
        {/* Список игроков */}
        {!loading && filteredPlayers.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredPlayers.map((player: Player) => (
              <Link 
                key={player.id}
                to={`/player/${player.id}`}
                className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300 cursor-pointer no-underline"
              >
                <div className="relative h-64 bg-gray-50">
                  <img 
                    src={player.image || '/placeholder.svg'} 
                    alt={player.nickname} 
                    className="w-full h-full object-cover"
                  />
                  {player.isProPlayer && (
                    <div className="absolute top-2 right-2 bg-blue-600 text-white text-xs font-bold px-2 py-1 rounded-md">
                      PRO
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <h2 className="text-xl font-bold text-gray-800 mb-2">{player.nickname}</h2>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {player.games.slice(0, 2).map(game => (
                      <span key={game} className="inline-block px-2 py-1 bg-blue-50 text-blue-700 text-xs font-medium rounded">
                        {game}
                      </span>
                    ))}
                    {player.games.length > 2 && (
                      <span className="inline-block px-2 py-1 bg-gray-50 text-gray-600 text-xs font-medium rounded">
                        +{player.games.length - 2}
                      </span>
                    )}
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">{player.countryCode}</span>
                    <span className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                      Подробнее
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        ) : !loading && !error ? (
          <div className="bg-white p-8 rounded-lg shadow-sm text-center">
            <div className="text-5xl mb-4">🎮</div>
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Игроки не найдены</h2>
            <p className="text-gray-600 mb-6">Попробуйте изменить параметры фильтрации</p>
            <button
              onClick={handleResetFilters}
              className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-6 py-3 rounded-lg transition-colors"
            >
              Сбросить фильтры
            </button>
          </div>
        ) : null}
      </div>
    </main>
  );
};

export default PlayersPage; 