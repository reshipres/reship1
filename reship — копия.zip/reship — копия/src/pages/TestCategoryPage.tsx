import React from 'react';
import CategoryMenu from '../components/CategoryMenu';

// Моковые данные для категорий
const categories = [
  {
    id: 1,
    name: 'Мышки',
    image: '',
    slug: 'mice'
  },
  {
    id: 2,
    name: 'Коврики',
    image: '',
    slug: 'mousepads'
  },
  {
    id: 3,
    name: 'Клавиатуры',
    image: '',
    slug: 'keyboards'
  },
  {
    id: 5,
    name: 'Наушники',
    image: '',
    slug: 'headphones'
  },
  {
    id: 6,
    name: 'Микрофоны',
    image: '',
    slug: 'microphones'
  },
  {
    id: 7,
    name: 'Аксессуары',
    image: '',
    slug: 'accessories'
  }
];

const TestCategoryPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto py-4">
        <CategoryMenu categories={categories} />
      </div>
    </div>
  );
};

export default TestCategoryPage; 