import React from 'react';
import { Link } from 'react-router-dom';

// Интерфейс для бренда
interface Brand {
  id: number;
  name: string;
  logo: string;
  description: string;
  productsCount: number;
}

const BrandsPage: React.FC = () => {
  // Моковые данные для брендов
  const brands: Brand[] = [
    { 
      id: 1, 
      name: 'Logitech', 
      logo: 'https://maxgaming.com/img/cms/Logitech/Logitech_Logo.jpg',
      description: 'Швейцарский производитель компьютерной периферии и программного обеспечения',
      productsCount: 42
    },
    { 
      id: 2, 
      name: 'Varmilo', 
      logo: 'https://maxgaming.com/img/cms/Varmilo/Varmilo_Logo.jpg',
      description: 'Китайский бренд, специализирующийся на высококачественных механических клавиатурах',
      productsCount: 28
    },
    { 
      id: 3, 
      name: 'Ducky', 
      logo: 'https://maxgaming.com/img/cms/Ducky/Ducky_Logo.jpg',
      description: 'Тайваньский производитель механических клавиатур премиум-класса',
      productsCount: 35
    },
    { 
      id: 4, 
      name: 'Glorious', 
      logo: 'https://maxgaming.com/img/cms/Glorious/Glorious_Logo.jpg',
      description: 'Американский бренд периферии для энтузиастов и геймеров',
      productsCount: 24
    },
    { 
      id: 5, 
      name: 'Artisan', 
      logo: 'https://maxgaming.com/img/cms/Artisan/Artisan_Logo.jpg',
      description: 'Японский производитель высококачественных ковриков для мыши',
      productsCount: 16
    },
    { 
      id: 6, 
      name: 'Finalmouse', 
      logo: 'https://maxgaming.com/img/cms/Finalmouse/Finalmouse_Logo.jpg',
      description: 'Производитель ультралегких игровых мышей с инновационным дизайном',
      productsCount: 12
    },
    { 
      id: 7, 
      name: 'Pulsar', 
      logo: 'https://maxgaming.com/img/cms/Pulsar/Pulsar_Logo.jpg',
      description: 'Корейский бренд, специализирующийся на легких игровых мышах',
      productsCount: 19
    },
    { 
      id: 8, 
      name: 'Razer', 
      logo: 'https://maxgaming.com/img/cms/Razer/Razer_Logo.jpg',
      description: 'Американская компания, производитель игровой периферии и аксессуаров',
      productsCount: 53
    },
    { 
      id: 9, 
      name: 'HyperX', 
      logo: 'https://maxgaming.com/img/cms/HyperX/HyperX_Logo.jpg',
      description: 'Американский бренд игровой периферии и аксессуаров',
      productsCount: 31
    },
    { 
      id: 10, 
      name: 'SteelSeries', 
      logo: 'https://maxgaming.com/img/cms/SteelSeries/SteelSeries_Logo.jpg',
      description: 'Датский производитель игровой периферии и аксессуаров',
      productsCount: 38
    },
    { 
      id: 11, 
      name: 'Keychron', 
      logo: 'https://maxgaming.com/img/cms/Keychron/Keychron_Logo.jpg',
      description: 'Производитель беспроводных механических клавиатур',
      productsCount: 24
    },
    { 
      id: 12, 
      name: 'NuPhy', 
      logo: 'https://maxgaming.com/img/cms/NuPhy/NuPhy_Logo.jpg',
      description: 'Производитель низкопрофильных механических клавиатур',
      productsCount: 18
    }
  ];

  return (
    <div className="bg-[#E3E7F0] min-h-screen py-8 md:py-12">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Заголовок страницы */}
        <div className="mb-8 md:mb-12">
          <h1 className="font-century font-bold text-3xl md:text-4xl text-[#212121] mb-3">Бренды</h1>
          <p className="font-roboto text-base md:text-lg text-[#545454]">
            Познакомьтесь с ведущими брендами компьютерной периферии и аксессуаров, представленными в нашем магазине.
          </p>
        </div>
        
        {/* Сетка брендов */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {brands.map((brand) => (
            <Link key={brand.id} to={`/brands/${brand.name.toLowerCase()}`} className="block transition-transform hover:-translate-y-1">
              <div className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                {/* Логотип бренда */}
                <div className="p-6 flex items-center justify-center h-40 bg-white border-b border-gray-100">
                  <img 
                    src={brand.logo} 
                    alt={`${brand.name} логотип`} 
                    className="max-h-28 max-w-[80%] object-contain"
                  />
                </div>
                
                {/* Информация о бренде */}
                <div className="p-5">
                  <h2 className="font-century font-bold text-xl text-[#212121] mb-2">{brand.name}</h2>
                  <p className="font-roboto text-sm text-[#545454] mb-3 line-clamp-2">{brand.description}</p>
                  <div className="flex items-center text-sm text-[#096DFF] font-medium">
                    <span>{brand.productsCount} товаров</span>
                    <svg 
                      width="16" 
                      height="16" 
                      viewBox="0 0 16 16" 
                      fill="none" 
                      xmlns="http://www.w3.org/2000/svg"
                      className="ml-1 transition-transform group-hover:translate-x-1"
                    >
                      <path 
                        d="M8 1L15 8L8 15M15 8H1" 
                        stroke="#096DFF" 
                        strokeWidth="2" 
                        strokeLinecap="round" 
                        strokeLinejoin="round"
                      />
                    </svg>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BrandsPage; 