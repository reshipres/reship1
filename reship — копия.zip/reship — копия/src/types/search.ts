// Категория поиска
export interface Category {
  id: string;
  title: string;
  path: string;
}

// Элемент истории поиска
export interface HistoryItem {
  id: number;
  title: string;
  price: number;
  image: string;
}

// Товар (результат поиска)
export interface Product {
  id: number;
  title: string;
  price: number;
  brand: string;
  image: string;
} 