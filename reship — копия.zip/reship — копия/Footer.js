{/* Copyright at bottom */}
<div className="border-t border-gray-200/50 mt-8 pt-6 text-center text-gray-500 text-sm">
  <p>© 2023 ReShip. Все права защищены.</p>
  <p className="mt-1">ИП Букаров Давид Арсенович</p>
</div> 