# Download Century Gothic fonts

$fontsDir = "src\styles\fonts"

# Create directory if it doesn't exist
if (!(Test-Path $fontsDir)) {
    New-Item -ItemType Directory -Path $fontsDir -Force
}

# URLs for font downloads
$urls = @{
    "CenturyGothic.woff" = "https://allfont.ru/cache/fonts/century-gothic-regular_7cace0aa1bcbfbca6fe6531ca9f33d2d.woff"
    "CenturyGothic.woff2" = "https://allfont.ru/cache/fonts/century-gothic-regular_7cace0aa1bcbfbca6fe6531ca9f33d2d.woff2"
    "CenturyGothicBold.woff" = "https://allfont.ru/cache/fonts/century-gothic-bold_7cace0aa1bcbfbca6fe6531ca9f33d2d.woff"
    "CenturyGothicBold.woff2" = "https://allfont.ru/cache/fonts/century-gothic-bold_7cace0aa1bcbfbca6fe6531ca9f33d2d.woff2"
}

# Download each font
foreach ($file in $urls.Keys) {
    $url = $urls[$file]
    $outputPath = Join-Path $fontsDir $file
    
    Write-Host "Downloading $file from $url"
    
    try {
        Invoke-WebRequest -Uri $url -OutFile $outputPath
        Write-Host "File $file successfully downloaded to $outputPath"
    }
    catch {
        Write-Host "Error downloading $file"
    }
}

Write-Host "Download completed!" 